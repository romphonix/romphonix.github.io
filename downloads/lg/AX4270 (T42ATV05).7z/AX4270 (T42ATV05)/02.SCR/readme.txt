Script file (.SCR) and its sub files.
On SCR Download of LGDP, it is to call all its sub files.
Thanks. 