This is ERI (Enhanced Roaming Indicator) data file.
