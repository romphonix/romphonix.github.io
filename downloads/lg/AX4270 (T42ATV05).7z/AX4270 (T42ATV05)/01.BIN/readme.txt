This file is the binary image of phone software.
Thanks.
