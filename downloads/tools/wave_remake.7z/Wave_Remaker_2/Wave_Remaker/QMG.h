#pragma once


//#include "Qmage.h"
#include <stdlib.h>
#include <memory.h>

	const unsigned short difftableQMG[256] = {
          1,         3,     0x100,         2,         8,	    7,         6,     0x300,
		  0x10,      4,     0x200,         9,      0x40,      0x18,         5,     0x20,
		  0xC,     0xE,       0xF,       0xA,      0xC0,     0x800,     0x700,     0x101,
		  0x400,      0xB,      0x30,      0x11,      0x80,     0x600,    0xD,      0x12,
		  0x1C,     0x500,      0x1B,     0x1E,      0x14,      0x1A,      0x28,     0x38,
     0x1000,      0x1F,      0x19,      0x16,      0x60,   0x2000,      0x13,      0x1D, 
	 0x103,      0x24,       0x17,      0x15,     0x102,     0x1C0,     0xF00,     0x3C, 
	 0x301,     0xC00,    0x1800,      0x48,       0x21,      0x34,     0xE00,     0x202, 
	 0x2C,     0x70,     0xA00,     0x303,      0x36,     0x201,       0x3F,     0xD00,    
	 0x180,      0x3E,    0x3000,    0x900,      0x78,      0x22,      0x50,      0x3A,
       0x41,     0x107,      0x33,     0x106,      0x26,     0x2A,      0xA0,      0x23, 
	   0x29,      0x88,       0x44,      0x3D,      0xE0,      0x32,      0x2E,     0x39,  
	   0x31,      0x2D,      0xF0,     0x140,      0xB00,      0x3B,      0x58,    0x4000, 
	   0x37,     0x35,      0x68,     0x302,      0x7C,      0x2F,       0x27,      0x64,   
	   0x90,      0x74,     0x203,    0x104,      0x6C,    0x1100,     0x3C0,      0xFF,
       0x25,    0xF000,    0x1F00,     0x701,      0x42,     0x7F,      0x2B,     0x105,  
	   0x54,    0x1C00,       0x4C,     0x801,      0x43,    0x6000,      0x5C,     0x7E,  
	   0xE8,     0x108,      0xF8,    0xE000,      0x206,    0x1E00,     0x380,      0x61,
	   0x7A,     0x4E,     0x601,    0x1001,      0xC8,    0x8000,     0x1D00,      0xD0, 
	   0x72,      0x49,    0x1600,   0x1A00,      0x46,    0x7000,     0x10F,     0x110,
       0x76,    0x1200,    0x1400,     0x404,     0x606,    0x10E,      0xFC,    0x1700,  
	   0x6E,      0xFE,     0x1300,      0x62,      0x66,    0xC000,     0x204,    0x306,  
	   0x63,     0x707,     0x280,     0x602,       0x55,      0x47,      0x6A,     0x10C, 
	   0x52,    0x501,      0xD8,     0x307,      0x73,     0x109,      0x808,     0x401, 
	   0x4A,    0x2020,      0x5A,    0x702,      0xB0,      0x45,     0x207,     0x304,
      0x402,      0x5E,     0x10A,      0x79,    0x3800,     0xF4,    0x1500,     0x1E0, 
	  0x1B00,      0x71,     0x1010,      0xC1,      0xE4,     0x502,      0x56,     0x7D,
	  0x81,      0x77,      0xCC,     0x703,      0x10D,     0x205,     0x340,    0x5000,  
	  0x82,     0x67,    0xFF00,     0x120,      0x69,      0x98,       0xC3,    0x1900, 
	  0x65,      0x7B,     0x240,    0x603,      0xEC,      0x59,      0xFA,     0x403,
       0x75,      0x6F,    0x3100,    0x3300,      0x4F,     0xB8,      0x6D,     0x208, 
	   0x4D,     0x111,       0x51,     0x20E,      0xDC,      0xC4,    0x2100,     0xA8
};

namespace ImageUtils
{
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	using namespace System::Runtime::InteropServices;



int  QM_WCodec_2nd_decode( unsigned char * source, unsigned char *dest){
	
	int offset_;
	int BitsBuffer; // 
	unsigned int len1; // 
	unsigned char* len2; // 
	int BitCount; //  
	unsigned char *pDest;
	unsigned int result; // 
	unsigned char *pBlock3; // 
	unsigned char *pBlock2; // 
	unsigned char * pBlock1; // 
	unsigned int first; // 
	
	unsigned char Shift;	
	
	offset_ = 1;
	BitsBuffer = 0; 
	
	first = *(unsigned char *)source | (*(unsigned char *)(source + 1) << 8) | (*(unsigned char *)(source + 2) << 16) | (*(unsigned char *)(source + 3) << 24); 
	len1 = *(unsigned char *)(source + 4) | (*(unsigned char *)(source + 5) << 8) | (*(unsigned char *)(source + 6) << 16) | (*(unsigned char *)(source + 7) << 24); 
	len2 = (unsigned char *)((*(unsigned char *)(source + 8) | (*(unsigned char *)(source + 9) << 8) | (*(unsigned char *)(source + 10) << 16) | (*(unsigned char *)(source + 11) << 24)) + len1 + (unsigned char *)source); 

	pBlock1 = (unsigned char *)(source + 12); 
	pBlock2 = (unsigned char *)(len1 + (unsigned char *)(source + 12)); 

	int CountDword = (first & 0xFFFFFFF0) >> 2;

	pDest = dest + 4; 
	memcpy(dest, (len2 + 12), 4); 

	pBlock3 = (unsigned char *)(len2 + 16);

	BitCount = 0; 
	do {
		BitsBuffer = *(unsigned char *)pBlock1++ | (BitsBuffer << 8);
		BitCount += 8;
	} while ( BitCount < 0x12 ); 

	//BitCount = 24; 
///////////////////////////////////////


	for(int i = 0; i < 3; i++){

	BitCount--;
	if ( !((BitsBuffer >> BitCount) & 1) ) 
	{ 
		BitCount--;
			if ( (BitsBuffer >> BitCount) & 1 ) 
			{
				offset_ = *(unsigned char *)pBlock2++; 

			} else {
			
				offset_ = *(unsigned short *)pBlock3; 
				pBlock3 += 2;
			} 
	}

for(int n = 0; n < 2; n++){

	BitCount --;
	if ( (BitsBuffer >> BitCount) & 1 ) 
	{
		*(unsigned short *)pDest = *(unsigned short *)(pDest - 2 * offset_); 
	} else {
		BitCount--;
				if ( (BitsBuffer >> BitCount) & 1 ) 
				{
				*(unsigned short *)pDest = *(unsigned short *)pBlock3; 
				pBlock3 += 2;
				} else { 

				*(unsigned short *)pDest = (unsigned short )(difftableQMG[*(unsigned char *)pBlock2++] ^ *(unsigned short *)(pDest - 2 * offset_));
					
				}
	}
	pDest+=2;
}


	}




unsigned int Count = 4; 
while ( Count < CountDword )
{
	while(BitCount < 2)
	{
		BitsBuffer = *(unsigned char *)pBlock1++ | (BitsBuffer << 8);
			BitCount += 8;
	}


	BitCount--;
	if ( !((BitsBuffer >> BitCount) & 1) )
	{
		BitCount--; 
		if ( !((BitsBuffer >> BitCount) & 1) )
		{
			memcpy((void *)pDest, pBlock3, 16); 
			pDest += 16;
			pBlock3 += 16;
			
		}else{

		*(unsigned short *)pDest = *(unsigned short *)(pDest - 2 * offset_); 
		pDest +=2;
		*(unsigned short *)pDest = *(unsigned short *)(pDest - 2 * offset_); 
		pDest += 2;
		*(unsigned short *)pDest = *(unsigned short *)(pDest - 2 * offset_);
		pDest += 2;
		*(unsigned short *)pDest = *(unsigned short *)(pDest - 2 * offset_); 
		pDest += 2;
		*(unsigned short *)pDest = *(unsigned short *)(pDest - 2 * offset_); 
		pDest += 2; 
		*(unsigned short *)pDest = *(unsigned short *)(pDest - 2 * offset_); 
		pDest += 2;
		*(unsigned short *)pDest = *(unsigned short *)(pDest - 2 * offset_);
		pDest += 2;
		*(unsigned short *)pDest = *(unsigned short *)(pDest - 2 * offset_); 
		pDest += 2;

		}
		
	}else{




	Shift = *(unsigned char *)pBlock2++;
	
	while ( BitCount < 0xF ) 
	{
		BitsBuffer = *(unsigned char *)pBlock1++ | (BitsBuffer << 8);
		BitCount += 8;
	}
///////////////////////////////////////////
	
unsigned char Cast = 7;	
	
	for(int a = 0 ; a < 4; a++){


		BitCount--;
		if ( !((BitsBuffer >> BitCount)  & 1) )//unset bit
		{
			BitCount--;
			if ( (BitsBuffer >> BitCount) & 1 ) //set bit
			{
				offset_ = *(unsigned char *)pBlock2++; 
				
			} else { 
				offset_ = *(unsigned short *)pBlock3;
				pBlock3 += 2;
			}
		}


		if ( (Shift  /*& 0x80*/>> Cast--)&1 ) // 8 bit 
		{
			*(unsigned short *)pDest = *(unsigned short *)(pDest - 2 * offset_); // set bit

		}else{
			
			BitCount--; 
		if ( (BitsBuffer >> BitCount) & 1 ) 
		{
			*(unsigned short *)pDest = *(unsigned short *)pBlock3; //set bit
			pBlock3 += 2;
		} else { //unset bit
			*(unsigned short *)pDest = (unsigned short )(difftableQMG[*(unsigned char *)pBlock2++] ^ *(unsigned short *)(pDest - 2 * offset_));
			
		
		}

		}
			pDest += 2;

		if ( (Shift  /*& 0x40*/>> Cast--)&1 ) // set bit 
		{
			*(unsigned short *)pDest = *(unsigned short *)(pDest - 2 * offset_); 

		}else{
			
			BitCount--; 
		if ( (BitsBuffer >> BitCount) & 1 ) //set bit
		{
			*(unsigned short *)pDest = *(unsigned short *)pBlock3; 
			pBlock3 += 2;
		} else { // unset bit

			*(unsigned short *)pDest = (unsigned short )(difftableQMG[*(unsigned char *)pBlock2++] ^ *(unsigned short *)(pDest - 2 * offset_));
			
		}

		}
			pDest += 2;


	}

}


	Count += 4; 
}




		unsigned int CountByte = 4 * CountDword; 
	 if ( (unsigned int)(4 * CountDword) < first ) 
		memcpy((void *)pDest, pBlock2, first - CountByte); 

			result = first + 4 * Count - CountByte;


		return result;


}

int QM_WCodec_1st_decode(unsigned char* src, unsigned char* dst, int HmW, int _2or4) { 
	
	 int CounBloc1 = 0;
	 int CounBloc2 = 0;  
	 int CounDst = 0;  
	 unsigned char* pBloc1;  
	 unsigned int i;  
	 int CounBloc3 = 0; 
	 char v17; 
	 unsigned char v20;  
	 int v23;  
	 int v24;  
	 unsigned int j; 
	 int v27; 
	 int size;  
	 int v30; 
	 unsigned char* pBloc3; 
	 unsigned char* pBloc2; 
	
	
	int a3 = *(unsigned int*)(src);
	int a4 = *(unsigned int*)(src + 4);
	int a5 = *(unsigned int*)(src + 8);
//	int d = WORD(dst,0xc);


	 v27 = HmW * _2or4 & 3; 
	 size = HmW * _2or4 >> 2;
	 pBloc1 = src + 4 * a3 + 16; //11
	 pBloc2 = pBloc1 + a4;//v13 + 16; //32
	 pBloc3 = pBloc2 + a5; //31

	 while ( CounDst < size )
	 {
		 while ( 1 ) 
		 {
					

			for ( i = *(unsigned char *)(pBloc1 + CounBloc1++);*(unsigned char *)(pBloc1 + (CounBloc1 - 1)) == 0xFF; CounBloc1++ )
				i += *(unsigned char *)(pBloc1 + CounBloc1);		 
			 

			if ( i ) //offset_ from src if i > 0
				 break;

			 
			*(unsigned int *)(dst + 4 * CounDst) = *(unsigned int *)(pBloc3 + 4 * CounBloc3);
			 CounDst++; CounBloc3++;
			
			 if ( CounDst >= size )
				 goto LABEL_1;

		 } 
			 
		
		 //���� ���� 1 = 0 �� �������� �� ����� 3 ���� �� ����� 0 �� ��� ������ � src ���� FF �� ��������� �� ��������� ���������
		 *(unsigned int *)(dst + 4 * CounDst) = *(unsigned int *)(src + 16 + (4 * i )- 4 );
		CounDst++;

		 for ( j = *(unsigned char *)(pBloc2 + CounBloc2++); *(unsigned char *)(pBloc2 + (CounBloc2 - 1)) == 0xFF; CounBloc2++ )
			 j += *(unsigned char *)(CounBloc2 + pBloc2);
		 

		 while(j > 0  ){
					 *(unsigned int *)(dst + 4 * CounDst) = *(unsigned int *)(src + 16 + (4 * i )- 4 ); 
						CounDst++; j--;
				 } 
			 
	 }

LABEL_1:
	 if ( v27 )
	 {
		 v23 = HmW * _2or4 & 3;
		 v24 = 4 * size;
	 do 
	 {
		 *(unsigned char *)(v24 + dst) = *(unsigned char *)(pBloc1 + CounBloc1++);
		 v17 = v23-- == 1;
		 ++v24; 
	 }
	 while ( !v17 );
	 }
	 return v27 + 4 * CounDst; 
}


	int _QM_WCodec_1st_decode ( unsigned char *src, unsigned char *dst, unsigned short H, unsigned short W, unsigned int _2or4/*, BackgroundWorker ^ bwAsync*/ )
	{

		unsigned int HmW = H*W;

		return QM_WCodec_1st_decode( src,  dst,  HmW, _2or4);


	}


	void QM_WCodec_1st_decode_old(unsigned char * src, unsigned char *dst, unsigned int HmW, unsigned int _2or4){

		//unsigned int countsrc = 0;

		unsigned short a = *(unsigned char*) (src++);
		unsigned short b = *(unsigned char*) (src++);
		unsigned short offset1;
		unsigned short offset2;
		unsigned char operation;
		unsigned char shift;
		unsigned char offset;
		unsigned char repit;
		
		unsigned char* bloc1;
		unsigned char* bloc2;


		unsigned char c = a & 0x7F;

		if ((a >> 7) & 1 ) // set bit 
		{
			offset1 = ( (c << 8) | b );
			offset2 = (*(unsigned short*) src >> 8 | *(unsigned short*) src << 8);
			src += 2;

		}else{
			
			src += 4;
		}
		
		bloc1 = src + offset1;
		bloc2 = src + offset2;

		*(unsigned int*)dst = *(unsigned int*) bloc1;
		bloc1+=4; dst+=4;


//////////////////////////////////////////

		while(1){

			operation = *(unsigned char*)bloc2 ;
			bloc2++;

			for(int shift = 6; shift >= 0; shift -= 2){

			if(!((operation  >> shift) & 3)){
		
				*(unsigned int*)dst = *(unsigned int*) bloc1;
				bloc1+=4; dst+=4;

			}else if(((operation  >> shift) & 3) == 1){
  
				repit = *(unsigned char*) src++;
				offset = *(unsigned char*) src++;
				offset++;

				while(repit){
				*(unsigned int *)dst = *(unsigned int *)(dst - 4 * offset);
				dst+=4; repit--;
				}

			}else if (((operation  >> shift) & 3) == 2){
  
				repit = *(unsigned char*) src++;
				
				while(repit){
				*(unsigned int *)dst = *(unsigned int *)(dst - 4 );
				dst+=4; repit--;
				}

			}else if (((operation  >> shift) & 3) == 3){
			
				goto LEBEL_1;
				//continue;
			}

		}


		}

LEBEL_1:
		
		unsigned int v1 = HmW * _2or4 & 3;
		while(v1){
		*(unsigned char*)dst++ = *(unsigned char*)src++;
		v1--;
		}
	}


}