
#pragma once

#include "ImageUtils.h"
#include "RC1.h"

#include <stdlib.h>
#include <memory.h>


namespace ImageUtils {


	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	using namespace System::Collections::Generic;
	//using namespace System::Runtime::InteropServices;

	#define ALIGN(x,a) (((x)+(a)-1)&~((a)-1))



	[StructLayout(LayoutKind::Sequential, Size=0x200)]
	ref struct PartEntry {

		unsigned int cscMagic;               // 
		unsigned int PartNumber;               // 
		unsigned int Unknown3;     //
		unsigned int PartOffset;     //
		unsigned int Unknown4;     //
		unsigned int Unknown5;     //
		unsigned int PartLen;     //��� ������������� �����, �� � ������ ��� �������
		unsigned int Unknown6;     //
		[MarshalAs(UnmanagedType::ByValArray, SizeConst=0x1E0)]
		array<Byte>^ PartName;

static	PartEntry^ GetPartEntry (BinaryReader^ br/*, int offset*/){

			PartEntry^ partEntry = gcnew PartEntry;

			partEntry->cscMagic = br->ReadInt32();
			partEntry->PartNumber = br->ReadInt32();
			partEntry->Unknown3 = br->ReadInt32();
			partEntry->PartOffset = br->ReadInt32();
			partEntry->Unknown4 = br->ReadInt32();
			partEntry->Unknown5 = br->ReadInt32();
			partEntry->PartLen = br->ReadInt32();
			partEntry->Unknown6 = br->ReadInt32();
			
			partEntry->PartName = gcnew array<Byte>(0x1E0);
			for(int i = 0; i < 0x1E0; i++){
			partEntry->PartName[i] = br->ReadByte();
			}
			
			return partEntry;
		}

static void WritePartEntry(PartEntry^ partEntry, BinaryWriter^ bw){

			bw->Write(partEntry->cscMagic);// = br->ReadInt32();
			bw->Write(partEntry->PartNumber);// = br->ReadInt32();
			bw->Write(partEntry->Unknown3);// = br->ReadInt32();
			bw->Write(partEntry->PartOffset);// = br->ReadInt32();
			bw->Write(partEntry->Unknown4);// = br->ReadInt32();
			bw->Write(partEntry->Unknown5);// = br->ReadInt32();
			bw->Write(partEntry->PartLen);// = br->ReadInt32();
			bw->Write(partEntry->Unknown6);// = br->ReadInt32();

			bw->Write(partEntry->PartName, 0, partEntry->PartName->Length) ;


}

	};


	[StructLayout(LayoutKind::Sequential, Size=0x200)]
	ref struct CSCEntry {

		unsigned int cscMagic;               // 
		unsigned int LenCSC;               // 
		unsigned int PageLen;     //
		unsigned int Unknown1;     //
		unsigned int NumRegions;     //
		unsigned int LenHeader;     //
		unsigned int Unknown2;     //
		//[MarshalAs(UnmanagedType::ByValArray, SizeConst=0x4)]
		array<PartEntry^>^ PartEntryArray;


static	CSCEntry^ GetCSCEntry (BinaryReader^ br/*, int offset*/){

		CSCEntry^ cscEntry = gcnew CSCEntry;
//		br->BaseStream->Seek(offset, System::IO::SeekOrigin::Begin);
		
		cscEntry->cscMagic = br->ReadInt32();     //
		cscEntry->LenCSC = br->ReadInt32(); 
		cscEntry->PageLen = br->ReadInt32();     //
		cscEntry->Unknown1 = br->ReadInt32();     //
		cscEntry->NumRegions = br->ReadInt32();     //
		cscEntry->LenHeader = br->ReadInt32();     //
		cscEntry->Unknown2 = br->ReadInt32();     //

		br->BaseStream->Seek(0x200, System::IO::SeekOrigin::Begin);
			
		cscEntry->PartEntryArray = gcnew array<PartEntry^>(/*7*/cscEntry->NumRegions);

		for(int i = 0; i < /*7*/cscEntry->NumRegions; i++){
		cscEntry->PartEntryArray[i] = PartEntry::GetPartEntry(br);
		}



		return cscEntry;

		}
static void WriteCSCEntry(CSCEntry^ cscEntry, BinaryWriter^ bw){
		
		bw->BaseStream->Seek(0x0, System::IO::SeekOrigin::Begin);

		bw->Write(cscEntry->cscMagic);// = br->ReadInt32();     //
		bw->Write(cscEntry->LenCSC);// = br->ReadInt32(); 
		bw->Write(cscEntry->PageLen);// = br->ReadInt32();     //
		bw->Write(cscEntry->Unknown1);// = br->ReadInt32();     //
		bw->Write(cscEntry->NumRegions);// = br->ReadInt32();     //
		bw->Write(cscEntry->LenHeader);// = br->ReadInt32();     //
		bw->Write(cscEntry->Unknown2);// = br->ReadInt32();     //

		bw->BaseStream->Seek(0x200, System::IO::SeekOrigin::Begin);
		
		for(int i = 0; i < /*7*/cscEntry->NumRegions; i++){
		PartEntry::WritePartEntry(cscEntry->PartEntryArray[i], bw);// = PartEntry::GetPartEntry(br);
		}


}
	};

	String^ GetStringCSC(array<unsigned char>^ buff){
				System::Text::Encoding^ encoding = System::Text::Encoding::UTF8;
				String^ path = "";
				
				for (Int32 i = 0; i < 0x1E0; i++){
					if( 0 != static_cast<Byte>(buff->GetValue(i)) ){
               		path = String::Concat(path, encoding->GetString( buff,i,1 ));
					}else{continue;}
				}
				return path;
	}


//			String^ GetString(array<unsigned char>^ buff, int offset) {
				//Int64 position = br->BaseStream->Position;
				//br->BaseStream->Seek(offset, SeekOrigin::Begin);
//				Char b;
//				String^ string;
//				while((b = buff[offset]) != 0x00) {
//					string += b;
//					offset++;
//				}
				//br->BaseStream->Seek(position, System::IO::SeekOrigin::Begin);
//				return string;
//			}


	void dump_CSC(array<unsigned char>^ Csc, String^ foldername, bool Wave3, BackgroundWorker^ bwAsync ){

				MemoryStream^ myStreamDump = gcnew MemoryStream(Csc);
				BinaryReader^ br = gcnew BinaryReader(myStreamDump);
				br->BaseStream->Seek(0x0, SeekOrigin::Begin);


				CSCEntry^ Entry = CSCEntry::GetCSCEntry(br); 

				br->BaseStream->Seek(0x0, SeekOrigin::Begin);
							
				array<unsigned char>^ bufname = gcnew array<unsigned char>(0x1000);
				br->Read(bufname,0,0x1000);
				BinaryWriter^ bw = gcnew BinaryWriter(File::Create(String::Concat(foldername, L"\\CSC.bin"))); 
				bw->BaseStream->Write(bufname,0,0x1000);
				bw->Close();


//				int Pos = br->BaseStream->Position;
//				br->BaseStream->Seek(Entry->PartEntryArray[1]->PartOffset + 0x60, SeekOrigin::Begin);

//				if(br->ReadInt32() == 0x3A424344){
//				br->BaseStream->Seek(Pos, SeekOrigin::Begin);
				array<unsigned char>^ rsrpart = gcnew array<unsigned char>(Entry->PartEntryArray[0]->PartLen);
				br->Read(rsrpart, 0, Entry->PartEntryArray[0]->PartLen);
									
				Directory::CreateDirectory(foldername + L"\\CSCrcs");
				//bool Wave3 = false;
				dump_RC1(rsrpart, foldername + L"\\CSCrcs", false, bwAsync);
//				}

				br->BaseStream->Seek(Entry->PartEntryArray[1]->PartOffset, SeekOrigin::Begin);
				array<unsigned char>^ sfspart = gcnew array<unsigned char>(br->BaseStream->Length - Entry->PartEntryArray[1]->PartOffset/*Entry->PartEntryArray[1]->PartLen*/);
				br->Read(sfspart,0,br->BaseStream->Length - Entry->PartEntryArray[1]->PartOffset /*Entry->PartEntryArray[1]->PartLen*/);
				
				Directory::CreateDirectory(foldername + L"\\CSCsfs");
				//Wave3 = false;
				dump_fs ( /*br*/sfspart, foldername + L"\\CSCsfs", Wave3, bwAsync );
//int a = 0;
				//return;

	}

	void SetWord ( unsigned int offset, unsigned int enter, BinaryWriter^ bw ){

		bw->BaseStream->Seek(offset, SeekOrigin::Begin);
		bw->Write(enter);

	}

	void Save_file_csc_uncompress ( String^ SaveFileName, TreeNode^ rootNode, BackgroundWorker^ bwAsync ){

				BinaryWriter^ bw = gcnew BinaryWriter(File::Create(SaveFileName)); 
				
				MemoryStream^ myStreamDump = gcnew MemoryStream(File::ReadAllBytes(static_cast <String^> (rootNode->Tag) + L"\\CSC.bin"));
				BinaryReader^ br = gcnew BinaryReader(myStreamDump);
				br->BaseStream->Seek(0x0, SeekOrigin::Begin);
				CSCEntry^ entry = CSCEntry::GetCSCEntry(br); 
				br->Close();


				array<unsigned char>^ rcs_part = Create_file_org ( rootNode, bwAsync );//->ToArray();
	
				unsigned int a = 0x40000, i = 0x100;
				MemoryStream^ rcs_header = gcnew MemoryStream();
				BinaryWriter^ bw1 = gcnew BinaryWriter(rcs_header);

				bw1->BaseStream->Seek(0x0, SeekOrigin::Begin);
				array<unsigned char>^ name_buff = File::ReadAllBytes(rootNode->FirstNode->Tag + "\\name.bin");
				bw1->Write( name_buff, 0, name_buff->Length );

				array<unsigned char>^ len=gcnew array<unsigned char>(4);
				len[0] = rcs_part[0x38];
				len[1] = rcs_part[0x39];
				len[2] = rcs_part[0x3A];
				len[3] = rcs_part[0x3B];
				unsigned int len_non_compress = 0;
				len_non_compress = ((len_non_compress | len[3])<<0x8) ;
				len_non_compress = ((len_non_compress | len[2])<<0x8) ; 
				len_non_compress = ((len_non_compress | len[1])<<0x8) ;
				len_non_compress = ((len_non_compress | len[0])) ;
				len_non_compress = ALIGN(len_non_compress, 0x40000);

				SetWord ( 0x10, len_non_compress, bw1 );//������ ��������� �����
				SetWord ( 0x1C, len_non_compress, bw1 );//������ ��������� �����
				SetWord ( 0x8C, len_non_compress, bw1 );//������ ��������� �����
				SetWord ( 0x14, len_non_compress + 0x40000, bw1 ); //������ ���� (������)�������� � �������� �� ��� ���������
				SetWord ( 0x44, len_non_compress + 0x40000, bw1 ); //������ ���� (������)�������� � �������� �� ��� ���������
				
				//bw1->BaseStream->Seek(0x100, SeekOrigin::Begin);
				while ( a < len_non_compress + 0x40000 )
				{
					SetWord ( i + 0, 0x0F, bw1 );
					SetWord ( i + 4, 0x40000, bw1 );
					SetWord ( i + 8, a, bw1 );
//SET_WORD ( i + 8, a);
					a += 0x40000;
					i += 12;
				}

				i = 0x4000;
				a = 0x40000;
				while ( a < len_non_compress + 0x40000 )
				{
					SetWord ( i, a, bw1 );

					a += 0x1000;
					i += 4;
				}
				
				//SetWord(bw1->BaseStream->Length - 0x4000, 0x2C, bw1)
				
				array<unsigned char>^ buff_header = rcs_header->ToArray();
				Array::Resize(buff_header, /*ALIGN(buff_header->Length, 0x40000)*/0x40000 + len_non_compress + 0x400);
				bw1->Close();
				rcs_header->Close();
				
				Array::Copy(rcs_part, 0, buff_header, 0x40000, len_non_compress + 0x400);

				autosign_buffer(buff_header);
				
				array<unsigned char>^ sfs_part = (Create_file ( rootNode, bwAsync ));//->ToArray();

				
				array<unsigned char>^ buf = File::ReadAllBytes(rootNode->FirstNode->NextNode->Tag + "\\end.bin");
				String^ NameWave = GetString(buf, buf->Length - 1012);
				//String^ FileType = GetString(buf, buf->Length - 980);
				bool Wave3 = false;
				if(NameWave == L"S8600" || NameWave->Substring(0,5) == L"S7230" || NameWave->Substring(0,5) == L"S5750"){

				Wave3 = true;


//				if(Wave3){
				array<unsigned char>^ buffer = gcnew array<unsigned char>(sfs_part->Length);//->ToArray();
				/*buffer = */sfs_part->CopyTo(buffer,0);
				sfs_part = Encrypt ( buffer, Wave3, bwAsync );
				}


				bw->BaseStream->Seek(0x1000, SeekOrigin::Begin);
				bw->Write(buff_header,0,buff_header->Length);
				bw->BaseStream->Seek(0x1000 + ALIGN(buff_header->Length, 0x1000), SeekOrigin::Begin);
				bw->Write(sfs_part, 0, sfs_part->Length);
				

				entry->PartEntryArray[0]->PartLen = buff_header->Length; // ������ � ����������
				entry->PartEntryArray[1]->PartLen = sfs_part->Length - 0x404;//������ ��� ���������
				entry->PartEntryArray[1]->PartOffset = 0x1000 + ALIGN(buff_header->Length, 0x1000);
				entry->LenCSC = /*0x1000 + ALIGN(buff_header->Length, 0x1000)*/entry->PartEntryArray[1]->PartOffset + sfs_part->Length - 0x404;
				
				bw->BaseStream->Seek(0x0, SeekOrigin::Begin);
				CSCEntry::WriteCSCEntry(entry, bw);				
				bw->Close();
				autosign_file(SaveFileName);

	}

	void Save_file_rc1_uncompress ( String^ SaveFileName, TreeNode^ rootNode, BackgroundWorker^ bwAsync ){

				BinaryWriter^ bw1 = gcnew BinaryWriter(File::Create(SaveFileName)); 
//				
//
//
				array<unsigned char>^ rcs_part = Create_file_RC1 ( rootNode, bwAsync );//->ToArray();
//	
				unsigned int a = 0x40000, i = 0x100;
//				MemoryStream^ rcs_header = gcnew MemoryStream();
//				BinaryWriter^ bw1 = gcnew BinaryWriter(rcs_header);


				bw1->BaseStream->Seek(0x0, SeekOrigin::Begin);
				array<unsigned char>^ name_buff = File::ReadAllBytes(rootNode->Tag + "\\name.bin");
				bw1->Write( name_buff, 0, name_buff->Length );
//

				array<unsigned char>^ len=gcnew array<unsigned char>(4);
				len[0] = rcs_part[0x38];
				len[1] = rcs_part[0x39];
				len[2] = rcs_part[0x3A];
				len[3] = rcs_part[0x3B];
				unsigned int len_non_compress = 0;
				len_non_compress = ((len_non_compress | len[3])<<0x8) ;
				len_non_compress = ((len_non_compress | len[2])<<0x8) ; 
				len_non_compress = ((len_non_compress | len[1])<<0x8) ;
				len_non_compress = ((len_non_compress | len[0])) ;
				len_non_compress = ALIGN(len_non_compress, 0x40000);

				SetWord ( 0x10, len_non_compress, bw1 );//������ ��������� �����
				SetWord ( 0x1C, len_non_compress, bw1 );//������ ��������� �����
				SetWord ( 0x8C, len_non_compress, bw1 );//������ ��������� �����
				SetWord ( 0x14, len_non_compress + 0x40000, bw1 ); //������ ���� (������)�������� � �������� �� ��� ���������
				SetWord ( 0x44, len_non_compress + 0x40000, bw1 ); //������ ���� (������)�������� � �������� �� ��� ���������
				
//				//bw1->BaseStream->Seek(0x100, SeekOrigin::Begin);
				while ( a < len_non_compress + 0x40000 )
				{
					SetWord ( i + 0, 0x0F, bw1 );
					SetWord ( i + 4, 0x40000, bw1 );
					SetWord ( i + 8, a, bw1 );
//SET_WORD ( i + 8, a);
					a += 0x40000;
					i += 12;
				}
//
				i = 0x4000;
				a = 0x40000;
				while ( a < len_non_compress + 0x40000 )
				{
					SetWord ( i, a, bw1 );

					a += 0x1000;
					i += 4;
				}
				bw1->BaseStream->Seek(0x40000, SeekOrigin::Begin);
				bw1->Write(rcs_part, 0 , rcs_part->Length);
				bw1->Close();


				array<unsigned char>^ buf = File::ReadAllBytes(SaveFileName);
				String^ NameWave = GetString(buf, buf->Length - 1012);
				//String^ FileType = GetString(buf, buf->Length - 980);
//				bool Wave3 = false;
				if(NameWave == L"S8600" || NameWave->Substring(0,5) == L"S7230" || NameWave->Substring(0,5) == L"S5750"){
//				Wave3 = true;


//				if(Wave3){
				array<unsigned char>^ buffer = gcnew array<unsigned char>(buf->Length);//->ToArray();
				bool Wave3 = false;
				buffer = Encrypt ( buf, Wave3, bwAsync );
				BinaryWriter^ bw2 = gcnew BinaryWriter(File::Create(SaveFileName)); 
				bw2->BaseStream->Seek(0x0, SeekOrigin::Begin);
				bw2->Write(buffer, 0 , buffer->Length);
				bw2->Close();
				}



				autosign_file(SaveFileName);

	}

};