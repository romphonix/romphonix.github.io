#pragma once

#include <memory.h>



namespace ImageUtils
{



	unsigned int/*void*/ LZ32_decompress(unsigned char* src, unsigned char* dst){


				unsigned int count_in1=0, len1, count_in2=0, len2, count_in3=0, len3, count_write=0;
				unsigned char *src1, *src2,  *src3;
				unsigned int data=0, count=0, offset_src3=0; 
				unsigned char  shift=0;

				char  header[8] = {0,0,0,0,0,0,0,0};

				src1 = src + 0x8;
				len1 = (unsigned int)BYTE(src, 2)<<0xF | (unsigned int)BYTE(src, 0)<<0x8 | (unsigned int)BYTE(src, 1);		
				len1 = len1&~1;
				src2 = src1 + len1;
				len2 = (unsigned int)BYTE(src, 6)<<0xF | (unsigned int)BYTE(src, 4)<<0x8 | (unsigned int)BYTE(src, 5);		
				src3 = src2 + len2;
				//len3 = 

					do{
					SET_HALF( dst, count_write<<1,	GET_HALF(src2, count_in2<<1));
					count_write++;	count_in2++;

					offset_src3 = (count_in2 - 1)>>2 & 0x1FFFFFFF;
					shift = 7 & ((count_in2 - 1) << 1);
					
					//}while(BYTE(src3, offset_src3) & header[shift] == 0);
					}while(((signed char)(GET_BYTE(src3, offset_src3)>>shift)& 0x3)/* & header[shift]*/ == 0);


					while(count_in1 < len1){

					unsigned char repeat_count = ((BYTE(src1, count_in1))>>1) & 0x3F;
					unsigned int offset = count_write - BYTE(src1, count_in1 + 1);


					unsigned char count = 0;
					//unsigned int repeat = repeat_count&~1;
					while(count < repeat_count&~1){

					SET_HALF(dst, count_write<<1, GET_HALF(dst,(offset+count)<<1));
					SET_HALF(dst, (count_write+1)<<1, GET_HALF(dst,(offset+count+1)<<1));
					count+=2; count_write+=2;//count_write � ������

					}
					
					while(count < repeat_count){

					SET_HALF(dst, count_write<<1, GET_HALF(dst,(offset+count)<<1));
					count++; count_write++;

					}

					if((signed char)(BYTE(src1, count_in1))<0){

						do{
						SET_HALF( dst, count_write<<1,	GET_HALF(src2, count_in2<<1));
						count_write++;	count_in2++;

						offset_src3 = (count_in2 - 1)>>2 & 0x1FFFFFFF;
						shift = 7 & ((count_in2 - 1)<<1);
						
						//}while(BYTE(src3, offset_src3) & header[shift] == 0);
						}while(((GET_BYTE(src3, offset_src3)>>shift) & 0x3)/* & header[shift]*/ == 0);

					}

					count_in1+=2;
					
					}//while(count_in1 < len1);
				

						return count_write;
}



	void Rbm_LZ32_View(unsigned int Width, unsigned int Height, array<unsigned char>^ data, PictureBox^ pictureBox1){

		//unsigned int length = data->Length;
		unsigned char *src = (unsigned char *)malloc ( data->Length );
		
		Marshal::Copy(data, 0, IntPtr(src), data->Length);

		unsigned char *dst = (unsigned char *)malloc ( Width * Height * 4 );
		unsigned int len = LZ32_decompress( src, dst);		

		Bitmap^ bmp = gcnew Bitmap(Width, Height, Imaging::PixelFormat::Format32bppPArgb);
				Rectangle rect = Rectangle(0,0,Width,Height);
					System::Drawing::Imaging::BitmapData^ bmpData = bmp->LockBits( rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, bmp->PixelFormat );
						IntPtr ptr = bmpData->Scan0;
							int bytes = Math::Abs(bmpData->Stride) * Height;
								memcpy( (void*)(ptr), dst, bytes);
					
						bmp->UnlockBits( bmpData );
						pictureBox1->SizeMode = PictureBoxSizeMode::CenterImage;
					pictureBox1->Image = dynamic_cast<Image^>(bmp);

			free( src );
			free ( dst );



	}










}