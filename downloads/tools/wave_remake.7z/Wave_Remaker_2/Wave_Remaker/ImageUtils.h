#pragma once


//#include "Decrypt_Decompress.h"
#include "Helper.h"
#include "SEED_Crypto.h"


namespace ImageUtils {


	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Collections::Generic;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
//	using namespace System::Security::Cryptography;


#define DIR_PROJECT		"\\Bada\\"
#define ROOT_NAME		"FW"
#define DONOR			"Donor\\"



#define ALIGN(x,a) (((x)+(a)-1)&~((a)-1))

unsigned int  datalen, count, gc;


			String^ GetString(array<unsigned char>^ buff, int offset) {
				Char b;
				String^ string;
				while((b = buff[offset]) != 0x00) {
					string += b;
					offset++;
				}
				return string;
			}


		void OpenProject(String^ ProjectFolderPath, TreeNode^ rootNode, System::Windows::Forms::ContextMenuStrip^ contextMenu )
		{

				for each(String^ PathFile in Directory::GetFiles(ProjectFolderPath, "*.*")){	
				String^ FileName = PathFile->Replace(Path::GetDirectoryName(PathFile) + "\\", "");
				if(FileName == L"end.bin" || FileName == L"name.bin" || FileName == L"CSC.bin"){continue;}
				TreeNode^ NodeFiles= gcnew TreeNode(FileName,1,1);
				NodeFiles->Tag = PathFile;
				NodeFiles->ContextMenuStrip = contextMenu;//
				FileInfo^ fi = gcnew FileInfo(PathFile);
				int FileSize = fi->Length;
				NodeFiles->ToolTipText = String::Format("Size: 0x{0:x8} bytes\nSize: {0:d} bytes", FileSize);//L"����� �����, ��� �����\n � ��� �����";
				
				rootNode->Nodes->Add( NodeFiles);
			}


				for each(String^ PathFolder in Directory::GetDirectories(ProjectFolderPath)) {
				String^ FolderName = PathFolder->Replace(Path::GetDirectoryName(PathFolder) + "\\", "");
				TreeNode^ NodeDirectory = gcnew TreeNode(FolderName,0,0);
				NodeDirectory->Tag = PathFolder;
				NodeDirectory->ContextMenuStrip = contextMenu;//
				rootNode->Nodes->Add( NodeDirectory);
				


					OpenProject(PathFolder, NodeDirectory, contextMenu);


			}



		}

		String^ UCS2STR(array<unsigned char>^ buf)
		{
			System::Text::Encoding^ encoding = System::Text::Encoding::Unicode;
			String^ name = "";
			
			for (Int32 i = 0; i < 1024; i+=2)
		    
			{
				if( 0 != static_cast<Byte>(buf->GetValue(i)) ){
               	name = String::Concat(name, encoding->GetString( buf,i,2 ));
				}else{continue;}
			}

				return name->Replace(L"/", L"\\");
		}

		array<unsigned char>^ STR2UCS (String^ Name)
		{
	
		array<unsigned char>^ bufucs = gcnew array<unsigned char>(0x800);
		array<wchar_t>^ buf = Name->ToCharArray();
		for(int i = 0; i < buf->Length; i++){
			bufucs[i*2] = buf[i];
		}
		return bufucs;
		}

		/*unsigned int*/void dump_fs ( /*BinaryReader^ br*/array<unsigned char>^ bufferffs, String^ foldername,  bool Wave3,  BackgroundWorker^ bwAsync )
{
				Stream^ myStream = gcnew MemoryStream(bufferffs);
				BinaryReader^ br = gcnew BinaryReader( myStream );
	
				String^ name;
				String^ debug = L"\\Debug\\pfsdummy";
				unsigned int len;
				unsigned int type;
				unsigned int futer;
				unsigned int pos = Convert::ToInt32(br->BaseStream->Position + 0x60);
				//unsigned int pos1 = 0;

				array<unsigned char>^ bufname = gcnew array<unsigned char>(0x60);
				br->Read(bufname,0,0x60);
				BinaryWriter^ bw1 = gcnew BinaryWriter(File::Create(foldername + L"\\name.bin")); 
				bw1->BaseStream->Write(bufname,0,0x60);
				bw1->Close();
///////////
						//int Pos = br->BaseStream->Position;
						

						if(Wave3/*br->ReadInt32() != 0x3A424344*/ ){
						br->BaseStream->Seek(0, SeekOrigin::Begin);
						array<unsigned char>^ CryptBuff = gcnew array<unsigned char> (br->BaseStream->Length/* br->BaseStream->Position*/);
						br->Read(CryptBuff,0,br->BaseStream->Length);
						array<unsigned char>^DecryptBuff = Decrypt( CryptBuff, Wave3, bwAsync );
						br->Close();

						Stream^ stream = gcnew MemoryStream(DecryptBuff);

						br = gcnew BinaryReader(stream);
						
						}
						
						br->BaseStream->Seek(pos, SeekOrigin::Begin);
						while ( br->ReadInt32() == 0x3A424344 ) // DCB:
						{
						type  = br->ReadInt32();
						len   = br->ReadInt32 ();
						futer = br->ReadInt32 ();
						array<unsigned char>^ buf = gcnew array<unsigned char>(0x800);
						array<unsigned char>^ bufdata = gcnew array<unsigned char>(len);
							
							
						br->Read(buf,0,0x800);

							name = UCS2STR(buf);

							String^ WritePath = String::Concat(foldername, name);

							if( false == name->Equals(debug)){
								if ( type == 0 ){ // create directory

									Directory::CreateDirectory(WritePath/*String::Concat(foldername, name)*/);

								}else{
									//dump_file ( s, pos, path );
									BinaryWriter^ bw = gcnew BinaryWriter(File::Create(WritePath/*String::Concat(foldername, name)*/)); 
									br->Read(bufdata,0,len);
									bw->BaseStream->Write(bufdata,0,len);
									bw->Close();
								}
							}
							br->BaseStream->Position = (0x810 + ALIGN( len, 16 )+ pos)  ;
							pos = Convert::ToInt32(br->BaseStream->Position);
						
							bwAsync->ReportProgress(Convert::ToInt32(  br->BaseStream->Position *  100 / br->BaseStream->Length));


							}
		
				
							br->BaseStream->Seek( -4, SeekOrigin::End);
							int signature_offset;

						for (int n = 0; n < br->BaseStream->Length / 4; n++){
							if(0xABCDABCD == br->ReadInt32()){
							signature_offset = Convert::ToInt32(br->BaseStream->Position) - 4;	
							br->BaseStream->Seek(-4, SeekOrigin::Current);
							array<unsigned char>^ bufname_1 = gcnew array<unsigned char>(0x400);
							br->Read(bufname_1,0,br->BaseStream->Length - signature_offset/*0x400*/);
							BinaryWriter^ bw2 = gcnew BinaryWriter(File::Create(String::Concat(foldername, L"\\end.bin"))); 
							bw2->BaseStream->Write(bufname_1,0,0x400);
							bw2->Close();

							break;
							}
							br->BaseStream->Seek( -8, SeekOrigin::Current);
						}


						if((br->BaseStream->Length  - signature_offset) != 0x400){
						System::Windows::Forms::MessageBox::Show("Error len futter.","ERROR",MessageBoxButtons::OK, MessageBoxIcon::Error);
						br->Close();
						bwAsync->ReportProgress( 0 );
						
						//return false;
						}

				br->Close();
				bwAsync->ReportProgress( 0 );

	}


		BinaryWriter^ ProcesingFolders(BinaryWriter^ bw, String^ FolderPath, String^ FullPath){

				if(Directory::Exists(FolderPath)){

				bw->Write( 0x3A424344 ); // DCB:
				bw->BaseStream->Seek(0xC/*0x8*/, SeekOrigin::Current);
				bw->Write( STR2UCS(FullPath), 0, 0x800  );
				count++;
				}
			return bw;

}


		BinaryWriter^ ProcesingFiles(BinaryWriter^ bw, String^ FolderPath, String^ FullPath){

	
				bw->Write( 0x3A424344 ); // DCB:
				bw->Write( 0x1 );

				array<unsigned char>^ buf = File::ReadAllBytes(FolderPath);
				array<unsigned char>^ buf1 = gcnew array<unsigned char>(ALIGN(buf->Length, 0x10) - buf->Length);

				bw->Write(buf->Length);
				bw->Write(buf1->Length);
				datalen += buf->Length;
				
				count++;
				
				bw->Write( STR2UCS(FullPath), 0, 0x800  );
					if(0 != buf->Length){
						bw->BaseStream->Write(buf, 0, buf->Length);
							
							if(0 != buf1->Length){
									for(int i = 0; i < buf1->Length; i++){
										buf1[i] = 0xff;
									}
							bw->BaseStream->Write(buf1, 0, buf1->Length);
							}
					}
			return bw;

				}





		BinaryWriter^ load_files ( BinaryWriter^ bw, String^ ProjectFolderPath, String^ FolderPath, BackgroundWorker^ bwAsync )
		{

			for each(String^ PathFolder in Directory::GetDirectories(FolderPath)) {
				String^ FolderName = PathFolder->Replace(ProjectFolderPath, "");
				FolderName = FolderName->Replace("\\", "/");
				ProcesingFolders(bw, PathFolder, FolderName);
				bwAsync->ReportProgress(Convert::ToInt32( count *  100 /( gc + 1)));


				for each(String^ PathFile in Directory::GetFiles(PathFolder, "*.*")){	
				String^ FileName = PathFile->Replace(ProjectFolderPath, "");
				FileName = FileName->Replace("\\", "/");
				ProcesingFiles(bw, PathFile, FileName);
				bwAsync->ReportProgress(Convert::ToInt32( count *  100 /( gc + 1)));
				
				}

					load_files(  bw, ProjectFolderPath, PathFolder,  bwAsync );

			
			}
				return bw;

		}




		void/*unsigned int*/ Save_file ( String^ SaveFile, TreeNode^ rootNode, BackgroundWorker^ bwAsync )
{

		unsigned int /*pos, len,*/ padding;


		BinaryWriter^ bw = gcnew BinaryWriter(File::Create(SaveFile)); 
		bw->BaseStream->Seek(0x60, SeekOrigin::Begin);
		count = 0;
		datalen = 0;
		//padding = 0;

		gc = rootNode->TreeView->GetNodeCount(true);//;
		String^ ProjectFolderPath = static_cast <String^> (rootNode->Tag);
		
//		SortedDictionary<String^, int>^ FW    = gcnew SortedDictionary<String^, int>;


		load_files ( bw, ProjectFolderPath, ProjectFolderPath,/* rootNode,*/ bwAsync /*FW, count_node_all*/);

	//add dummy file
		bw->Write( 0x3A424344 ); // DCB:
		bw->Write( 0x1 );
		bw->BaseStream->Seek(0x8, SeekOrigin::Current);

		bw->Write( STR2UCS(L"/Debug/pfsdummy"), 0, 0x800  );

		
		bw->BaseStream->Seek(0x0, SeekOrigin::End);
		padding = ALIGN(bw->BaseStream->Length, 0x4000) - bw->BaseStream->Length;
		if(0 != padding){
		array<unsigned char>^ buf2 = gcnew array<unsigned char>(padding);
		bw->Write( buf2, 0, buf2->Length );
		}
		

		bw->BaseStream->Seek(0x0, SeekOrigin::Begin);
		array<unsigned char>^ buf_1 = File::ReadAllBytes(rootNode->Tag + "\\name.bin");
		bw->Write( buf_1, 0, buf_1->Length );

		bw->BaseStream->Seek(0x20, SeekOrigin::Begin);

		bw->Write(datalen);
		bw->Write(padding);
		bw->Write(Convert::ToInt32(bw->BaseStream->Length));
		bw->Write(count + 1);
		bw->Write(datalen);

		bw->BaseStream->Seek(0x0, SeekOrigin::End);
		array<unsigned char>^ buf = File::ReadAllBytes(rootNode->Tag + "\\end.bin");
		bw->Write( buf, 0, buf->Length );
		
		bw->Close();

				array<unsigned char>^ buf_ = File::ReadAllBytes(SaveFile);
				String^ NameWave = GetString(buf_, buf_->Length - 1012);
				//String^ FileType = GetString(buf, buf->Length - 980);
//				bool Wave3 = false;
				if(NameWave == L"S8600" || NameWave->Substring(0,5) == L"S7230"  || NameWave->Substring(0,5) == L"S5750"){
//				Wave3 = true;


//				if(Wave3){
				array<unsigned char>^ buffer = gcnew array<unsigned char>(buf_->Length);//->ToArray();
				bool Wave3 = true;
				buffer = Encrypt ( buf_, Wave3, bwAsync );
				BinaryWriter^ bw2 = gcnew BinaryWriter(File::Create(SaveFile)); 
				bw2->BaseStream->Seek(0x0, SeekOrigin::Begin);
				bw2->Write(buffer, 0 , buffer->Length);
				bw2->Close();
				}




		autosign_file(SaveFile);

	//return true;
}


		array<unsigned char>^ Create_file ( TreeNode^ rootNode, BackgroundWorker^ bwAsync )
{

		unsigned int /*pos, len,*/ padding;

		MemoryStream^ stream = gcnew MemoryStream();
		BinaryWriter^ bw = gcnew BinaryWriter(stream); 
		bw->BaseStream->Seek(0x60, SeekOrigin::Begin);
		count = 0;
		datalen = 0;

		gc = rootNode->FirstNode->NextNode->TreeView->GetNodeCount(true);//;
		String^ ProjectFolderPath = static_cast <String^> (rootNode->FirstNode->NextNode->Tag);
		//String^ FolderPath = static_cast <String^> (rootNode->FirstNode->NextNode->Tag);
		
		load_files ( bw, ProjectFolderPath, ProjectFolderPath, bwAsync );

		//add dummy file
		bw->Write( 0x3A424344 ); // DCB:
		bw->Write( 0x1 );
		bw->BaseStream->Seek(0x8, SeekOrigin::Current);

		bw->Write( STR2UCS(L"/Debug/pfsdummy"), 0, 0x800  );

		
		bw->BaseStream->Seek(0x0, SeekOrigin::End);
		padding = ALIGN(bw->BaseStream->Length, 0x4000) - bw->BaseStream->Length;
		if(0 != padding){
		array<unsigned char>^ buf2 = gcnew array<unsigned char>(padding);
		bw->Write( buf2, 0, buf2->Length );
		}
		

		bw->BaseStream->Seek(0x0, SeekOrigin::Begin);
		array<unsigned char>^ buf_1 = File::ReadAllBytes(rootNode->FirstNode->NextNode->Tag + "\\name.bin");
		bw->Write( buf_1, 0, buf_1->Length );

		bw->BaseStream->Seek(0x20, SeekOrigin::Begin);

		bw->Write(datalen);
		bw->Write(padding);
		bw->Write(Convert::ToInt32(bw->BaseStream->Length));
		bw->Write(count + 1);
		bw->Write(datalen);

		
		bw->BaseStream->Seek(0x0, SeekOrigin::End);
		bw->Write(0x65666163);
		array<unsigned char>^ buf = File::ReadAllBytes(rootNode->FirstNode->NextNode->Tag + "\\end.bin");
		bw->Write( buf, 0, buf->Length );

//		autosign_buffer(stream);
		
		array<unsigned char>^ sfs_part = stream->ToArray();		
		bw->Close();
		stream->Close();

	return sfs_part;//stream;
}



/*		short RGB16(unsigned char red, unsigned char green, unsigned char blue)
			{
				short rgb16_value = (short) (((red >> 3) << 11) | ((green >> 2) << 5) | (blue >> 3));
				return rgb16_value;
			}

*//*
		Bitmap^ LoadBitmap(int width, int height, String^ path_rc2){

			Bitmap^ bmp = gcnew Bitmap(width, height, Imaging::PixelFormat::Format16bppRgb565);

		   // Lock the bitmap's bits.  
		   Rectangle rect = Rectangle(0,0,width,height);
		   System::Drawing::Imaging::BitmapData^ bmpData = bmp->LockBits( rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, bmp->PixelFormat );

		   // Get the address of the first line.
		   IntPtr ptr = bmpData->Scan0;

		   // Declare an array to hold the bytes of the bitmap.
		   // This code is specific to a bitmap with 24 bits per pixels.
			int bytes = Math::Abs(bmpData->Stride) * height;
			array<Byte>^rgbValues = gcnew array<Byte>(bytes);
			rgbValues = File::ReadAllBytes(path_rc2);

		   
		   System::Runtime::InteropServices::Marshal::Copy( rgbValues, 0, ptr, bytes );

		   // Unlock the bits.
		   bmp->UnlockBits( bmpData );

			return bmp;
			}

*/
		void DirectoryCopy(String^ begin_dir, String^ end_dir)
			{
				
				if (Directory::Exists(end_dir) != true)
                {
					Directory::CreateDirectory(end_dir + "\\");
                }

            //���� ���� �������� �����
            DirectoryInfo^ dir_inf = gcnew DirectoryInfo(begin_dir);
            //���������� ��� ���������� �����
			
			for each (DirectoryInfo^ dir in dir_inf->GetDirectories())
            {
                //��������� - ���� ���������� �� ����������, �� ������;
				if (Directory::Exists(end_dir + "\\" + dir->Name) != true)
                {
					Directory::CreateDirectory(end_dir + "\\" + dir->Name);
                }
                
                //�������� (���������� ��������� ����� � ������ ��� ��� ��-�� �����).
                DirectoryCopy(dir->FullName, end_dir + "\\" + dir->Name);
            }

            //���������� ������� � ����� ���������.
			for each (String^ file in Directory::GetFiles(begin_dir))
            {
                //���������� (��������) ��� ����� � ����������� - ��� ���� (�� � ������ "\").
                //String^ filik = file->Substring(file->LastIndexOf('\\'), file->Length - file->LastIndexOf('\\'));
				String^ filik = Path::GetFileName(file);
				//�������� ������ � ����������� �� ��������� � �������.
				File::Copy(file, end_dir + "\\" + filik, true);
            }
        }

};