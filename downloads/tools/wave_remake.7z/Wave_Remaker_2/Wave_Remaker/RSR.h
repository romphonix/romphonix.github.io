#pragma once

//#include "Form1.h"

namespace /*Wave_Remaker*/ImageUtils {


	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Collections::Generic;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
//	using namespace Wave_Remaker;
	
#define ALIGN(x,a) (((x)+(a)-1)&~((a)-1))


//	[StructLayout(LayoutKind::Sequential, Size=0x10)]
	ref struct PointerLanguages {

		unsigned int Len;               // 
		unsigned int Null;               // 
		unsigned int OffsetLanguages;     //
		unsigned int TypLanguages;     //
		
static	PointerLanguages^ GetPointerLanguages (BinaryReader^ br){

			PointerLanguages^ pointerLanguages = gcnew PointerLanguages;

			pointerLanguages->Len = br->ReadInt32();
			pointerLanguages->Null = br->ReadInt32();
			pointerLanguages->OffsetLanguages = br->ReadInt32();
			pointerLanguages->TypLanguages = br->ReadInt32();
			
			return pointerLanguages;
		}
static	PointerLanguages^ SetPointerLanguages (DataGridView^ dataGridView1, int v){

			PointerLanguages^ pointerLanguages = gcnew PointerLanguages;

			pointerLanguages->Len = 0x10;
			pointerLanguages->Null = 0x0;
			//pointerLanguages->OffsetLanguages = 12 + (v * 0x10);
			pointerLanguages->TypLanguages = Convert::ToInt32(dataGridView1->Columns[ v ]->Name);
			
			return pointerLanguages;
		}


	};



////////

	ref struct StringHeader {

		unsigned int NumberStrings;               // 
		unsigned int LenAllStrings;               // 
		unsigned int TypLanguages;     //
		array<unsigned int>^ offsetstring;/////////////
		array<unsigned char >^ strings;/////////////

static	StringHeader^ GetStringHeader (BinaryReader^ br){

		StringHeader^ stringHeader = gcnew StringHeader;
		stringHeader->NumberStrings = br->ReadInt32();     //
		stringHeader->LenAllStrings = br->ReadInt32();     //
		stringHeader->TypLanguages = br->ReadInt32();     //

		stringHeader->offsetstring = gcnew array<unsigned int>(stringHeader->NumberStrings);
		
		for(int i = 0; i < stringHeader->NumberStrings; i++){
			stringHeader->offsetstring[i] = br->ReadUInt32();
		}
			stringHeader->strings = gcnew array<unsigned char>(stringHeader->LenAllStrings);
			br->BaseStream->Read(stringHeader->strings, 0, stringHeader->strings->Length);
			return stringHeader;
}
static	StringHeader^ SetStringHeader (DataGridView^ dataGridView1, int v){
		
		StringHeader^ stringHeader = gcnew StringHeader;
		stringHeader->NumberStrings = dataGridView1->Rows->Count;
		stringHeader->TypLanguages = Convert::ToInt32(dataGridView1->Columns[ v ]->Name);
		
		System::Text::Encoding^ encoding = System::Text::Encoding::UTF8;
		System::Text::Encoder^ encoder = encoding->GetEncoder();
		MemoryStream^ stream = gcnew MemoryStream();// ����� ������� �����
		stringHeader->offsetstring = gcnew array<unsigned int>(stringHeader->NumberStrings);		

		for(int i=0;i<dataGridView1->RowCount;i++){

			array<wchar_t>^ ch = (static_cast<String^>(dataGridView1->Rows[i]->Cells[v]->Value))->ToCharArray();
			int byteCount = encoder->GetByteCount(ch, 0, ch->Length, true);
			array<unsigned char>^ bytes = gcnew array<unsigned char>(byteCount + 1);
			bool flush = true;
			int charsUsed; 
			int bytesUsed; 
			bool completed;
			encoder->Convert(ch, 0, ch->Length, bytes, 0, byteCount,flush,charsUsed,bytesUsed,completed);
			stringHeader->offsetstring[i] = 12 + (stringHeader->NumberStrings * 4) + stream->Position;
			stream->Write(bytes, 0, bytes->Length);
			//stringHeader->offsetstring[i] = 12 + (stringHeader->NumberStrings * 4) + bytes->Length;	
		}

		stringHeader->LenAllStrings = ALIGN(stream->Length, 4);               // 
		stringHeader->strings = stream->GetBuffer();
		Array::Resize(stringHeader->strings, stringHeader->LenAllStrings);

		stream->Close();

		return stringHeader;
}
	
	};

	ref struct RSR {

		unsigned int Magic;               // 
		unsigned int LenPointer;               // 
		unsigned int NumberLanguages;     //
		array<PointerLanguages^>^ ArrayPointers;
		array<StringHeader^>^ ArrayStringHeaders;

static	RSR^ GetRSRHeader (BinaryReader^ br){

		RSR^ rsrHeader = gcnew RSR;
		
		rsrHeader->Magic = br->ReadInt32();     //
		rsrHeader->LenPointer = br->ReadInt32();     //
		rsrHeader->NumberLanguages = br->ReadInt32();     //

		rsrHeader->ArrayPointers = gcnew array<PointerLanguages^>(rsrHeader->NumberLanguages);
		for(int i = 0; i < rsrHeader->NumberLanguages; i++){
			rsrHeader->ArrayPointers[i] = PointerLanguages::GetPointerLanguages(br);
		}
		
		rsrHeader->ArrayStringHeaders = gcnew array<StringHeader^>(rsrHeader->NumberLanguages);
		for(int i = 0; i < rsrHeader->NumberLanguages; i++){
			br->BaseStream->Seek(rsrHeader->ArrayPointers[i]->OffsetLanguages, SeekOrigin::Begin);
			rsrHeader->ArrayStringHeaders[i] = StringHeader::GetStringHeader(br);
		}

		return rsrHeader;
}
	
static	RSR^ SetRSRHeader (DataGridView^ dataGridView1){
		
		RSR^ rsrHeader = gcnew RSR;
		
		rsrHeader->Magic = 0x1;     //
		rsrHeader->LenPointer = 0x10;     //
		rsrHeader->NumberLanguages = dataGridView1->Columns->Count;     //
		rsrHeader->ArrayStringHeaders = gcnew array<StringHeader^>(rsrHeader->NumberLanguages);
		rsrHeader->ArrayPointers = gcnew array<PointerLanguages^>(rsrHeader->NumberLanguages);
		
		for(int i = 0; i < dataGridView1->ColumnCount; i++){
			rsrHeader->ArrayPointers[i] = PointerLanguages::SetPointerLanguages(dataGridView1, i);
		}
		
		for(int i = 0; i < rsrHeader->NumberLanguages; i++){
			rsrHeader->ArrayStringHeaders[i] = StringHeader::SetStringHeader(dataGridView1, i);
		}		
		
		
		
		return rsrHeader;
}	
	};




	void  ViewRSR(String^ PathRsr, DataGridView^ dataGridView1){

				array<unsigned char>^rsr = File::ReadAllBytes(PathRsr);

				MemoryStream^ myStreamDump = gcnew MemoryStream(rsr);
				BinaryReader^ br = gcnew BinaryReader(myStreamDump);
				br->BaseStream->Seek(0x0, SeekOrigin::Begin);
				RSR^ rSR = RSR::GetRSRHeader(br); 

//////////////
//				int count = rSR->NumberLanguages;
//				for(int i=0;i<count;i++){
//					if((rSR->ArrayPointers[i]->Len && rSR->ArrayPointers[i]->TypLanguages) == 0)
//						rSR->NumberLanguages--;
//				}
//////////////
			dataGridView1->ColumnCount = rSR->NumberLanguages;
			dataGridView1->ColumnHeadersVisible = true;

			 // Set the column header style.
			DataGridViewCellStyle ^ columnHeaderStyle = gcnew DataGridViewCellStyle;
			columnHeaderStyle->BackColor = Color::Aqua;
			columnHeaderStyle->Font = gcnew System::Drawing::Font( "Arial",10,FontStyle::Bold );
			columnHeaderStyle->Alignment = DataGridViewContentAlignment::MiddleCenter;			
			dataGridView1->ColumnHeadersDefaultCellStyle = columnHeaderStyle;
			dataGridView1->Columns[ 0 ]->Tag = PathRsr;//Convert::ToString(RSR->ArrayPointers[i]->TypLanguages);
			
			for(int i=0; i<rSR->NumberLanguages; i++){
				
				dataGridView1->Columns[ i ]->Name = Convert::ToString(rSR->ArrayPointers[i]->TypLanguages);
				dataGridView1->Columns[ i ]->SortMode = DataGridViewColumnSortMode::NotSortable;
			}
			dataGridView1->RowCount = rSR->ArrayStringHeaders[0]->NumberStrings;
				for(unsigned int a=0; a<dataGridView1->RowCount; a++){
					dataGridView1->Rows[a]->HeaderCell->Value = Convert::ToString(a);
				}


			for(unsigned int x=0; x<rSR->NumberLanguages; x++){

				array <String^>^string_array = gcnew array<String^>(rSR->ArrayStringHeaders[0]->NumberStrings);
				System::Text::Encoding^ encoding = System::Text::Encoding::UTF8;
				String^ string = encoding->GetString(rSR->ArrayStringHeaders[x]->strings);
				array<Char>^ delim = gcnew array<Char>{'\0'};
				string_array = string->Split(delim, StringSplitOptions::None);
				
				for(unsigned int l=0; l<rSR->ArrayStringHeaders[x]->NumberStrings; l++){
					dataGridView1[x,l]->Value = string_array[l];//RSR->ArrayStringHeaders[x]->strings[l];
				}
			}
			dataGridView1->Columns[ 0 ]->Frozen = true;
			
//////////				
	}


	void SaveRSR(DataGridView^ dataGridView1){

			RSR^ rsrHeader = RSR::SetRSRHeader(dataGridView1);
		
			BinaryWriter^ bw = gcnew BinaryWriter(File::Create(static_cast<String^>(dataGridView1->Columns[0]->Tag)));
			bw->BaseStream->Seek(0x0, SeekOrigin::Begin);

			bw->Write(rsrHeader->Magic);
			bw->Write(rsrHeader->LenPointer);
			bw->Write(rsrHeader->NumberLanguages);

			bw->BaseStream->Seek( 12 + (0x10 * rsrHeader->NumberLanguages) , SeekOrigin::Begin);

			for(int i=0; i<rsrHeader->NumberLanguages;i++){
			
				int offset = bw->BaseStream->Position;
				bw->Write(rsrHeader->ArrayStringHeaders[i]->NumberStrings);
				bw->Write(rsrHeader->ArrayStringHeaders[i]->LenAllStrings);
				bw->Write(rsrHeader->ArrayStringHeaders[i]->TypLanguages);
					for(int a=0; a<rsrHeader->ArrayStringHeaders[i]->NumberStrings;a++){
						bw->Write(offset + rsrHeader->ArrayStringHeaders[i]->offsetstring[a]);
					}
			bw->Write(rsrHeader->ArrayStringHeaders[i]->strings, 0, rsrHeader->ArrayStringHeaders[i]->LenAllStrings);
			
			bw->BaseStream->Seek( 12 + (0x10 * i) , SeekOrigin::Begin);
			bw->Write(rsrHeader->ArrayPointers[i]->Len);
			bw->Write(rsrHeader->ArrayPointers[i]->Null);
			bw->Write(offset);
			bw->Write(rsrHeader->ArrayPointers[i]->TypLanguages);
			bw->BaseStream->Seek( 0 , SeekOrigin::End);
			
			}
			bw->Close();

	}
}