#pragma once


#include <memory.h>



namespace ImageUtils
{

//
//	MAX_REPEAT_WORD		CONTINUE_REPEAT(0)				MAX_OFFSET
//		1111					1					111		1111 1111
//
//		  R					 G			GO TO COMMAND			 B
//		11111				11111			1					11111
//


#define MAX_BUFF_LEN							0xFFE // 0xFFE == 4094 byte ������������ ����� ������ � ������
#define MAX_REPEAT								0xF // ������������ ����������

#define SET_NO_REPEAT(data)				(unsigned short)(data) = (data | (unsigned short)0x800);
#define SET_REPEAT(data, repeat)				(unsigned short)(data) = (data | (unsigned short)(repeat<<0xC));
#define SET_OFFSET(data,offset)					(unsigned short)(data) = (data | (unsigned short)((offset<<0x5)>>5));					

#define SET_GOTO_COMMAND(data)					(unsigned short)(data) = (data | (unsigned short)0x20);
#define SET_GOTO_DATA(data)						(unsigned short)(data) = (data &~(unsigned short)0x20);


unsigned char *FindLZ(unsigned char *src, unsigned int len_in_data, unsigned char *start_buff, unsigned int &counts)
{
	long maxcount = 0, count;
	unsigned char *maxp = start_buff-2;
	for (unsigned char *p = start_buff-2; ((start_buff - p) <= MAX_BUFF_LEN && p >= src  && start_buff-2 < src + len_in_data); p-=2)
	{
					count = 0;
					bool continues= false;
					do{
						if(	HALF( start_buff, count<<1) == HALF(p, count<<1) && HALF( start_buff, (count+1)<<1) ==	HALF(p, (count+1)<<1))	{
							count+=2;
						}else{
							continues= true;
						}
					}while(!continues && start_buff + ((count+1)<<1) < src + len_in_data);
					
					continues= false;
					do{
						if(HALF( start_buff, count<<1)	==	HALF(p, count<<1))	{
							count++;
						}else{
							continues= true; 
						}
					}while(!continues && start_buff + (count<<1) < src + len_in_data);
					
					if (count > maxcount){
						maxp = p;
						maxcount = count; 
					}

	
	}
	counts = maxcount;
	return maxp;
}



array<unsigned char>^ LZ16Encode( unsigned char *in_data, unsigned int len_in_data, BackgroundWorker^ bwAsync)
{
	
	unsigned int out_data_count=0, out_command_count=0, repeat_count=0, count=0, count_next=0, offset=0;
	unsigned short data, command;
	unsigned char *curent_pointer, *p;
	unsigned char *out_data = (unsigned char *)malloc ( len_in_data );
	unsigned char *out_command = (unsigned char *)malloc ( len_in_data );

		curent_pointer = in_data;
	
		while (curent_pointer-in_data < len_in_data )
	{
		p = FindLZ(in_data, len_in_data, curent_pointer, count);
		
		if (count < 2 ){ 

			FindLZ(in_data, len_in_data, curent_pointer+2, count_next);

			data = HALF(curent_pointer, 0);	
				
			if(count_next < 2){
				SET_GOTO_DATA(data); // ������������� ������ ��� � 0
			}else{
				SET_GOTO_COMMAND(data);
			}
				SET_HALF(out_data, out_data_count<<1, data);
					curent_pointer +=2;
						out_data_count++;

		}else{
		repeat_count = count;
			offset = (curent_pointer - p)>>1;
				curent_pointer += count<<1;

			while(repeat_count > 0){	
				SET_OFFSET(command,offset);///////
					if(repeat_count > MAX_REPEAT){
						if(repeat_count - MAX_REPEAT == 1){
							SET_REPEAT(command, MAX_REPEAT - 1);
								repeat_count-=(MAX_REPEAT - 1);
						}else{
							SET_REPEAT(command, MAX_REPEAT);
								repeat_count-=MAX_REPEAT;
						}
					}else{
						SET_REPEAT(command, repeat_count);
							FindLZ(in_data, len_in_data, curent_pointer, count_next);
								if(count_next<2)
									SET_NO_REPEAT(command);	//������ ���� ��������� ������ �� ����� ����������
										repeat_count=0;
					}
				SET_HALF(out_command, out_command_count<<1, (command>>8 |command<<8)&0xFFFF );
					out_command_count++;
						command=0;
			}//while

		}
			
		bwAsync->ReportProgress(Convert::ToInt32(  (curent_pointer - in_data) *  100 / len_in_data));

	}//while


	unsigned int len_offset;
	offset = out_command_count<<1;
	if(offset < 0xFFFF){
	offset = (offset<<8 | offset>>8) & 0xFFFF;
	len_offset = 0x2;
	}else{
	offset = ((((offset<<8) | 0x100 )& 0xFF00 | (offset>>8)& 0xFF) )  | (( offset & 0xFF0000)>>0xF)<<0x10;
	len_offset = 0x4;
	}
	const char * header = {"compress LZ"};
	unsigned char *encoded_data = (unsigned char *)malloc ( 0x10 + len_offset + (out_data_count<<1) +  (out_command_count<<1));


	memcpy( encoded_data, (const void*)header, 0xC);
	memcpy( encoded_data + 0x10 + len_offset, (const void*)out_command, out_command_count<<1);
	memcpy( encoded_data + 0x10 + len_offset + (out_command_count<<1), (const void*)out_data, out_data_count<<1);
	if(len_offset == 0x2){
		SET_HALF(encoded_data, 0x10, offset);
	}else{
		SET_WORD(encoded_data, 0x10, offset);
	}


	array<unsigned char>^ compress = gcnew array<unsigned char>( 0x10 + len_offset + (out_data_count<<1) +  (out_command_count<<1) );
	Marshal::Copy(IntPtr(encoded_data), compress, 0,  compress->Length);

	free(out_data);
	free(out_command);
	free(encoded_data);

	return compress;
}




void IMG_Compress( String^ path, String^ SaveFileName, BackgroundWorker^ bwAsync){

			Bitmap^ bmp = gcnew Bitmap(path);
				
			if(bmp->PixelFormat != Imaging::PixelFormat::Format24bppRgb 
				&& bmp->PixelFormat != Imaging::PixelFormat::Format32bppArgb
				&& bmp->PixelFormat != Imaging::PixelFormat::Format32bppRgb){
					
			MessageBox::Show("Pixel format is not correct", "ERROR",  MessageBoxButtons::OK, MessageBoxIcon::Error);
				
					return;
				}//else if(bmp->Height != 800 || bmp->Width != 480){
//				
//					return;
//				}
			
			Rectangle rect = Rectangle(0,0,bmp->Width,bmp->Height);
					System::Drawing::Imaging::BitmapData^ bmpData = bmp->LockBits( rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, bmp->PixelFormat );
						IntPtr ptr = bmpData->Scan0;
							unsigned int len = Math::Abs(bmpData->Stride) * bmp->Height;
							
			unsigned char *src = (unsigned char *)malloc ( len );
				memcpy( src, (const void*)(ptr), len);
					unsigned char *dst = (unsigned char *)malloc ( bmp->Width * bmp->Height * 2 );
					
					unsigned int counter = 0;

					if(bmp->PixelFormat == Imaging::PixelFormat::Format24bppRgb){
					
					for (int x = 0; x < len; x += 3)
					{
						Byte red = BYTE(src,x);
						Byte green = BYTE(src,x + 1);
						Byte blue = BYTE(src,x + 2);

						SET_HALF(dst, counter, RGB16(blue/*red*/, green, red/*blue*/));
						counter+=2;
					}
					
					}else if(bmp->PixelFormat == Imaging::PixelFormat::Format32bppRgb || bmp->PixelFormat == Imaging::PixelFormat::Format32bppArgb){
					for (int x = 0; x < len; x += 4)
					{
						Byte red = BYTE(src,x);
						Byte green = BYTE(src,x + 1);
						Byte blue = BYTE(src,x + 2);

						SET_HALF(dst, counter, RGB16(blue/*red*/, green, red/*blue*/));
						counter+=2;
					}

					}

					bmp->UnlockBits( bmpData );

					array<unsigned char>^ Encode = LZ16Encode(dst, bmp->Width * bmp->Height * 2, bwAsync);

					BinaryWriter^ bw = gcnew BinaryWriter(File::Create(SaveFileName));
					bw->BaseStream->Write(Encode, 0, Encode->Length);
					bw->Close();


					free( src );
					free( dst );
}




void Encode_Folder(String^ OpenFolder, String^ SaveFolder, String^ ext, BackgroundWorker^ bwAsync){

				unsigned int count=0;
				unsigned int files_count = Directory::GetFiles(OpenFolder, "*" + ext)->Length;
				for each(String^ PathFile in Directory::GetFiles(OpenFolder, "*" + ext)){	
				String^ FileName = Path::GetFileNameWithoutExtension(PathFile);
				String^ SavePath = SaveFolder + L"\\" + FileName + L".img";
				//Save_Image(PathFile, SavePath, bwAsync);
				IMG_Compress( PathFile, SavePath,  bwAsync);				
				count++;
				bwAsync->ReportProgress(Convert::ToInt32( count *  100 /files_count));
				
				}

}










}