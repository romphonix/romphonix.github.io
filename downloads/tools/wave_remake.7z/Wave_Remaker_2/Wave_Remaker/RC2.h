#pragma once

namespace ImageUtils {


	using namespace System;
//	using namespace System::ComponentModel;
//	using namespace System::Collections;
	using namespace System::Windows::Forms;
//	using namespace System::Data;
//	using namespace System::Drawing;
//	using namespace System::IO;
//	using namespace System::Collections::Generic;
//	using namespace System::Runtime::InteropServices;

	#define ALIGN(x,a) (((x)+(a)-1)&~((a)-1))


		 void WriteRC2(/*DumpArgumentSave^ dump_argument,*/String^ SaveFileName, String^ Path, String^ pathdirectory, int debug_level){

			BinaryWriter^ bw = gcnew BinaryWriter(File::Create(/*dump_argument->*/SaveFileName)); 
			bw->BaseStream->Seek(0x0, SeekOrigin::Begin);
			array<unsigned char>^ buf_1 = File::ReadAllBytes(/*dump_argument->TopNode->Tag*/Path + "\\name.bin");
			bw->Write( buf_1, 0, buf_1->Length );

			for each(String^ path in Directory::GetFiles(/*dump_argument->*/pathdirectory/*   AppPath + DIR_PROJECT + FileNamerc2*/, "*.")) {

			FileInfo^ fi = gcnew FileInfo(path);
			array<String^>^ delim = gcnew array<String^>(2){" ","x"};
			array<String^>^ split = fi->Name->Split(delim, StringSplitOptions::RemoveEmptyEntries);
			int offset = UInt32::Parse(split[0], System::Globalization::NumberStyles::HexNumber);

			if(offset != bw->BaseStream->Position)
			bw->Write(0xFFFF0000);

			array<unsigned char>^ buf = File::ReadAllBytes(path);
			bw->Write( buf, 0, buf->Length );

			}

				bw->BaseStream->Seek(0x0, SeekOrigin::End);
				array<unsigned char>^ buf = File::ReadAllBytes(/*dump_argument->TopNode->Tag*/pathdirectory + "\\end.bin");
				bw->Write( buf, 0, buf->Length );
				
				bw->BaseStream->Seek(0x8, SeekOrigin::Begin);
				bw->Write(debug_level);
				bw->Close();

				autosign_file(/*dump_argument->*/SaveFileName);


		 }



		unsigned int dump_rc2 ( BinaryReader^ br, String^ foldername,  BackgroundWorker^ bwAsync1 )
{
		//int len;

						int Pos = br->BaseStream->Position;
						br->BaseStream->Seek(0x10, SeekOrigin::Begin);

/*						if(br->ReadInt32() != 0x40464544 ){

						br->BaseStream->Seek(Pos, SeekOrigin::Begin);

						array<unsigned char>^ CryptBuff = gcnew array<unsigned char> (br->BaseStream->Length - Pos);
						br->Read(CryptBuff,0,br->BaseStream->Length - Pos);
						array<unsigned char>^DecryptBuff = DecryptApps_1( CryptBuff, bwAsync1 );
						br->Close();
						Stream^ stream = gcnew MemoryStream(DecryptBuff);
						BinaryReader^ br1 = gcnew BinaryReader(stream);

		while ( br1->ReadInt32() != 0x5A5B5C5D ) // DCB:
		{
		}
		int start_header = br1->BaseStream->Position - 4;

		br1->ReadInt32();
		int len   = br1->ReadInt32 ();
		br1->BaseStream->Seek(0, SeekOrigin::Begin);
		array<unsigned char>^ bufname = gcnew array<unsigned char>(len);
		br1->Read(bufname,0,len);
		BinaryWriter^ bw1 = gcnew BinaryWriter(File::Create(String::Concat(foldername, L"\\name.bin"))); 
		bw1->BaseStream->Write(bufname,0,len);
		bw1->Close();


		br1->BaseStream->Seek(start_header + 0xc, SeekOrigin::Begin);
		int start_1_screen = len;
		int len_1_screen = br1->ReadInt32 ();
		
		br1->BaseStream->Seek(start_header + 0x28, SeekOrigin::Begin);
		int width_1_screen = br1->ReadInt32 ();
		int height_1_screen = br1->ReadInt32 ();

////		
		br1->BaseStream->Seek(start_header + 0x66C, SeekOrigin::Begin);
		int start_2_screen = br1->ReadInt32 ();
		int len_2_screen = br1->ReadInt32 ();
		
		br1->BaseStream->Seek(start_header + 0x28, SeekOrigin::Begin);
		int width_2_screen = br1->ReadInt32 ();
		int height_2_screen = br1->ReadInt32 ();

////
		br1->BaseStream->Seek(start_header + 0x878, SeekOrigin::Begin);
		int start_3_screen = br1->ReadInt32 ();
		int len_3_screen = br1->ReadInt32 ();
		
		br1->BaseStream->Seek(start_header + 0x88c, SeekOrigin::Begin);
		int width_3_screen = br1->ReadInt32 ();
		int height_3_screen = br1->ReadInt32 ();

////
		br1->BaseStream->Seek(start_header + 0x894, SeekOrigin::Begin);
		int start_4_screen = br1->ReadInt32 ();
		int len_4_screen = br1->ReadInt32 ();
		
		br1->BaseStream->Seek(start_header + 0x8A8, SeekOrigin::Begin);
		int width_4_screen = br1->ReadInt32 ();
		int height_4_screen = br1->ReadInt32 ();

//bwAsync1->ReportProgress(50);
					bwAsync1->ReportProgress(Convert::ToInt32(  br1->BaseStream->Position *  100 / br1->BaseStream->Length));

					br1->BaseStream->Seek(start_1_screen, SeekOrigin::Begin);
					array<unsigned char>^ buf_1_screen = gcnew array<unsigned char>(len_1_screen);
					br1->Read(buf_1_screen, 0, len_1_screen);
					BinaryWriter^ bw3 = gcnew BinaryWriter(File::Create(String::Concat(foldername, L"\\" + String::Format("{0:x8}  {1:d}x{2:d}" ,start_1_screen, width_1_screen, height_1_screen)))); 
					bw3->BaseStream->Write(buf_1_screen, 0, len_1_screen);
					bw3->Close();
		
					bwAsync1->ReportProgress(Convert::ToInt32(  br1->BaseStream->Position *  100 / br1->BaseStream->Length));

					br1->BaseStream->Seek(start_2_screen, SeekOrigin::Begin);
					array<unsigned char>^ buf_2_screen = gcnew array<unsigned char>(len_2_screen);
					br1->Read(buf_2_screen, 0, len_2_screen);
					BinaryWriter^ bw4 = gcnew BinaryWriter(File::Create(String::Concat(foldername, L"\\" + String::Format("{0:x8}  {1:d}x{2:d}" ,start_2_screen, width_2_screen, height_2_screen)))); 
					bw4->BaseStream->Write(buf_2_screen, 0, len_2_screen);
					bw4->Close();
		
					bwAsync1->ReportProgress(Convert::ToInt32(  br1->BaseStream->Position *  100 / br1->BaseStream->Length));

					br1->BaseStream->Seek(start_3_screen, SeekOrigin::Begin);
					array<unsigned char>^ buf_3_screen = gcnew array<unsigned char>(len_3_screen);
					br1->Read(buf_3_screen, 0, len_3_screen);
					BinaryWriter^ bw5 = gcnew BinaryWriter(File::Create(String::Concat(foldername, L"\\" + String::Format("{0:x8}  {1:d}x{2:d}" ,start_3_screen, width_3_screen, height_3_screen)))); 
					bw5->BaseStream->Write(buf_3_screen, 0, len_3_screen);
					bw5->Close();

					bwAsync1->ReportProgress(Convert::ToInt32(  br1->BaseStream->Position *  100 / br1->BaseStream->Length));

					br1->BaseStream->Seek(start_4_screen, SeekOrigin::Begin);
					array<unsigned char>^ buf_4_screen = gcnew array<unsigned char>(len_4_screen);
					br1->Read(buf_4_screen, 0, len_4_screen);
					BinaryWriter^ bw6 = gcnew BinaryWriter(File::Create(String::Concat(foldername, L"\\" + String::Format("{0:x8}  {1:d}x{2:d}" ,start_4_screen, width_4_screen, height_4_screen)))); 
					bw6->BaseStream->Write(buf_4_screen, 0, len_4_screen);
					bw6->Close();

					bwAsync1->ReportProgress(Convert::ToInt32(  br1->BaseStream->Position *  100 / br1->BaseStream->Length));

					br1->BaseStream->Seek( -4, SeekOrigin::End);
					int signature_offset;

				for (int n = 0; n < br1->BaseStream->Length / 4; n++){
					
					if(0xABCDABCD == br1->ReadInt32()){
					signature_offset = Convert::ToInt32(br1->BaseStream->Position) - 4;	
					br1->BaseStream->Seek(-4, SeekOrigin::Current);
					array<unsigned char>^ bufname_1 = gcnew array<unsigned char>(0x400);
					br1->Read(bufname_1,0,0x400);
					BinaryWriter^ bw2 = gcnew BinaryWriter(File::Create(String::Concat(foldername, L"\\end.bin"))); 
					bw2->BaseStream->Write(bufname_1,0,0x400);
					bw2->Close();

					break;
					//continue;
					}
					br1->BaseStream->Seek( -8, SeekOrigin::Current);
				}


				if((br1->BaseStream->Length - signature_offset) != 0x400){
				System::Windows::Forms::MessageBox::Show("Error len futter.","ERROR",MessageBoxButtons::OK, MessageBoxIcon::Error);
				return false;
				}

				br1->Close();
				bwAsync1->ReportProgress( 0 );

				//Form1::_OpenProject_rc2();
				
				
				return true;



						}else{
	*/					
		br->BaseStream->Seek(Pos, SeekOrigin::Begin);


		while ( br->ReadInt32() != 0x5A5B5C5D ) // DCB:
		{
		}
		int start_header = br->BaseStream->Position - 4;

		br->ReadInt32();
		int len   = br->ReadInt32 ();
		br->BaseStream->Seek(0, SeekOrigin::Begin);
		array<unsigned char>^ bufname = gcnew array<unsigned char>(len);
		br->Read(bufname,0,len);
		BinaryWriter^ bw1 = gcnew BinaryWriter(File::Create(String::Concat(foldername, L"\\name.bin"))); 
		bw1->BaseStream->Write(bufname,0,len);
		bw1->Close();


		br->BaseStream->Seek(start_header + 0xc, SeekOrigin::Begin);
		int start_1_screen = len;
		int len_1_screen = br->ReadInt32 ();
		
		br->BaseStream->Seek(start_header + 0x28, SeekOrigin::Begin);
		int width_1_screen = br->ReadInt32 ();
		int height_1_screen = br->ReadInt32 ();

////		
		br->BaseStream->Seek(start_header + 0x66C, SeekOrigin::Begin);
		int start_2_screen = br->ReadInt32 ();
		int len_2_screen = br->ReadInt32 ();
		
		br->BaseStream->Seek(start_header + 0x28, SeekOrigin::Begin);
		int width_2_screen = br->ReadInt32 ();
		int height_2_screen = br->ReadInt32 ();

////
		br->BaseStream->Seek(start_header + 0x878, SeekOrigin::Begin);
		int start_3_screen = br->ReadInt32 ();
		int len_3_screen = br->ReadInt32 ();
		
		br->BaseStream->Seek(start_header + 0x88c, SeekOrigin::Begin);
		int width_3_screen = br->ReadInt32 ();
		int height_3_screen = br->ReadInt32 ();

////
		br->BaseStream->Seek(start_header + 0x894, SeekOrigin::Begin);
		int start_4_screen = br->ReadInt32 ();
		int len_4_screen = br->ReadInt32 ();
		
		br->BaseStream->Seek(start_header + 0x8A8, SeekOrigin::Begin);
		int width_4_screen = br->ReadInt32 ();
		int height_4_screen = br->ReadInt32 ();

//bwAsync1->ReportProgress(50);
					bwAsync1->ReportProgress(Convert::ToInt32(  br->BaseStream->Position *  100 / br->BaseStream->Length));

					br->BaseStream->Seek(start_1_screen, SeekOrigin::Begin);
					array<unsigned char>^ buf_1_screen = gcnew array<unsigned char>(len_1_screen);
					br->Read(buf_1_screen, 0, len_1_screen);
					BinaryWriter^ bw3 = gcnew BinaryWriter(File::Create(String::Concat(foldername, L"\\" + String::Format("{0:x8}  {1:d}x{2:d}" ,start_1_screen, width_1_screen, height_1_screen)))); 
					bw3->BaseStream->Write(buf_1_screen, 0, len_1_screen);
					bw3->Close();
		
					bwAsync1->ReportProgress(Convert::ToInt32(  br->BaseStream->Position *  100 / br->BaseStream->Length));

					br->BaseStream->Seek(start_2_screen, SeekOrigin::Begin);
					array<unsigned char>^ buf_2_screen = gcnew array<unsigned char>(len_2_screen);
					br->Read(buf_2_screen, 0, len_2_screen);
					BinaryWriter^ bw4 = gcnew BinaryWriter(File::Create(String::Concat(foldername, L"\\" + String::Format("{0:x8}  {1:d}x{2:d}" ,start_2_screen, width_2_screen, height_2_screen)))); 
					bw4->BaseStream->Write(buf_2_screen, 0, len_2_screen);
					bw4->Close();
		
					bwAsync1->ReportProgress(Convert::ToInt32(  br->BaseStream->Position *  100 / br->BaseStream->Length));

					br->BaseStream->Seek(start_3_screen, SeekOrigin::Begin);
					array<unsigned char>^ buf_3_screen = gcnew array<unsigned char>(len_3_screen);
					br->Read(buf_3_screen, 0, len_3_screen);
					BinaryWriter^ bw5 = gcnew BinaryWriter(File::Create(String::Concat(foldername, L"\\" + String::Format("{0:x8}  {1:d}x{2:d}" ,start_3_screen, width_3_screen, height_3_screen)))); 
					bw5->BaseStream->Write(buf_3_screen, 0, len_3_screen);
					bw5->Close();

					bwAsync1->ReportProgress(Convert::ToInt32(  br->BaseStream->Position *  100 / br->BaseStream->Length));

					br->BaseStream->Seek(start_4_screen, SeekOrigin::Begin);
					array<unsigned char>^ buf_4_screen = gcnew array<unsigned char>(len_4_screen);
					br->Read(buf_4_screen, 0, len_4_screen);
					BinaryWriter^ bw6 = gcnew BinaryWriter(File::Create(String::Concat(foldername, L"\\" + String::Format("{0:x8}  {1:d}x{2:d}" ,start_4_screen, width_4_screen, height_4_screen)))); 
					bw6->BaseStream->Write(buf_4_screen, 0, len_4_screen);
					bw6->Close();

					bwAsync1->ReportProgress(Convert::ToInt32(  br->BaseStream->Position *  100 / br->BaseStream->Length));

					br->BaseStream->Seek( -4, SeekOrigin::End);
					int signature_offset;

				for (int n = 0; n < br->BaseStream->Length / 4; n++){
					
					if(0xABCDABCD == br->ReadInt32()){
					signature_offset = Convert::ToInt32(br->BaseStream->Position) - 4;	
					br->BaseStream->Seek(-4, SeekOrigin::Current);
					array<unsigned char>^ bufname_1 = gcnew array<unsigned char>(0x400);
					br->Read(bufname_1,0,0x400);
					BinaryWriter^ bw2 = gcnew BinaryWriter(File::Create(String::Concat(foldername, L"\\end.bin"))); 
					bw2->BaseStream->Write(bufname_1,0,0x400);
					bw2->Close();

					break;
					}
					br->BaseStream->Seek( -8, SeekOrigin::Current);
				}


				if((br->BaseStream->Length - signature_offset) != 0x400){
				System::Windows::Forms::MessageBox::Show("Error len futter.","ERROR",MessageBoxButtons::OK, MessageBoxIcon::Error);
				return false;
				}

				br->Close();
				bwAsync1->ReportProgress( 100 );

				
				return true;
				//}

	}

		void OpenProject_rc2(String^ ProjectFolderPath, TreeNode^ rootNode )
		{

						
				for each(String^ PathFile in Directory::GetFiles(ProjectFolderPath, "*.")){	
				String^ FileName = PathFile->Replace(Path::GetDirectoryName(PathFile) + "\\", "");
				TreeNode^ NodeFiles= gcnew TreeNode(FileName,2,2);
				NodeFiles->Tag = PathFile;
				rootNode->Nodes->Add( NodeFiles);
				}

		}



		short RGB16(unsigned char red, unsigned char green, unsigned char blue)
			{
				short rgb16_value = (short) (((red >> 3) << 11) | ((green >> 2) << 5) | (blue >> 3));
				return rgb16_value;
			}




		Bitmap^ LoadBitmap(int width, int height, String^ path_rc2){

			Bitmap^ bmp = gcnew Bitmap(width, height, Imaging::PixelFormat::Format16bppRgb565);

		   // Lock the bitmap's bits.  
		   Rectangle rect = Rectangle(0,0,width,height);
		   System::Drawing::Imaging::BitmapData^ bmpData = bmp->LockBits( rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, bmp->PixelFormat );

		   // Get the address of the first line.
		   IntPtr ptr = bmpData->Scan0;

		   // Declare an array to hold the bytes of the bitmap.
		   // This code is specific to a bitmap with 24 bits per pixels.
			int bytes = Math::Abs(bmpData->Stride) * height;
			array<Byte>^rgbValues = gcnew array<Byte>(bytes);
			rgbValues = File::ReadAllBytes(path_rc2);

		   
		   System::Runtime::InteropServices::Marshal::Copy( rgbValues, 0, ptr, bytes );

		   // Unlock the bits.
		   bmp->UnlockBits( bmpData );

			return bmp;
			}


}