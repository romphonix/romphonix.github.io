#pragma once

#include <memory.h>



namespace ImageUtils
{


	
	unsigned int/*void*/ LZ16_decompress(unsigned char* src, unsigned char* dst){


				unsigned int count_in1=0, count_in2=0, count_write=0;
				unsigned char *src1, *src2, *pRead;
				unsigned int data=0, count=0;

				unsigned int offset = (GET_HALF(src, 0)<<0x8 | GET_HALF(src, 0)>>0x8) & 0xFFFF;
				src2 = src + 2 + offset;
				src1 = src+2;
				
				if(offset & 1 != 0){ //���� ���������� ������� ���, �.�. ����� �������� �����
					
					offset = (offset & 0xFFFE) | ( GET_BYTE(src, 2) << 15 ) | ( GET_BYTE(src, 3) << 23);
					src2 = src + 4 + offset;
					src1 = src + 4;
				}

				
					
					while(count_in1 < offset){

					unsigned short  a = BYTE(src1, count_in1);

					if(a>>4 != 0 ){
					
					unsigned short  b = BYTE(src1, (count_in1+1));
					unsigned int off = (count_write - (unsigned int)((a & 7)<<8 | b));
					count = 0;

						while(count < (a>>4)){
							SET_HALF( dst, count_write<<1,	GET_HALF(/*pRead*/dst, (off + count)<<1));
							count_write++; count++;
						}
					
					}else{	
						
						data = GET_HALF(src2, (count_in2<<1));
						SET_HALF( dst, (count_write<<1), data );
						count_write++; count_in2++;
					}
					
					count_in1+=2;
					
					}//while(count_in1 < offset);
				
						//data = GET_HALF(src2, (count_in2<<1));
						//SET_HALF( dst, (count_write<<1)-2, data );
						//count_write++; count_in2++;

						return count_write;
}



	void Rbm_LZ16_View(unsigned int Width, unsigned int Height, array<unsigned char>^ data, PictureBox^ pictureBox1){

		//unsigned int length = data->Length;
		unsigned char *src = (unsigned char *)malloc ( data->Length );
		
		Marshal::Copy(data, 0, IntPtr(src), data->Length);

		unsigned char *dst = (unsigned char *)malloc ( Width * Height * 2 );
		unsigned int len = LZ16_decompress( src, dst);		
		
		int f = Width * Height;
		if(len!= f){
int j =0;
		}

		Bitmap^ bmp = gcnew Bitmap(Width, Height, Imaging::PixelFormat::Format16bppRgb565);
				Rectangle rect = Rectangle(0,0,Width,Height);
					System::Drawing::Imaging::BitmapData^ bmpData = bmp->LockBits( rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, bmp->PixelFormat );
						IntPtr ptr = bmpData->Scan0;
							int bytes = Math::Abs(bmpData->Stride) * Height;
								memcpy( (void*)(ptr), dst, bytes);
					
						bmp->UnlockBits( bmpData );
						pictureBox1->SizeMode = PictureBoxSizeMode::CenterImage;
					pictureBox1->Image = dynamic_cast<Image^>(bmp);

			free( src );
			free ( dst );



	}














	}