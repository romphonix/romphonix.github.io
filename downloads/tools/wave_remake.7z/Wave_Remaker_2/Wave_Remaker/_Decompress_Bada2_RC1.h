#pragma once

#include "SEED_Crypto.h"
#include "Decompress_Bada2.h"


namespace ImageUtils {


/*

	void copy_2_bytes_from_offset_out_stream_RC1(MemoryStream^ StreamBlock3){
							int offset = G_R3;
							StreamBlock3->Seek(-offset, SeekOrigin::Current);
							unsigned short a = StreamBlock3->ReadByte();
							StreamBlock3->Seek(0, SeekOrigin::End);
							StreamBlock3->WriteByte(a);
							StreamBlock3->Seek(-offset, SeekOrigin::Current);
							a = StreamBlock3->ReadByte();
							StreamBlock3->Seek(0, SeekOrigin::End);
							StreamBlock3->WriteByte(a);
	}
	void copy_2_bytes_from_compressed_stream_RC1(MemoryStream^ StreamBlock3, array<unsigned char>^ block_3){
							StreamBlock3->WriteByte(block_3[G_Offset]);
							StreamBlock3->WriteByte(block_3[G_Offset+1]);
							G_Offset+=2;
	}
	void copy_2_bytes_with_xor_RC1(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3){
					int offset = G_R3;
					int c = difftable[StreamBlock2->ReadByte() ];
					StreamBlock3->Seek( -offset, SeekOrigin::Current);
					unsigned short a = StreamBlock3->ReadByte();
					StreamBlock3->Seek(0, SeekOrigin::End);
					StreamBlock3->WriteByte(a ^ (c & 0xFF));
					StreamBlock3->Seek( -offset, SeekOrigin::Current);
					a = StreamBlock3->ReadByte();
					StreamBlock3->Seek(0, SeekOrigin::End);
					StreamBlock3->WriteByte(a ^ (c >> 8));
	}

	
	void Case_0_decompress2(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
					G_CountBit--;// 
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}
					G_CountBit--;// 
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}

					if((G_BitOperation & ext) != 0){
					G_CountBit--;// 
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
							G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
							G_Offset+=2;
						}else{//���� ����� ��� == 1
							G_R3 = StreamBlock2->ReadByte();
						}
					}

					G_CountBit--;// 
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}
					G_CountBit--;// 
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}

	}
	void Case_1_decompress2(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
					G_CountBit--;// 
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}
					G_CountBit--;// 
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}

					if((G_BitOperation & ext) != 0){
					G_CountBit--;// 
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
							G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
							G_Offset+=2;
						}else{//���� ����� ��� == 1
							G_R3 = StreamBlock2->ReadByte();
						}
					}

					G_CountBit--;// 
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}
							copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
	}

	void Case_2_decompress2(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
					G_CountBit--;// 
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}
					G_CountBit--;// 
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}

					if((G_BitOperation & ext) != 0){
					G_CountBit--;// 
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
							G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
							G_Offset+=2;
						}else{//���� ����� ��� == 1
							G_R3 = StreamBlock2->ReadByte();
						}
					}

					copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
					
					G_CountBit--;// 
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}
	}	
	
	
	void Case_3_decompress2(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
					G_CountBit--;// 
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}
					G_CountBit--;// 
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}

					if((G_BitOperation & ext) != 0){
					G_CountBit--;// 
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
							G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
							G_Offset+=2;
						}else{//���� ����� ��� == 1
							G_R3 = StreamBlock2->ReadByte();
						}
					}
					copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
					copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
	}	
///	
	void Case_4_decompress2(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
					G_CountBit--;//
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}
					copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);

					if((G_BitOperation & ext) != 0){
						G_CountBit--;// 
							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
								G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
								G_Offset+=2;
							}else{//
								G_R3 = StreamBlock2->ReadByte();
							}
					}
					G_CountBit--;//
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}
					G_CountBit--;//
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}
	}
/////
	void Case_5_decompress2(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
					G_CountBit--;//
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}
					copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);

					if((G_BitOperation & ext) != 0){
						G_CountBit--;// 
							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
								G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
								G_Offset+=2;
							}else{//
								G_R3 = StreamBlock2->ReadByte();
							}
					}
					G_CountBit--;// 
							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
							}
						copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
						
	}
//////
	void Case_6_decompress2(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
					G_CountBit--;//
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}
					copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);

					if((G_BitOperation & ext) != 0){
						G_CountBit--;// 
							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
								G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
								G_Offset+=2;
							}else{//
								G_R3 = StreamBlock2->ReadByte();
							}
					}
						
					copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
						G_CountBit--;// 
							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
							}
	}
//////
	void Case_7_decompress2(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
					G_CountBit--;//
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}
						copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);

					if((G_BitOperation & ext) != 0){
						G_CountBit--;// 
							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
								G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
								G_Offset+=2;
							}else{//
								G_R3 = StreamBlock2->ReadByte();
							}
					}
						copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
						copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
	}
//////
	void Case_8_decompress2(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
					
					copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
					G_CountBit--;//
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}
					if((G_BitOperation & ext) != 0){
						G_CountBit--;// 
							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
								G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
								G_Offset+=2;
							}else{//
								G_R3 = StreamBlock2->ReadByte();
							}
					}
					G_CountBit--;//
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}
					G_CountBit--;//
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}
	}	
//////
	void Case_9_decompress2(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
					
					copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
					G_CountBit--;//
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}
					if((G_BitOperation & ext) != 0){
						G_CountBit--;// 
							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
								G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
								G_Offset+=2;
							}else{//
								G_R3 = StreamBlock2->ReadByte();
							}
					}
						G_CountBit--;// 
							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
								copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
							}else{
								copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
							}
							copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
	}	
//////
	void Case_10_decompress2(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
					
					copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
					G_CountBit--;//
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}
					if((G_BitOperation & ext) != 0){
						G_CountBit--;// 
							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
								G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
								G_Offset+=2;
							}else{//
								G_R3 = StreamBlock2->ReadByte();
							}
					}
						copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
						G_CountBit--;// 
							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
							}
	}
/////
	void Case_11_decompress2(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
					
					copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
					G_CountBit--;//
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}
					if((G_BitOperation & ext) != 0){
						G_CountBit--;// 
							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
								G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
								G_Offset+=2;
							}else{//
								G_R3 = StreamBlock2->ReadByte();
							}
					}
						copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
						copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
	}
/////
	void Case_12_decompress2(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
					
					copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
					copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
					if((G_BitOperation & ext) != 0){
						G_CountBit--;// 
							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
								G_R3 = block_3[G_Offset] |(block_3[G_Offset + 1] << 8);
								G_Offset+=2;
							}else{//
								G_R3 = StreamBlock2->ReadByte();
							}
					}
					G_CountBit--;//
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}
					G_CountBit--;//
						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
						}

	}	
//////
	void Case_13_decompress2(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
					
					copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
					copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
					if((G_BitOperation & ext) != 0){
						G_CountBit--;// 
							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
								G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
								G_Offset+=2;
							}else{//
								G_R3 = StreamBlock2->ReadByte();
							}
					}
						G_CountBit--;// 
							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
							}
						copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
	}
////////
	void Case_14_decompress2(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
					
					copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
					copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
					if((G_BitOperation & ext) != 0){
						G_CountBit--;// 
							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
								G_R3 = block_3[G_Offset] |(block_3[G_Offset + 1] << 8);
								G_Offset+=2;
							}else{//
								G_R3 = StreamBlock2->ReadByte();
							}
					}
						copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
						G_CountBit--;// 
							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
							copy_2_bytes_with_xor_RC1(StreamBlock2, StreamBlock3);
						}else{
							copy_2_bytes_from_compressed_stream_RC1(StreamBlock3, block_3);
							}
	}
/////
	void Case_15_decompress2(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
					
					copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
					copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
					if((G_BitOperation & ext) != 0){
						G_CountBit--;// 
							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
								G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
								G_Offset+=2;
							}else{//
								G_R3 = StreamBlock2->ReadByte();
							}
					}
						copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
						copy_2_bytes_from_offset_out_stream_RC1(StreamBlock3);
	}	




	array<unsigned char>^ DecompressAppBada2RC1( array<unsigned char>^ decrypt, BackgroundWorker^ bwAsync){
			
	
				MemoryStream^ stream = gcnew MemoryStream(decrypt);
				BinaryReader^ br = gcnew BinaryReader( stream );

				int first = br->ReadInt32();
				int len_1 = br->ReadInt32();
				int len_2 = br->ReadInt32();

				array<unsigned char>^ block_1 = gcnew array<unsigned char>(len_1 + 0x10);
				array<unsigned char>^ block_2 = gcnew array<unsigned char>(len_2 + 0x10);
				array<unsigned char>^ block_3 = gcnew array<unsigned char>((br->BaseStream->Length -(len_1 + len_2 + 0xC)) + 0x100);

				br->Read(block_1, 0, len_1);
				MemoryStream^ StreamBlock1 = gcnew MemoryStream( block_1->Length );// ����� ������� �����
				StreamBlock1->Write(block_1, 0, block_1->Length);
				StreamBlock1->Seek(0, SeekOrigin::Begin);

				br->Read(block_2, 0, len_2);
				MemoryStream^ StreamBlock2 = gcnew MemoryStream( block_2->Length );// ����� ������� �����
				StreamBlock2->Write(block_2, 0, block_2->Length);
				StreamBlock2->Seek(0, SeekOrigin::Begin);

				br->Read(block_3, 0, block_3->Length);
				MemoryStream^ StreamBlock3 = gcnew MemoryStream( first >> 4 << 2  ); ///������ ����� ��������. ��� �������� �����
				StreamBlock3->Seek(0, SeekOrigin::Begin);
					
				br->Close();
//////////
				G_CountBit = 0;
				G_BitOperation = 0;
				G_Offset = 0;
				G_CountDword = (first >> 4 << 2);
				G_CaseSwitch = 0;
				G_R3 = 1;
				G_BitsBuffer = 0;

				/////���������� �� 3 ����� 16 ���� � �����
				StreamBlock3->Write(block_3, G_Offset, 0x10);
				G_Offset += 0x10;
				G_CountDword-=4;//

///////////////////////
				while(G_CountDword != 0){
				if(G_CountBit <= 0x10){
				unsigned short a = StreamBlock1->ReadByte();// ������� 1 ���� Count < 0x10
				unsigned short b = StreamBlock1->ReadByte();
				G_BitsBuffer = a | (G_BitsBuffer << 8);
				G_BitsBuffer = b | (G_BitsBuffer << 8);
				G_CountBit += 0x10;
				}

				G_CountBit--;//������� ���� Count > 0x10
				if((G_BitsBuffer >> G_CountBit & 1) == 0){//���� ��� == 0 �� ������ ������ ���
					G_CountBit--;// 
					if((G_BitsBuffer >> G_CountBit & 1) == 0){//���� ������ ��� == 00
							G_CountBit --;//
							if((G_BitsBuffer >> G_CountBit & 1) == 0){//���� ������ ��� == 0/////////
								G_CountBit--;//
								if((G_BitsBuffer >> G_CountBit & 1) == 0){ //���� ������ ���� == 0 (0000)//////////
										G_CountBit-= 4;
										G_CaseSwitch = (G_BitsBuffer >> G_CountBit) & 0xF;//����� ������ ���� �� ������ ����� - ���������� ���������� ����� (������ == 4 �����)
										G_CountDword = G_CountDword - (G_CaseSwitch << 2);//-(CaseSwitch * 4);
									}else{//���� ������ ���� = (0001)
										G_CaseSwitch = StreamBlock2->ReadByte();//����� ���� �� ������� ������ - ���������� ���������� ����� (������ == 4 �����)
										G_CountDword = G_CountDword - (G_CaseSwitch << 2);////+ ((0 - CaseSwitch) << 2);
									}
								while(G_CaseSwitch){
											StreamBlock3->Write(block_3, G_Offset, 0x10);
											G_Offset += 0x10;
											G_CaseSwitch--;
								}
									}else{//���� ������ ���� == (001~) �.�. ������ ���  == 1
										
										G_CountBit--;//
										if((G_BitsBuffer >> G_CountBit & 1) == 0){//���� ������ ���� == (0010)
												G_CountBit-= 4;
												G_CaseSwitch = (G_BitsBuffer >> G_CountBit) & 0xF;
												G_CountDword = G_CountDword - (G_CaseSwitch << 2);//+ ((0 - CaseSwitch) << 2);
										}else{//���� ������ ���� == (0011)
												G_CaseSwitch = StreamBlock2->ReadByte();
												G_CountDword = G_CountDword - (G_CaseSwitch << 2);//+ ((0 - CaseSwitch) << 2);
										}

								while(G_CaseSwitch){
										for(int i = 0; i<0x10; i++){
											int offset = G_R3;
											StreamBlock3->Seek(-offset, SeekOrigin::Current);
											unsigned short a = StreamBlock3->ReadByte();
											StreamBlock3->Seek(0, SeekOrigin::End);
											StreamBlock3->WriteByte(a);
										}
										G_CaseSwitch--;							
								}//while

							}

					}else{//���� ������ ��� ����� 1 (01)
						StreamBlock3->Write(block_3, G_Offset, 0x10);
						G_Offset += 0x10;
						G_CountDword-=4;
						}


				}else{//���� ��� ��������� �� ������� ������ ����� 1
					
					G_CaseSwitch = StreamBlock2->ReadByte();// >> 4;//������� 4 ������� ���� �� ����� ���������� �� ������� ������
							G_CountBit-=4;//
									G_BitOperation = ((G_BitsBuffer >> G_CountBit) & 0xF);// ������� 4 ���� �� ������ �����
											if((G_BitOperation & 8) != 0)	{//���� ������� �� ������� ��� == 1 (1~~~)			
													G_CountBit--;
														if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
																G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
																G_Offset+=2;
															}else{//���� ����� ��� == 1
																G_R3 = StreamBlock2->ReadByte();
														}
											}
												switch(G_CaseSwitch >> 4){

													case 0:
														Case_0_decompress2(StreamBlock2, StreamBlock3, block_3, 4);
														break;
													case 1:
														Case_1_decompress2(StreamBlock2, StreamBlock3, block_3, 4);
														break;
													case 2:
														Case_2_decompress2(StreamBlock2, StreamBlock3, block_3, 4);
														break;
													case 3:
														Case_3_decompress2(StreamBlock2, StreamBlock3, block_3, 4);
														break;
													case 4:
														Case_4_decompress2(StreamBlock2, StreamBlock3, block_3, 4);
														break;
													case 5:
														Case_5_decompress2(StreamBlock2, StreamBlock3, block_3, 4);
														break;
													case 6:
														Case_6_decompress2(StreamBlock2, StreamBlock3, block_3, 4);
														break;
													case 7:
														Case_7_decompress2(StreamBlock2, StreamBlock3, block_3, 4);
														break;
													case 8:
														Case_8_decompress2(StreamBlock2, StreamBlock3, block_3, 4);
														break;
													case 9:
														Case_9_decompress2(StreamBlock2, StreamBlock3, block_3, 4);
														break;
													case 10:
														Case_10_decompress2(StreamBlock2, StreamBlock3, block_3, 4);
														break;
													case 11:
														Case_11_decompress2(StreamBlock2, StreamBlock3, block_3, 4);
														break;
													case 12:
														Case_12_decompress2(StreamBlock2, StreamBlock3, block_3, 4);
														break;
													case 13:
														Case_13_decompress2(StreamBlock2, StreamBlock3, block_3, 4);
														break;
													case 14:
														Case_14_decompress2(StreamBlock2, StreamBlock3, block_3, 4);
													break;
													case 15:
														Case_15_decompress2(StreamBlock2, StreamBlock3, block_3, 4);
													break;
													default:
														break;
												}//Switch

							if(G_CountBit <= 0x10){
							unsigned short a = StreamBlock1->ReadByte();// ������� 1 ���� Count < 0x10
							unsigned short b = StreamBlock1->ReadByte();
							G_BitsBuffer = a | (G_BitsBuffer << 8);
							G_BitsBuffer = b | (G_BitsBuffer << 8);
							G_CountBit += 0x10;
							}							

							if((G_BitOperation & 2) != 0){
								G_CountBit--;// 
									if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
										G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
										G_Offset+=2;
									}else{//
										G_R3 = StreamBlock2->ReadByte();
									}
							}

												switch(G_CaseSwitch & 0xF){

													case 0:
														Case_0_decompress2(StreamBlock2, StreamBlock3, block_3, 1);
														break;
													case 1:
														Case_1_decompress2(StreamBlock2, StreamBlock3, block_3, 1);
														break;
													case 2:
														Case_2_decompress2(StreamBlock2, StreamBlock3, block_3, 1);
														break;
													case 3:
														Case_3_decompress2(StreamBlock2, StreamBlock3, block_3, 1);
														break;
													case 4:
														Case_4_decompress2(StreamBlock2, StreamBlock3, block_3, 1);
														break;
													case 5:
														Case_5_decompress2(StreamBlock2, StreamBlock3, block_3, 1);
														break;
													case 6:
														Case_6_decompress2(StreamBlock2, StreamBlock3, block_3, 1);
														break;
													case 7:
														Case_7_decompress2(StreamBlock2, StreamBlock3, block_3, 1);
														break;
													case 8:
														Case_8_decompress2(StreamBlock2, StreamBlock3, block_3, 1);
														break;
													case 9:
														Case_9_decompress2(StreamBlock2, StreamBlock3, block_3, 1);
														break;
													case 10:
														Case_10_decompress2(StreamBlock2, StreamBlock3, block_3, 1);
														break;
													case 11:
														Case_11_decompress2(StreamBlock2, StreamBlock3, block_3, 1);
														break;
													case 12:
														Case_12_decompress2(StreamBlock2, StreamBlock3, block_3, 1);
														break;
													case 13:
														Case_13_decompress2(StreamBlock2, StreamBlock3, block_3, 1);
														break;
													case 14:
														Case_14_decompress2(StreamBlock2, StreamBlock3, block_3, 1);
														break;
													case 15:
														Case_15_decompress2(StreamBlock2, StreamBlock3, block_3, 1);
														break;
													default:
														break;
												}//Switch
									G_CountDword-=4;

					}
				}//while
///////////////////////
							array<unsigned char>^ decompress = gcnew array<unsigned char>(StreamBlock3->Length);
							StreamBlock3->Seek(0, SeekOrigin::Begin);
							StreamBlock3->Read(decompress, 0, decompress->Length);

							return decompress;
	}

*/

/*				array<unsigned char>^ ParserAppBada2RC1(array<unsigned char>^ decompress, String^ foldername, BackgroundWorker^ bwAsync){
				
				int  type;

				BinaryWriter^ bw2 = gcnew BinaryWriter(File::Create(String::Concat(foldername, L"\\name.bin"))); 
				bw2->BaseStream->Write(decompress,0,0x100);
				bw2->Close();


				MemoryStream^ myStreamParser = gcnew MemoryStream(decompress);
				BinaryReader^ br = gcnew BinaryReader(myStreamParser);
				
				br->BaseStream->Seek(0x14, SeekOrigin::Begin);
				int len_file = br->ReadInt32();

				br->BaseStream->Seek(0x100, SeekOrigin::Begin);
				
				MemoryStream^ Stream = gcnew MemoryStream();
				BinaryWriter^ bw = gcnew BinaryWriter(Stream);
				

				while((type = br->ReadInt32()) != 0){
				int len = br->ReadInt32();
				int offset = br->ReadUInt32();
				int position2 = br->BaseStream->Position;
				
				array<unsigned char>^ CompressedBlock = gcnew array<unsigned char>(len);
				
				switch(type){

				case 0xF:
				case 0xA:
				case 0x3:
						br->BaseStream->Seek(offset, SeekOrigin::Begin);
						br->BaseStream->Read(CompressedBlock, 0, len);
						bw->BaseStream->Write(CompressedBlock, 0, len);
					break;
				
//				case 0x1:
//						br->BaseStream->Seek(offset, SeekOrigin::Begin);
//						br->BaseStream->Read(CompressedBlock, 0, len);
//						bw->BaseStream->Write((DecompressAppBada2(CompressedBlock, bwAsync)), 0, 0x40000);
//						bwAsync->ReportProgress(Convert::ToInt32( br->BaseStream->Position *  100 / br->BaseStream->Length));
//					break;

				case 0x8:
						int position = br->BaseStream->Position;
						br->BaseStream->Seek(offset, SeekOrigin::Begin);
						unsigned int LenBlock = 0;
						int m = 0;
						
						for(int i = 0; i < 0x40; i++){
							LenBlock = br->ReadInt16();
							int position1 = br->BaseStream->Position;

							br->BaseStream->Seek(offset + 0x80 + m, SeekOrigin::Begin);
							br->BaseStream->Read(CompressedBlock, 0, LenBlock);
						if(LenBlock == 0x1000){
						
							bw->BaseStream->Write(CompressedBlock, 0, LenBlock);	
						}else{
						
							bw->BaseStream->Write((DecompressAppBada2RC1(CompressedBlock, bwAsync)), 0, 0x1000);
							bwAsync->ReportProgress(Convert::ToInt32( br->BaseStream->Position *  100 / br->BaseStream->Length));
						}
							m += LenBlock;
							br->BaseStream->Seek(position1, SeekOrigin::Begin);

						}
						br->BaseStream->Seek(position, SeekOrigin::Begin);

						break;
					}//case
						
				br->BaseStream->Seek(position2, SeekOrigin::Begin);

			}//while

				array<unsigned char>^ bufname = gcnew array<unsigned char>(0x400);
				br->BaseStream->Seek(len_file,SeekOrigin::Begin);
				br->Read(bufname,0,0x400);
				BinaryWriter^ bw1 = gcnew BinaryWriter(File::Create(String::Concat(foldername, L"\\end.bin"))); 
				bw1->BaseStream->Write(bufname,0,0x400);
				bw1->Close();


					array<unsigned char>^ decrypt_decompress = gcnew array<unsigned char>(bw->BaseStream->Length);
					bw->BaseStream->Seek(0,SeekOrigin::Begin);
					bw->BaseStream->Read(decrypt_decompress, 0, decrypt_decompress->Length);

					bw->Close();
					br->Close();

					return decrypt_decompress;
	}
*/

}