#pragma once

//#include "Form1.h"


namespace ImageUtils {


	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	using namespace System::Collections::Generic;

	ref struct Item{
		
		unsigned int item_ID;
		unsigned int item_num;
		unsigned int len;
		unsigned int item_compression_metod;
		unsigned int item_width;
		unsigned int item_height;
		unsigned int item_bit_format;
		unsigned int item_transparent;
		unsigned int item_mask;
		unsigned int item_end;
		array<unsigned char>^ data;


		static Item^ Get_Item(BinaryReader^ br){

				Item^ item = gcnew Item;
				item->item_ID = br->ReadInt32();
				item->item_num = br->ReadInt32();
				if(item->item_num == 0xFFFFFFFF)
				item->item_num=0;
				item->len = br->ReadInt32();
				if(item->len == 0xFFFFFFFF)
				item->len=0;
				item->item_compression_metod = br->ReadInt32();
				if(item->item_compression_metod == 0xFFFFFFFF)
				item->item_compression_metod=0;
				item->item_width = br->ReadInt32();
				if(item->item_width == 0xFFFFFFFF)
				item->item_width=0;
				item->item_height = br->ReadInt32();
				if(item->item_height == 0xFFFFFFFF)
				item->item_height=0;
				item->item_bit_format = br->ReadInt32();
				if(item->item_bit_format == 0xFFFFFFFF)
				item->item_bit_format=0;
				item->item_transparent = br->ReadInt32();
				item->item_mask = br->ReadInt32();
				item->item_end = br->ReadInt32();
				//if(item->item_num != 0xFFFFFFFF){
				item->data = gcnew array<unsigned char>(item->len);
				br->Read(item->data, 0, item->len);
				//}else{
				//item->data = gcnew array<unsigned char>(0);
				//}
				return item;
		}

	};

	ref struct Item_Pointer{

		unsigned int magic;
		unsigned int item_ID;
		unsigned int item_offset;
		unsigned int item_len;

	static Item_Pointer^ Get_Item_Pointer(BinaryReader^ br){

				Item_Pointer^ Pointer = gcnew Item_Pointer;
				Pointer->magic = br->ReadInt32();
				Pointer->item_ID = br->ReadInt32();
				Pointer->item_offset = br->ReadInt32();
				Pointer->item_len = br->ReadInt32();

			return Pointer;
		}


	};
	ref struct RBMheader{

		unsigned int uncnoun;
		unsigned int magic;
		unsigned int item_count;
		array<Item_Pointer^>^ pointer;
		array<Item^>^ item;

		static RBMheader^ GetRBM (BinaryReader^ br){
				

					RBMheader^ RBM = gcnew RBMheader;
					RBM->uncnoun = br->ReadInt32();
					RBM->magic = br->ReadInt32();
					RBM->item_count = br->ReadInt32();
		
					RBM->pointer = gcnew array<Item_Pointer^>(RBM->item_count);

					for(int i = 0; i < RBM->item_count; i++){
						RBM->pointer[i] = Item_Pointer::Get_Item_Pointer(br);
					}

					RBM->item = gcnew array <Item^>(RBM->item_count);

					for(int i = 0; i < RBM->item_count; i++){
						RBM->item[i] =Item::Get_Item( br);
					}


			return RBM;
		}

	};


	void/*RBMheader^ */ViewRBM(String^ Path, TreeView^ treeView, ContextMenuStrip^ MenuStrip){
				
			MemoryStream^ myStreamDump = gcnew MemoryStream(File::ReadAllBytes(Path));
				BinaryReader^ br = gcnew BinaryReader(myStreamDump);
					br->BaseStream->Seek(0x0, SeekOrigin::Begin);
						RBMheader^ rbm = RBMheader::GetRBM (br);
							br->Close();
			
			String^ Name = Path::GetFileName(Path);
				treeView->BeginUpdate();
					treeView->Nodes->Clear();
						TreeNode^ rootNode = gcnew TreeNode( Name,0,0);
					rootNode->NodeFont = gcnew System::Drawing::Font("Arial",8,System::Drawing::FontStyle::Bold);
				treeView->Nodes->Add( rootNode);
			treeView->Sorted = false;
		
						for(unsigned int l=0; l<rbm->item_count; l++){
							int mode;
							if((rbm->item[l]->item_compression_metod == 3 || rbm->item[l]->item_compression_metod == 5) && (rbm->item[l]->item_bit_format == 32 || rbm->item[l]->item_bit_format == 16)){
							mode = rbm->item[l]->data[5];
							}else{
							mode = 0;
							}
							TreeNode^ NodeFiles= gcnew TreeNode(String::Format ("ID {0}, size {1}x{2}, bpp {3}, metod {4}, mode {5}", rbm->item[l]->item_ID, rbm->item[l]->item_width, rbm->item[l]->item_height, rbm->item[l]->item_bit_format, rbm->item[l]->item_compression_metod, mode),2,2);
						NodeFiles->Tag = rbm->item[l];
						NodeFiles->ToolTipText = String::Format ("size {0}x{1}\nbit format {2}\ncompression metod {3}\ntransparent {4}\nmask {5:x8}",
							rbm->item[l]->item_width, rbm->item[l]->item_height, rbm->item[l]->item_bit_format,rbm->item[l]->item_compression_metod, rbm->item[l]->item_transparent, rbm->item[l]->item_mask);
						NodeFiles->ContextMenuStrip = MenuStrip;
						rootNode->Nodes->Add( NodeFiles);
						}
			treeView->EndUpdate();
				rootNode->Expand();
					treeView->SelectedNode = rootNode;
						treeView->Focus();

	}





}