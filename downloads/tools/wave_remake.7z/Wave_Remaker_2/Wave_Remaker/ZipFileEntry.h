﻿
//#include "ZipEntry.h"
//#include "Crc32.h"

using namespace System;
using namespace System::IO;
using namespace System::Collections::Generic;
using namespace System::Text;




namespace TinySharpZip
{

//   public ref class Crc32
//    {
////        #region Private Variables
//
//        static  unsigned int CRC32_POLYNOMIAL = 0xedb88320;
//        static  array<unsigned int>^ CRC32_TABLE;
//
////        #endregion
//
////        #region Constructors
//
//        static Crc32()
//        {
//            CRC32_TABLE = gcnew  array<unsigned int>(0x100);
//
//            for (unsigned int byteIndex = 0; byteIndex < 0x100; byteIndex++)
//            {
//                unsigned int crcTableItem = byteIndex;
//                for (int bitIndex = 0; bitIndex < 8; bitIndex++)
//                {
//                    if ((crcTableItem & 1) != 0)
//                    {
//                        crcTableItem = CRC32_POLYNOMIAL ^ (crcTableItem >> 1);
//                    }
//                    else
//                    {
//                        crcTableItem = crcTableItem >> 1;
//                    }
//                }
//                CRC32_TABLE[byteIndex] = crcTableItem;
//            }
//        }
//
//         static unsigned int Compute(Stream^ bytes)
//        {
//			unsigned int crc32Value = UInt32::MaxValue;
//            int sourceByte = 0;
//            while ((sourceByte = bytes->ReadByte()) != -1)
//            {
//                unsigned int indexInTable = (crc32Value ^ (char)sourceByte) & 0xFF;
//                crc32Value = CRC32_TABLE[indexInTable] ^ (crc32Value >> 8);
//
//            }
//            crc32Value = ~crc32Value;
//            return crc32Value;
//        }
//
//    };
	private ref class Crc32
	{
		#pragma region Private Variables

	private:
		static initonly System::UInt32 CRC32_POLYNOMIAL = 0xedb88320;
		static initonly array<System::UInt32> ^CRC32_TABLE;

		#pragma endregion

		#pragma region Constructors

		static Crc32()
		{
			CRC32_TABLE = gcnew array<System::UInt32>(0x100);

			for (System::UInt32 byteIndex = 0; byteIndex < 0x100; byteIndex++)
			{
				System::UInt32 crcTableItem = byteIndex;
				for (int bitIndex = 0; bitIndex < 8; bitIndex++)
				{
					if ((crcTableItem & 1) != 0)
					{
						crcTableItem = CRC32_POLYNOMIAL ^ (crcTableItem >> 1);
					}
					else
					{
						crcTableItem = crcTableItem >> 1;
					}
				}
				CRC32_TABLE[byteIndex] = crcTableItem;
			}
		}

		#pragma endregion

		#pragma region Public Methods

	internal:
		static System::UInt32 Compute(Stream ^bytes)
		{
			System::UInt32 crc32Value = System::UInt32::MaxValue;
			int sourceByte = 0;
			while ((sourceByte = bytes->ReadByte()) != -1)
			{
				System::UInt32 indexInTable = (crc32Value ^ safe_cast<System::Byte>(sourceByte)) & 0xFF;
				crc32Value = CRC32_TABLE[indexInTable] ^ (crc32Value >> 8);

			}
			crc32Value = ~crc32Value;
			return crc32Value;
		}

		#pragma endregion
	};


 //ref class ZipEntry
 //   {

 //        System::DateTime lastModified;


 //        ZipEntry()
 //       {
	//		lastModified = System::DateTime::Now;
 //       }


	//public: property System::DateTime LastModified
 //       {
 //          System::DateTime get() { return lastModified; }
 //          void/*System::DateTime*/ set (System::DateTime value){ lastModified = value; }
 //       }


 //        void SetLastModifiedDateTime(unsigned int dosTime)
 //       {
	//		unsigned int second = Math::Min((unsigned int)59, (unsigned int)(2 * (dosTime & 0x1f)));
	//		unsigned int minute = Math::Min((unsigned int)59, (unsigned int)((dosTime >> 5) & 0x3f));
	//		unsigned int hour = Math::Min((unsigned int)23, (unsigned int)((dosTime >> 11) & 0x1f));
	//		unsigned int month = Math::Max((unsigned int)1, Math::Min((unsigned int)12,(unsigned int) ((dosTime >> 21) & 0xf)));
 //           unsigned int year = ((dosTime >> 25) & 0x7f) + 1980;
	//		int day = Math::Max((unsigned int)1, Math::Min((unsigned int)( DateTime::DaysInMonth((unsigned int)year, (unsigned int)month)), (unsigned int)((dosTime >> 16) & 0x1f)));
 //           lastModified = DateTime((unsigned int)year, (unsigned int)month, day, (unsigned int)hour, (unsigned int)minute, (unsigned int)second);
 //       }

 //        unsigned int GetLastModifiedDateTime()
 //       {
	//		unsigned int year = (unsigned int)lastModified.Year;
	//		unsigned int month = (unsigned int)lastModified.Month;
	//		unsigned int day = (unsigned int)lastModified.Day;
	//		unsigned int hour = (unsigned int)lastModified.Hour;
	//		unsigned int minute = (unsigned int)lastModified.Minute;
	//		unsigned int second = (unsigned int)lastModified.Second;

 //           if (year < 1980)
 //           {
 //               year = 1980;
 //               month = 1;
 //               day = 1;
 //               hour = 0;
 //               minute = 0;
 //               second = 0;
 //           }
 //           else if (year > 2107)
 //           {
 //               year = 2107;
 //               month = 12;
 //               day = 31;
 //               hour = 23;
 //               minute = 59;
 //               second = 59;
 //           }

 //           unsigned int dosTime = ((year - 1980) & 0x7f) << 25 |
 //               (month << 21) |
 //               (day << 16) |
 //               (hour << 11) |
 //               (minute << 5) |
 //               (second >> 1);
 //           return dosTime;
 //       }

 //   };



 /*    public ref class ZipFileEntry : ZipEntry
    {
        
	private: String^ fileName;
	private: Stream^ data;
	private: unsigned int crc;


	public: ZipFileEntry(String^ fileName, Stream^ data)
        {
            this->fileName = fileName;
            this->data = data;
            ComputeCrc(data);
        }
       

	public: property String^ FileName
        {
           String^ get() { return fileName; }
            void set (String^ value){ fileName = value; }
        }


	public: property unsigned int Crc
        {
           unsigned int get() { return crc; }
        }



		private: void ComputeCrc(Stream^ data)
        {
            if (data != nullptr && data->Length != 0)
            {
				crc = Crc32.Compute(data);
            }
            else
            {
                crc = 0;
            }
        }
	
	
	public: property Stream^ Data
        {
            Stream^ get() { return data; }
            void set(Stream^ value)
            {
                data = value;
                ComputeCrc(data);
            }
        }





    };*/

	public ref class ZipEntry abstract
	{
		#pragma region Private Variables

	private:
		DateTime lastModified;

		#pragma endregion

		#pragma region Constructors / Destructors

	internal:
		ZipEntry()
		{
			lastModified = DateTime::Now;
		}

		#pragma endregion

		#pragma region Public Properties

	public:
		property DateTime LastModified
		{
			DateTime get()
			{
				return lastModified;
			}
			void set(DateTime value)
			{
				lastModified = value;
			}
		}

		#pragma endregion

		#pragma region Internal Methods

	internal:
		void SetLastModifiedDateTime(System::UInt32 dosTime)
		{
			unsigned int second = Math::Min((unsigned int)59, (unsigned int)(2 * (dosTime & 0x1f)));
			unsigned int minute = Math::Min((unsigned int)59, (unsigned int)((dosTime >> 5) & 0x3f));
			unsigned int hour = Math::Min((unsigned int)23, (unsigned int)((dosTime >> 11) & 0x1f));
			unsigned int month = Math::Max((unsigned int)1, Math::Min((unsigned int)12,(unsigned int) ((dosTime >> 21) & 0xf)));
            unsigned int year = ((dosTime >> 25) & 0x7f) + 1980;
			int day = Math::Max((unsigned int)1, Math::Min((unsigned int)( DateTime::DaysInMonth((unsigned int)year, (unsigned int)month)), (unsigned int)((dosTime >> 16) & 0x1f)));
            lastModified = DateTime((unsigned int)year, (unsigned int)month, day, (unsigned int)hour, (unsigned int)minute, (unsigned int)second);
		}

		System::UInt32 GetLastModifiedDateTime()
		{
			System::UInt32 year = safe_cast<System::UInt32>(lastModified.Year);
			System::UInt32 month = safe_cast<System::UInt32>(lastModified.Month);
			System::UInt32 day = safe_cast<System::UInt32>(lastModified.Day);
			System::UInt32 hour = safe_cast<System::UInt32>(lastModified.Hour);
			System::UInt32 minute = safe_cast<System::UInt32>(lastModified.Minute);
			System::UInt32 second = safe_cast<System::UInt32>(lastModified.Second);

			if (year < 1980)
			{
				year = 1980;
				month = 1;
				day = 1;
				hour = 0;
				minute = 0;
				second = 0;
			}
			else if (year > 2107)
			{
				year = 2107;
				month = 12;
				day = 31;
				hour = 23;
				minute = 59;
				second = 59;
			}

			System::UInt32 dosTime = ((year - 1980) & 0x7f) << 25 | (month << 21) | (day << 16) | (hour << 11) | (minute << 5) | (second >> 1);
			return dosTime;
		}

		#pragma endregion
	};

	public ref class ZipFileEntry : ZipEntry
	{
		#pragma region Private Variables

	private:
		System::String ^fileName;
		Stream ^data;
		System::UInt32 crc;

		#pragma endregion

		#pragma region Constructors

	public:
		ZipFileEntry(System::String ^fileName, Stream ^data)
		{
			this->fileName = fileName;
			this->data = data;
			ComputeCrc();
		}

		#pragma endregion

		#pragma region Public Properties

		property System::String ^FileName
		{
			System::String ^get()
			{
				return fileName;
			}
			void set(System::String ^value)
			{
				fileName = value;
			}
		}

		property Stream ^Data
		{
			Stream ^get()
			{
				return data;
			}
			void set(Stream ^value)
			{
				data = value;
				ComputeCrc();
			}
		}

		property System::UInt32 Crc
		{
			System::UInt32 get()
			{
				return crc;
			}
		}

		#pragma endregion

		#pragma region Private Methods

	private:
		void ComputeCrc()
		{
			if (data != nullptr && data->Length != 0)
			{
				crc = Crc32::Compute(data);
			}
			else
			{
				crc = 0;
			}
		}

		#pragma endregion
	};






 //public ref  class ZipDirectoryEntry : ZipEntry
 //   {

	// String^ directoryName;
 //       

	// public: ZipDirectoryEntry(String^ directoryName)
 //       {
 //           this->directoryName = directoryName;
 //       }


	//public: property String^ DirectoryName
 //       {
 //          String^ get (){ return directoryName; }
 //         void  set (String^ value){ directoryName = value; }
 //               
 //       }

 //   };

	public ref class ZipDirectoryEntry : ZipEntry
	{
		#pragma region Private Variables

	private:
		System::String ^directoryName;

		#pragma endregion

		#pragma region Constructors

	public:
		ZipDirectoryEntry(System::String ^directoryName)
		{
			this->directoryName = directoryName;
		}

		#pragma endregion

		#pragma region Public Properties

		property System::String ^DirectoryName
		{
			System::String ^get()
			{
				return directoryName;
			}
			void set(System::String ^value)
			{
				directoryName = value;
			}

		}

		#pragma endregion
	};

}
