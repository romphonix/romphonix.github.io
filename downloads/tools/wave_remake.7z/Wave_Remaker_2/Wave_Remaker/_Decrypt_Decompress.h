#pragma once

#include "SEED_Crypto.h"
#include "QMD.h"


namespace ImageUtils {


//	using namespace System;
//	using namespace System::ComponentModel;
//	using namespace System::Collections;
//	using namespace System::Windows::Forms;
//	using namespace System::Data;
//	using namespace System::Drawing;
//	using namespace System::IO;


//	#define ALIGN(x,a) (((x)+(a)-1)&~((a)-1))



			array<unsigned char>^ DecompressApp( array<unsigned char>^ decrypt/*,  String^ SaveFileName*//*, BackgroundWorker^ bwAsync*/){
			
	
			MemoryStream^ stream = gcnew MemoryStream(decrypt);
			BinaryReader^ br = gcnew BinaryReader( stream );

			array<unsigned short>^ tab = gcnew array<unsigned short>(256){


					0x1,   0x3,	  0x100, 0x2,  0x8,  0x7,   0x6,	0x300,
					0x10,  0x4,	  0x200, 0x9,  0x40, 0x18,  0x5,	0x20,
					0xC,   0xE,   0xF,   0xA,  0xC0, 0x800, 0x700,	0x101,
					0x400, 0xB,   0x30,  0x11, 0x80, 0x600, 0xD,    0x12,
					0x1C,  0x500, 0x1B,  0x1E, 0x14, 0x1A,  0x28,   0x38,
					0x1000,0x1F,  0x19,  0x16, 0x60, 0x2000,0x13,   0x1D,
					0x103,  0x24,  0x17,  0x15, 0x102, 0x1C0, 0xF00,  0x3C,
					0x301, 0xC00,0x1800,  0x48,  0x21,  0x34, 0xE00, 0x202,
					0x2C,  0x70, 0xA00, 0x303,  0x36, 0x201,  0x3F, 0xD00,
					0x180,  0x3E,0x3000, 0x900,  0x78,  0x22,  0x50,  0x3A,
					0x41, 0x107,  0x33, 0x106,  0x26,  0x2A,  0xA0,  0x23,
					0x29,  0x88,  0x44,  0x3D,  0xE0,  0x32,  0x2E,  0x39,
					0x31,  0x2D,  0xF0, 0x140, 0xB00,  0x3B,  0x58,0x4000,
					0x37,  0x35,  0x68, 0x302,  0x7C,  0x2F,  0x27,  0x64,
					0x90,  0x74, 0x203, 0x104,  0x6C,0x1100, 0x3C0,  0xFF,
					0x25,0xF000,0x1F00, 0x701,  0x42,  0x7F,  0x2B, 0x105,
					0x54,0x1C00,  0x4C, 0x801,  0x43,0x6000,  0x5C,  0x7E,
					0xE8, 0x108,  0xF8,0xE000, 0x206,0x1E00, 0x380,  0x61,
					0x7A,  0x4E, 0x601,0x1001,  0xC8,0x8000,0x1D00,  0xD0,
					0x72,  0x49,0x1600,0x1A00,  0x46,0x7000, 0x10F, 0x110,
					0x76,0x1200,0x1400, 0x404, 0x606, 0x10E,  0xFC,0x1700,
					0x6E,  0xFE,0x1300,  0x62,  0x66,0xC000, 0x204, 0x306,
					0x63, 0x707, 0x280, 0x602,  0x55,  0x47,  0x6A, 0x10C,
					0x52, 0x501,  0xD8, 0x307,  0x73, 0x109, 0x808, 0x401,
					0x4A,0x2020,  0x5A, 0x702,  0xB0,  0x45, 0x207, 0x304,
					0x402,  0x5E, 0x10A,  0x79,0x3800,  0xF4,0x1500, 0x1E0,
					0x1B00,  0x71,0x1010,  0xC1,  0xE4, 0x502,  0x56,  0x7D,
					0x81,  0x77,  0xCC, 0x703, 0x10D, 0x205, 0x340,0x5000,
					0x82,  0x67,0xFF00, 0x120,  0x69,  0x98,  0xC3,0x1900,
					0x65,  0x7B, 0x240, 0x603,  0xEC,  0x59,  0xFA, 0x403,
					0x75,  0x6F,0x3100,0x3300,  0x4F,  0xB8,  0x6D, 0x208,
					0x4D, 0x111,  0x51, 0x20E,  0xDC,  0xC4,0x2100,  0xA8
				};                            
				
				br->BaseStream->Seek(0x10,SeekOrigin::Begin);
				int first = br->ReadInt32();
				int len_1 = br->ReadInt32();
				int len_2 = br->ReadInt32();

				array<unsigned char>^ block_1 = gcnew array<unsigned char>(len_1 + 0x10);
				array<unsigned char>^ block_2 = gcnew array<unsigned char>(len_2 + 0x10);
				array<unsigned char>^ block_3 = gcnew array<unsigned char>((br->BaseStream->Length -(len_1 + len_2 + 0xC)) + 0x100);

				br->Read(block_1, 0, len_1);
				MemoryStream^ StreamBlock1 = gcnew MemoryStream( block_1->Length );
				StreamBlock1->Write(block_1, 0, block_1->Length);
				StreamBlock1->Seek(0, SeekOrigin::Begin);

				br->Read(block_2, 0, len_2);
				MemoryStream^ StreamBlock2 = gcnew MemoryStream( block_2->Length );
				StreamBlock2->Write(block_2, 0, block_2->Length);
				StreamBlock2->Seek(0, SeekOrigin::Begin);

				br->Read(block_3, 0, block_3->Length);

				MemoryStream^ StreamBlock3 = gcnew MemoryStream( (first >> 4 << 2)  /*0x4000*/ ); ///������ ����� ��������.
				StreamBlock3->Seek(0, SeekOrigin::Begin);
					
				br->Close();

				unsigned int BitCount = 0;
				int BitOperation = 0;

				unsigned int offset = 0;
				/////���������� �� 3 ����� 16 ���� � �����
				StreamBlock3->Write(block_3, offset, 0x10);
				offset += 0x10;


				int var30 = first >> 4 << 2;//0x400;
				
				unsigned int OffsetDivOn2 = 1;
				
				for(int R10 = 4; R10 < var30; R10 += 4){
//������ ���������
				while(BitCount <= 2){	////////////
				BitOperation = ((StreamBlock1->ReadByte() << (0x18 - BitCount)) | BitOperation);
				BitCount += 8;
				}
				
				BitCount -= 1;

				if(BitOperation >= 0){//BGE ������ ��� �����, �������� ��������� ///�������� �������� �� ������������
					
				BitOperation = BitOperation << 1;
						
						if( BitOperation >= 0){ //BPL ������������� ��������, ������ ��� ����� ����
							StreamBlock3->Write(block_3, offset, 0x10);
								offset +=0x10;
						}else{


							for(int i = 0; i < 8; i ++){

								int off = OffsetDivOn2<<1;
								StreamBlock3->Seek(-off, SeekOrigin::Current);
								array<unsigned char>^ temp = gcnew array<unsigned char> (2);
								StreamBlock3->Read(temp, 0, 0x2);
								StreamBlock3->Seek(0, SeekOrigin::End);
								StreamBlock3->Write(temp, 0, 0x2);
							}
						} //if(s >= 0){ //BPL ������������� ��������, ������ ��� ����� ����
				
				BitCount -= 1;
				BitOperation = BitOperation << 1;
//������ ���������

				}else{

					int b2 = StreamBlock2->ReadByte();
					BitOperation = BitOperation << 1;

						while(BitCount < 0x10){	
						unsigned char g = StreamBlock1->ReadByte();
						BitOperation = (( /*StreamBlock1->ReadByte()*/g << (0x18 - BitCount)) | BitOperation);
						BitCount += 8;
						}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////						
						if(BitOperation >= 0){ //BLT (���������� ���� ��������� ��� ��������)
								BitOperation = BitOperation << 1;
								BitCount -= 1;
										if(BitOperation >= 0){ //BPL
										//��������� 2 ����� �� 3 �����
											unsigned char a = block_3[offset + 1];
											unsigned char b = block_3[offset];
											OffsetDivOn2 = a << 8;
											OffsetDivOn2 = OffsetDivOn2 | b;
											offset += 2;
										}else{
										//��������� 1 ���� �� 2 �����
											OffsetDivOn2 = (StreamBlock2->ReadByte());
										}
							}
									
										BitOperation = BitOperation << 1;
										BitCount -= 1;
/////////////////////////////////////////////////////////////////////////////////////////////////////////									
									if(OffsetDivOn2 > R10<<1){ return nullptr; }///// ��������� !!!!!!!!!!!!!!!!!//OffsetDivOn2
									
									if((int)(b2<<0x18)>= 0){

										if(BitOperation >= 0){

											int off = OffsetDivOn2<<1;
											StreamBlock3->Seek(-off, SeekOrigin::Current);
											
											unsigned short a = StreamBlock3->ReadByte();
											unsigned short b = StreamBlock3->ReadByte();
											b = b << 8;
											b = b | a;

											b = b ^ tab[StreamBlock2->ReadByte() ];
											
											StreamBlock3->Seek(0, SeekOrigin::End);
											
											a = b & 0xFF;
											b = b >> 8;

											StreamBlock3->WriteByte(a);
											StreamBlock3->WriteByte(b);
										
										}else{
											StreamBlock3->WriteByte(block_3[offset]);
											StreamBlock3->WriteByte(block_3[offset + 1]);
											offset += 2;
										}
									
											BitOperation = BitOperation << 1;
											BitCount -= 1;

									}else{

									int off = OffsetDivOn2<<1;
									StreamBlock3->Seek(-off, SeekOrigin::Current);
									array<unsigned char>^ temp = gcnew array<unsigned char> (2);
									StreamBlock3->Read(temp, 0, 0x2);
									StreamBlock3->Seek(0, SeekOrigin::End);
									StreamBlock3->Write(temp, 0, 0x2);
									} //R0
/////////////////////////////////////////////////////////////////////////////////////////////////////////
									

									if((int)(b2 << 0x19) >= 0 ){
										
										if(BitOperation >= 0){
											
											int off = OffsetDivOn2<<1;
											StreamBlock3->Seek(-off, SeekOrigin::Current);

											unsigned short a = StreamBlock3->ReadByte();
											unsigned short b = StreamBlock3->ReadByte();
											b = b << 8;
											b = b | a;

											b = b ^ tab[StreamBlock2->ReadByte() ];
											
											StreamBlock3->Seek(0, SeekOrigin::End);
											
											a = b & 0xFF;
											b = b >> 8;

											StreamBlock3->WriteByte(a);
											StreamBlock3->WriteByte(b);
										
										}else{
											
											StreamBlock3->WriteByte(block_3[offset]);
											StreamBlock3->WriteByte(block_3[offset + 1]);
											offset += 2;
										}

											BitOperation = BitOperation << 1;
											BitCount -= 1;

									}else{//////
									
									int off = OffsetDivOn2<<1;
									StreamBlock3->Seek(-off, SeekOrigin::Current);
									array<unsigned char>^ temp = gcnew array<unsigned char> (2);
									StreamBlock3->Read(temp, 0, 0x2);
									StreamBlock3->Seek(0, SeekOrigin::End);
									StreamBlock3->Write(temp, 0, 0x2);

									}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//���������   
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

								if(BitOperation >= 0){ //BLT (���������� ���� ��������� ��� ��������)
								BitOperation = BitOperation << 1;
								BitCount -= 1;
									
										if(BitOperation >= 0){
										//if(BitOperation >= 0){ //BPL
										//��������� 2 ����� �� 3 �����
											unsigned char a = block_3[offset + 1];
											unsigned char b = block_3[offset];
											OffsetDivOn2 = a << 8;
											OffsetDivOn2 = OffsetDivOn2 | b;
											offset += 2;
										}else{
										//��������� 1 ���� �� 2 �����
											OffsetDivOn2 = (StreamBlock2->ReadByte());
										}
								}
									
										BitOperation = BitOperation << 1;
										BitCount -= 1;
/////////////////////////////////////////////////////////////////////////////////////////////////////////									
									if(OffsetDivOn2 > R10<<2){return nullptr; }///// ��������� !!!!!!!!!!!!!!!!!//OffsetDivOn2
									
									//if((b2<<0x1A) >= 0){
									if((int)(b2 << 0x1A) >= 0 ){  //R0
										if(BitOperation >= 0){

											//int pos = StreamBlock3->Position;
											int off = OffsetDivOn2<<1;
											StreamBlock3->Seek(-off, SeekOrigin::Current);
											
											unsigned short a = StreamBlock3->ReadByte();
											unsigned short b = StreamBlock3->ReadByte();
											b = b << 8;
											b = b | a;

											//unsigned short j = tab[StreamBlock2->ReadByte() ];
											
											b = b ^ tab[StreamBlock2->ReadByte() ];
											
											StreamBlock3->Seek(0, SeekOrigin::End);
											
											a = b & 0xFF;
											b = b >> 8;
											
											StreamBlock3->WriteByte(a);
											StreamBlock3->WriteByte(b);
										
										}else{
											StreamBlock3->WriteByte(block_3[offset]);
											StreamBlock3->WriteByte(block_3[offset + 1]);
											offset += 2;
										}
									
											BitOperation = BitOperation << 1;
											BitCount -= 1;

									}else{

									//int pos = StreamBlock3->Position;
									int off = OffsetDivOn2<<1;
									StreamBlock3->Seek(-off, SeekOrigin::Current);
									array<unsigned char>^ temp = gcnew array<unsigned char> (2);
									StreamBlock3->Read(temp, 0, 0x2);
									StreamBlock3->Seek(0, SeekOrigin::End);
									StreamBlock3->Write(temp, 0, 0x2);
									} //R0
/////////////////////////////////////////////////////////////////////////////////////////////////////////

									if((int)(b2 << 0x1B) >= 0 ){
										
										if(BitOperation >= 0){
											
											int off = OffsetDivOn2<<1;
											StreamBlock3->Seek(-off, SeekOrigin::Current);
											
											unsigned short a = StreamBlock3->ReadByte();
											unsigned short b = StreamBlock3->ReadByte();
											b = b << 8;
											b = b | a;

											b = b ^ tab[StreamBlock2->ReadByte() ];
											
											StreamBlock3->Seek(0, SeekOrigin::End);
											
											a = b & 0xFF;
											b = b >> 8;

											StreamBlock3->WriteByte(a);
											StreamBlock3->WriteByte(b);
										
										}else{
											
											StreamBlock3->WriteByte(block_3[offset]);
											StreamBlock3->WriteByte(block_3[offset + 1]);
											offset += 2;
										}

											BitOperation = BitOperation << 1;
											BitCount -= 1;

									}else{
									
									int off = OffsetDivOn2<<1;
									StreamBlock3->Seek(-off, SeekOrigin::Current);
									array<unsigned char>^ temp = gcnew array<unsigned char> (2);
									StreamBlock3->Read(temp, 0, 0x2);
									StreamBlock3->Seek(0, SeekOrigin::End);
									StreamBlock3->Write(temp, 0, 0x2);

									}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//��������� 2 8 ����
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

								if(BitOperation >= 0){ //BLT (���������� ���� ��������� ��� ��������)
								BitOperation = BitOperation << 1;
								BitCount -= 1;

										if(BitOperation >= 0){
										//��������� 2 ����� �� 3 �����
											unsigned char a = block_3[offset + 1];
											unsigned char b = block_3[offset];
											OffsetDivOn2 = a << 8;
											OffsetDivOn2 = OffsetDivOn2 | b;//////////////////////////////////////
											offset += 2;
										}else{
										//��������� 1 ���� �� 2 �����
											OffsetDivOn2 = (StreamBlock2->ReadByte());
										}
								}
									
										BitOperation = BitOperation << 1;
										BitCount -= 1;
/////////////////////////////////////////////////////////////////////////////////////////////////////////									
									if(OffsetDivOn2 > R10 << 3){return nullptr; }///// ��������� !!!!!!!!!!!!!!!!!//OffsetDivOn2
									
									if( (int)(b2 << 0x1C) >= 0 ){  //R0
										if(BitOperation >= 0){

											int off = OffsetDivOn2<<1;
											StreamBlock3->Seek(-off, SeekOrigin::Current);
											
											unsigned short a = StreamBlock3->ReadByte();
											unsigned short b = StreamBlock3->ReadByte();
											b = b << 8;
											b = b | a;

											b = b ^ tab[StreamBlock2->ReadByte() ];
											
											StreamBlock3->Seek(0, SeekOrigin::End);
											
											a = b & 0xFF;
											b = b >> 8;

											StreamBlock3->WriteByte(a);
											StreamBlock3->WriteByte(b);
										
										}else{
											StreamBlock3->WriteByte(block_3[offset]);
											StreamBlock3->WriteByte(block_3[offset + 1]);
											offset += 2;
										}
									
											BitOperation = BitOperation << 1;
											BitCount -= 1;

									}else{

									int off = OffsetDivOn2<<1;
									StreamBlock3->Seek(-off, SeekOrigin::Current);
									array<unsigned char>^ temp = gcnew array<unsigned char> (2);
									StreamBlock3->Read(temp, 0, 0x2);
									StreamBlock3->Seek(0, SeekOrigin::End);
									StreamBlock3->Write(temp, 0, 0x2);
									} //R0
/////////////////////////////////////////////////////////////////////////////////////////////////////////

									if((int)(b2 << 0x1D) >= 0 ){
										
										if(BitOperation >= 0){
											
											int off = OffsetDivOn2<<1;
											StreamBlock3->Seek(-off, SeekOrigin::Current);
											
											unsigned short a = StreamBlock3->ReadByte();
											unsigned short b = StreamBlock3->ReadByte();
											b = b << 8;
											b = b | a;

											b = b ^ tab[StreamBlock2->ReadByte() ];
											
											StreamBlock3->Seek(0, SeekOrigin::End);
											
											a = b & 0xFF;
											b = b >> 8;

											StreamBlock3->WriteByte(a);
											StreamBlock3->WriteByte(b);
										
										}else{
											
											StreamBlock3->WriteByte(block_3[offset]);
											StreamBlock3->WriteByte(block_3[offset + 1]);
											offset += 2;
										}

											BitOperation = BitOperation << 1;
											BitCount -= 1;

									}else{
									
									int off = OffsetDivOn2<<1;
									StreamBlock3->Seek(-off, SeekOrigin::Current);
									array<unsigned char>^ temp = gcnew array<unsigned char> (2);
									StreamBlock3->Read(temp, 0, 0x2);
									StreamBlock3->Seek(0, SeekOrigin::End);
									StreamBlock3->Write(temp, 0, 0x2);

									}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//��������� 3  12   -    4 ����
////////////////////////////////////////////////////////////////////////////////////////////////////////////////

									if(BitOperation >= 0){ //BLT (���������� ���� ��������� ��� ��������)
									BitOperation = BitOperation << 1;
									BitCount -= 1;
											if(BitOperation >= 0){ //BPL
											//��������� 2 ����� �� 3 �����
												unsigned char a = block_3[offset + 1];
												unsigned char b = block_3[offset];
												OffsetDivOn2 = a << 8;
												OffsetDivOn2 = OffsetDivOn2 | b;
												offset += 2;
											}else{
										//��������� 1 ���� �� 2 �����
												OffsetDivOn2 = (StreamBlock2->ReadByte());
											}
									}
									
											BitOperation = BitOperation << 1;
											BitCount -= 1;
/////////////////////////////////////////////////////////////////////////////////////////////////////////									
									if(OffsetDivOn2 >= R10<<4){ return nullptr; }///// ��������� !!!!!!!!!!!!!!!!!//OffsetDivOn2

									if((int)(b2 << 0x1E) >= 0 ){  //R0
										
										if(BitOperation >= 0){

											int off = OffsetDivOn2<<1;
											StreamBlock3->Seek(-off, SeekOrigin::Current);
											unsigned short a = StreamBlock3->ReadByte();
											unsigned short b = StreamBlock3->ReadByte();
											b = b << 8;
											b = b | a;
											b = b ^ tab[StreamBlock2->ReadByte() ];
											StreamBlock3->Seek(0, SeekOrigin::End);
											a = b & 0xFF;
											b = b >> 8;
											StreamBlock3->WriteByte(a);
											StreamBlock3->WriteByte(b);
										}else{
											StreamBlock3->WriteByte(block_3[offset]);
											StreamBlock3->WriteByte(block_3[offset + 1]);
											offset += 2;
										}
									
											BitOperation = BitOperation << 1;
											BitCount -= 1;

									}else{

									int off = OffsetDivOn2<<1;
									StreamBlock3->Seek(-off, SeekOrigin::Current);
									array<unsigned char>^ temp = gcnew array<unsigned char> (2);
									StreamBlock3->Read(temp, 0, 0x2);
									StreamBlock3->Seek(0, SeekOrigin::End);
									StreamBlock3->Write(temp, 0, 0x2);
									} //R0
/////////////////////////////////////////////////////////////////////////////////////////////////////////

									if((int)(b2 << 0x1F) >= 0 ){
										
										if(BitOperation >= 0){
											
											int off = OffsetDivOn2<<1;
											StreamBlock3->Seek(-off, SeekOrigin::Current);
											
											unsigned short a = StreamBlock3->ReadByte();
											unsigned short b = StreamBlock3->ReadByte();
											b = b << 8;
											b = b | a;
											b = b ^ tab[StreamBlock2->ReadByte() ];
											StreamBlock3->Seek(0, SeekOrigin::End);
											a = b & 0xFF;
											b = b >> 8;
											StreamBlock3->WriteByte(a);
											StreamBlock3->WriteByte(b);
										
										}else{
											
											StreamBlock3->WriteByte(block_3[offset]);
											StreamBlock3->WriteByte(block_3[offset + 1]);
											offset += 2;
										}

											BitOperation = BitOperation << 1;
											BitCount -= 1;

									}else{
									
									int off = OffsetDivOn2<<1;
									StreamBlock3->Seek(-off, SeekOrigin::Current);
									array<unsigned char>^ temp = gcnew array<unsigned char> (2);
									StreamBlock3->Read(temp, 0, 0x2);
									StreamBlock3->Seek(0, SeekOrigin::End);
									StreamBlock3->Write(temp, 0, 0x2);

									}

					}//else{	//if(BitOperation >= 0){//BGE ������ ��� �����, �������� ��������� ///�������� �������� �� ������������

//					bwAsync->ReportProgress(Convert::ToInt32(  StreamBlock3->Position *  100 / StreamBlock3->Length));
				
				} // for

				array<unsigned char>^ decompress = gcnew array<unsigned char>(StreamBlock3->Length);
				StreamBlock3->Seek(0, SeekOrigin::Begin);
				StreamBlock3->Read(decompress, 0, decompress->Length);
				return decompress;

	}



//				array<unsigned char>^ Parser(array<unsigned char>^ decompress, BackgroundWorker^ bwAsync){
///*				
//				int  type;
//				MemoryStream^ myStreamParser = gcnew MemoryStream(decompress);
//				BinaryReader^ br = gcnew BinaryReader(myStreamParser);
//				br->BaseStream->Seek(0x40100, SeekOrigin::Begin);
//				MemoryStream^ Stream = gcnew MemoryStream();
//				BinaryWriter^ bw = gcnew BinaryWriter(Stream);
//				
//				
//				unsigned int position;
//
//				while((type = br->ReadInt32()) != 0){
//				int len = br->ReadInt32();
//				int offset = br->ReadUInt32();
//				
//				switch(type){
//
//				case 0xF:
//					bw->Write(type);
//					bw->Write(len);
//					bw->Write(offset);
//					break;
//				
//				case 0xA:
//					bw->Write(type);
//					bw->Write(len);
//					bw->Write(offset);
//					break;
//
//
//				case 0x1:
//					bw->Write(type);
//					bw->Write(len);
//					bw->Write(offset);
//					break;
//
//				case 0x8:
//						position = br->BaseStream->Position;
//						br->BaseStream->Seek(offset, SeekOrigin::Begin);
//						unsigned int LenBlock = 0;
//						int m = 0;
//						
//						for(int i = 0; i < 0x40; i++){
//							LenBlock = br->ReadInt16();
//							bw->Write(type);
//							bw->Write(LenBlock);
//							bw->Write(offset + 0x80 + m);
//							m += LenBlock;
//						}
//						br->BaseStream->Seek(position, SeekOrigin::Begin);
//
//						break;
//					}//case
//
//				}//while
//
//
//				MemoryStream^ Stream_2 = gcnew MemoryStream();
//				BinaryWriter^ bw_2 = gcnew BinaryWriter(Stream_2);
//				BinaryReader^ br_2 = gcnew BinaryReader(Stream);
//				br_2->BaseStream->Seek(0, SeekOrigin::Begin);
//
//
//				while( br_2->BaseStream->Position < br_2->BaseStream->Length){
//				int type = br_2->ReadInt32();
//				int len = br_2->ReadInt32();
//				int offset = br_2->ReadUInt32();
//			
//				array<unsigned char>^ CompressedBlock = gcnew array<unsigned char>(len);
//				
//				
//				switch(type){
//
//				case 0xF:
//						br->BaseStream->Seek(offset, SeekOrigin::Begin);
//						br->BaseStream->Read(CompressedBlock, 0, len);
//						bw_2->BaseStream->Write(CompressedBlock, 0, len);
//						break;
//
//				case 0xA:
//						br->BaseStream->Seek(offset, SeekOrigin::Begin);
//						br->BaseStream->Read(CompressedBlock, 0, len);
//						bw_2->BaseStream->Write(CompressedBlock, 0, len);
//						break;
//
//				case 0x1:
//						br->BaseStream->Seek(offset, SeekOrigin::Begin);
//						br->BaseStream->Read(CompressedBlock, 0, len);
//						bw_2->BaseStream->Write((DecompressApp(CompressedBlock, bwAsync)), 0, 0x40000);
//						bwAsync->ReportProgress(Convert::ToInt32( br->BaseStream->Position *  100 / br->BaseStream->Length));
//						break;
//
//				case 0x8:
//						br->BaseStream->Seek(offset, SeekOrigin::Begin);
//						br->BaseStream->Read(CompressedBlock, 0, len);
//						if(len == 0x1000){
//						bw_2->BaseStream->Write(CompressedBlock, 0, len);	
//						}else{
//						bw_2->BaseStream->Write((DecompressApp(CompressedBlock, bwAsync)), 0, 0x1000);
//						bwAsync->ReportProgress(Convert::ToInt32( br->BaseStream->Position *  100 / br->BaseStream->Length));
//						}
//						break;
//
//
//
//
//
//					}//case
//
//				}//while
//
//					array<unsigned char>^ decrypt_decompress = gcnew array<unsigned char>(bw_2->BaseStream->Length);
//					bw_2->BaseStream->Seek(0,SeekOrigin::Begin);
//					bw_2->BaseStream->Read(decrypt_decompress, 0, decrypt_decompress->Length);
//
//					bw_2->Close();
//					br->Close();
//
//	*/
//
//				int  type;
//				MemoryStream^ myStreamParser = gcnew MemoryStream(decompress);
//				BinaryReader^ br = gcnew BinaryReader(myStreamParser);
//				
//				br->BaseStream->Seek(0x40100, SeekOrigin::Begin);
//				MemoryStream^ Stream = gcnew MemoryStream();
//				BinaryWriter^ bw = gcnew BinaryWriter(Stream);
//				
//
//				while((type = br->ReadInt32()) != 0){
//				int len = br->ReadInt32();
//				int offset = br->ReadUInt32();
//				int position2 = br->BaseStream->Position;
//				
//				array<unsigned char>^ CompressedBlock = gcnew array<unsigned char>(len);
//				
//				switch(type){
//
//				case 0xF:
//				case 0xA:
//				case 0x3:
//						br->BaseStream->Seek(offset, SeekOrigin::Begin);
//						br->BaseStream->Read(CompressedBlock, 0, len);
//						bw->BaseStream->Write(CompressedBlock, 0, len);
//					break;
//				
//				case 0x1:
//						br->BaseStream->Seek(offset, SeekOrigin::Begin);
//						br->BaseStream->Read(CompressedBlock, 0, len);
//						bw->BaseStream->Write((DecompressApp(CompressedBlock, bwAsync)), 0, 0x40000);
//						bwAsync->ReportProgress(Convert::ToInt32( br->BaseStream->Position *  100 / br->BaseStream->Length));
//					break;
//
//				case 0x8:
//						int position = br->BaseStream->Position;
//						br->BaseStream->Seek(offset, SeekOrigin::Begin);
//						unsigned int LenBlock = 0;
//						int m = 0;
//						
//						for(int i = 0; i < 0x40; i++){
//							LenBlock = br->ReadInt16();
//							int position1 = br->BaseStream->Position;
//
//							br->BaseStream->Seek(offset + 0x80 + m, SeekOrigin::Begin);
//							br->BaseStream->Read(CompressedBlock, 0, LenBlock);
//						if(LenBlock == 0x1000){
//						
//							bw->BaseStream->Write(CompressedBlock, 0, LenBlock);	
//						}else{
//						
//							bw->BaseStream->Write((DecompressApp(CompressedBlock, bwAsync)), 0, 0x1000);
//							bwAsync->ReportProgress(Convert::ToInt32( br->BaseStream->Position *  100 / br->BaseStream->Length));
//						}
//							m += LenBlock;
//							br->BaseStream->Seek(position1, SeekOrigin::Begin);
//
//						}
//						br->BaseStream->Seek(position, SeekOrigin::Begin);
//
//						break;
//					}//case
//						
//				br->BaseStream->Seek(position2, SeekOrigin::Begin);
//
//			}//while
//
//					array<unsigned char>^ decrypt_decompress = gcnew array<unsigned char>(bw->BaseStream->Length);
//					bw->BaseStream->Seek(0,SeekOrigin::Begin);
//					bw->BaseStream->Read(decrypt_decompress, 0, decrypt_decompress->Length);
//
//					bw->Close();
//					br->Close();
//
//					return decrypt_decompress;
//	}

				//array<unsigned char>^ DecryptCompressedBin( array<unsigned char>^ buffer, BackgroundWorker^ bwAsync){
				//	//return Parser(Decrypt( buffer, bwAsync), bwAsync);//decrypt;
				//	return Decompress(Decrypt( buffer, bwAsync));//decrypt;
				//
				//}


};