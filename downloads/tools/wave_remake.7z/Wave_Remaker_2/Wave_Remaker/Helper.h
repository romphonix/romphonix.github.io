#pragma once




namespace ImageUtils {


	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
//	using namespace ImageUtils;
	using namespace System::Security::Cryptography;
	using namespace System::Text;


#define ALIGN(x,a) (((x)+(a)-1)&~((a)-1))



/*		void autosign_file(String^ SaveFile)
			{
				BinaryReader^ br_sign = gcnew BinaryReader( File::Open(SaveFile, FileMode::Open) );
				br_sign->BaseStream->Seek( -4, SeekOrigin::End);
				int signature_offset;

				for (int n = 0; n < br_sign->BaseStream->Length / 4; n++){
					if(0xABCDABCD == br_sign->ReadInt32()){
					signature_offset = Convert::ToInt32(br_sign->BaseStream->Position) - 4;	
					break;
					}
					br_sign->BaseStream->Seek( -8, SeekOrigin::Current);
				}

				if((br_sign->BaseStream->Length - signature_offset) != 0x400){
				System::Windows::Forms::MessageBox::Show("Error len futter.","ERROR",MessageBoxButtons::OK, MessageBoxIcon::Error);
				return;
				}

				br_sign->BaseStream->Seek( 0, SeekOrigin::Begin);
				array<unsigned char>^ buff = gcnew array<unsigned char> (signature_offset);/////
				br_sign->Read(buff,0,buff->Length);
				MD5^ Md5hash = MD5::Create();
				array<unsigned char>^ sign = Md5hash->ComputeHash(buff);
				br_sign->Close();

				BinaryWriter^ bw_sign = gcnew BinaryWriter(File::Open( SaveFile, FileMode::Open ) );
				bw_sign->BaseStream->Seek( -0x1B8, SeekOrigin::End);
				bw_sign->Write(sign,0,sign->Length);
				System::Windows::Forms::MessageBox::Show("File is signed.","INFO",MessageBoxButtons::OK, MessageBoxIcon::Information);
				bw_sign->Close();

		}
*/

		void WalkTreeNode(TreeNode^ node, int level, TreeNode^ nodeselect,  TreeView^ treeView){

		 for each (TreeNode^ n in node->Nodes)
			{
				if(Object::Equals(n->Tag, nodeselect->Tag)){
				treeView->SelectedNode = n;
				break;
				}
				WalkTreeNode(n, level++, nodeselect, treeView);
			}

	}


		array<int>^ sign_files (array<int>^ block_hash, array<int>^ hash)
	{

				int v6 = hash[1]; // ���� 
				int v7 = hash[0]; // ����
				int v8 = hash[1]; //����
				int v9 = hash[2]; //����
				int v10 = block_hash[0] + (hash[1] & hash[2] | hash[3] & (-1 - hash[1]));
				unsigned int v11 = hash[1] + ((/*(unsigned int)*/(v7 + v10 + 0xD76AA478/*- 680876936*/) << 7) | (/*(unsigned int)*/(v7 + v10 + 0xD76AA478/*- 680876936*/) >> 25)); 
				unsigned int v12 = v11 + (((block_hash[1] + (v11 & v8 | v9 & (-1 - v11)) + hash[3] + 0xE8C7B756/*- 389564586*/) << 12) | ((block_hash[1] + (v11 & v8 | v9 & (-1 - v11)) + hash[3] + 0xE8C7B756/*- 389564586*/) >> 20)); 
				unsigned int v13 = v12 + (((block_hash[2] + (v11 & v12 | v8 & (-1 - v12)) + v9 + 606105819) << 17) | ((block_hash[2] + (v11 & v12 | v8 & (-1 - v12)) + v9 + 606105819) >> 15)); 
				unsigned int v14 = v13 + (((block_hash[3] + (v13 & v12 | v11 & (-1 - v13)) + v8 - 1044525330) >> 10) | ((block_hash[3] + (v13 & v12 | v11 & (-1 - v13)) + v8 - 1044525330) << 22)); 
				unsigned int v15 = v11 + block_hash[4] + (v14 & v13 | v12 & (-1 - v14)) - 176418897; 
				unsigned int v16 = v14 + ((v15 << 7) | (v15 >> 25)); 
				int v17 = block_hash[5] + (v16 & v14 | v13 & (-1 - v16));
				unsigned int v18 = v16 + (((v17 + v12 + 1200080426) << 12) | ((v17 + v12 + 1200080426) >> 20)); 
				int v19 = block_hash[6] + (v16 & v18 | v14 & (-1 - v18));
				unsigned int v20 = v18 + (((v19 + v13 - 1473231341) << 17) | ((v19 + v13 - 1473231341) >> 15)); 
				unsigned int v21 = v20 + (((block_hash[7] + (v20 & v18 | v16 & (-1 - v20)) + v14 - 45705983) >> 10) | ((block_hash[7] + (v20 & v18 | v16 & (-1 - v20)) + v14 - 45705983) << 22));
				unsigned int v22 = v21; 
				int v23 = block_hash[8] + (v21 & v20 | v18 & (-1 - v21)); 
				unsigned int v24 = v22 + (((v23 + v16 + 1770035416) << 7) | ((unsigned int)(v23 + v16 + 1770035416) >> 25)); 
				unsigned int v25 = v18 + block_hash[9] + (v24 & v22 | v20 & (-1 - v24)) - 1958414417; 
				int v26 = v24 + ((v25 << 12) | (v25 >> 20)); 
				int v27 = block_hash[10] + (v24 & v26 | v22 & (-1 - v26)); 
				unsigned int v28 = v26 + (((v27 + v20 - 42063) << 17) | ((v27 + v20 - 42063) >> 15)); 
				unsigned int v29 = v28 + (((block_hash[11] + (v28 & v26 | v24 & (-1 - v28)) + v22 - 1990404162) >> 10) | ((block_hash[11] + (v28 & v26 | v24 & (-1 - v28)) + v22 - 1990404162) << 22)); 
				unsigned int v30 = v29; 
				int v31 = block_hash[12] + (v29 & v28 | v26 & (-1 - v29)); 
				unsigned int v32 = v30 + (((v31 + v24 + 1804603682) << 7) | ((v31 + v24 + 1804603682) >> 25)); 
				unsigned int v33 = block_hash[13] + (v32 & v30 | v28 & (-1 - v32)) + v26 - 40341101; 
				int v34 = v32 + ((v33 << 12) | (v33 >> 20)); 
				unsigned int v35 = v28 + block_hash[14] + ((-1 - v34) & v30 | v32 & (v32 + ((v33 << 12) | (v33 >> 20)))) - 1502002290;
				int v36 = v34 + ((v35 << 17) | (v35 >> 15)); 
				unsigned int v37 = block_hash[15] + (v36 & v34 | v32 & (-1 - v36)) + v30 + 1236535329; 
				int v38 = v36 + ((v37 >> 10) | (v37 << 22)); 
				unsigned int v39 = v38 + (32 * (block_hash[1] + ((-1 - v34) & v36 | v38 & v34) + v32 - 165796510) | ((block_hash[1] + ((-1 - v34) & v36 | v38 & v34) + v32 - 165796510) >> 27)); 
				int v40 = block_hash[6] + (v39 & v36 | v38 & (-1 - v36)); 
				unsigned int v41 = v39 + (((v40 + v34 - 1069501632) << 9) | ((unsigned int)(v40 + v34 - 1069501632) >> 23)); 
				unsigned int v42 = block_hash[11] + (v38 & v41 | v39 & (-1 - v38)) + v36 + 643717713; 
				int v43 = v41 + ((v42 << 14) | (v42 >> 18)); 
				unsigned int v44 = v43 + (((block_hash[0] + (v39 & v43 | v41 & (-1 - v39)) + v38 - 373897302) >> 12) | ((block_hash[0] + (v39 & v43 | v41 & (-1 - v39)) + v38 - 373897302) << 20)); 
				unsigned int v45 = v39 + block_hash[5] + (v44 & v41 | v43 & (-1 - v41)) - 701558691; 
				int v46 = v44 + (32 * v45 | (v45 >> 27)); 
				int v47 = block_hash[10] + (v46 & v43 | v44 & (-1 - v43)); 
				unsigned int v48 = v46 + (((v47 + v41 + 38016083) << 9) | ((v47 + v41 + 38016083) >> 23)); 
				unsigned int v49 = block_hash[15] + (v44 & v48 | v46 & (-1 - v44)) + v43 - 660478335; 
				int v50 = v48 + ((v49 << 14) | (v49 >> 18)); 
				unsigned int v51 = v50 + (((block_hash[4] + (v46 & v50 | v48 & (-1 - v46)) + v44 - 405537848) >> 12) | ((block_hash[4] + (v46 & v50 | v48 & (-1 - v46)) + v44 - 405537848) << 20)); 
				int v52 = block_hash[9] + (v51 & v48 | v50 & (-1 - v48)); 
				unsigned int v53 = v51 + (32 * (v52 + v46 + 568446438) | ((unsigned int)(v52 + v46 + 568446438) >> 27)); 
				unsigned int v54 = v48 + block_hash[14] + (v53 & v50 | v51 & (-1 - v50)) - 1019803690; 
				int v55 = v53 + ((v54 << 9) | (v54 >> 23)); 
				unsigned int v56 = block_hash[3] + (v51 & v55 | v53 & (-1 - v51)) + v50 - 187363961; 
				int v57 = v55 + ((v56 << 14) | (v56 >> 18)); 
				unsigned int v58 = v57 + (((block_hash[8] + (v53 & v57 | v55 & (-1 - v53)) + v51 + 1163531501) >> 12) | ((block_hash[8] + (v53 & v57 | v55 & (-1 - v53)) + v51 + 1163531501) << 20)); 
				int v59 = block_hash[13] + (v58 & v55 | v57 & (-1 - v55)); 
				unsigned int v60 = v58 + (32 * (v59 + v53 - 1444681467) | ((v59 + v53 - 1444681467) >> 27)); 
				int v61 = block_hash[2] + (v60 & v57 | v58 & (-1 - v57)); 
				unsigned int v62 = v60 + (((v61 + v55 - 51403784) << 9) | ((unsigned int)(v61 + v55 - 51403784) >> 23)); 
				unsigned int v63 = v57 + block_hash[7] + (v58 & v62 | v60 & (-1 - v58)) + 1735328473; 
				int v64 = v62 + ((v63 << 14) | (v63 >> 18)); 
				unsigned int v65 = block_hash[12] + (v60 & v64 | v62 & (-1 - v60)) + v58 - 1926607734; 
				int v66 = v64 + ((v65 >> 12) | (v65 << 20)); 
				int v67 = block_hash[5] + (v66 ^ v64 ^ v62); 
				unsigned int v68 = v66 + (16 * (v67 + v60 - 378558) | ((v67 + v60 - 378558) >> 28)); 
				int v69 = block_hash[8] + (v68 ^ v66 ^ v64); 
				unsigned int v70 = v68 + (((v69 + v62 - 2022574463) << 11) | ((v69 + v62 - 2022574463) >> 21)); 
				int v71 = block_hash[11] + (v68 ^ v66 ^ v70); 
				unsigned int v72 = v70 + (((v71 + v64 + 1839030562) << 16) | ((unsigned int)(v71 + v64 + 1839030562) >> 16)); 
				unsigned int v73 = v66 + block_hash[14] + (v68 ^ v72 ^ v70) - 35309556;
				int v74 = v72 + ((v73 >> 9) | (v73 << 23)); 
				int v75 = block_hash[1] + (v74 ^ v72 ^ v70); 
				unsigned int v76 = v74 + (16 * (v75 + v68 - 1530992060) | ((v75 + v68 - 1530992060) >> 28));
				int v77 = block_hash[4] + (v76 ^ v74 ^ v72);
				unsigned int v78 = v76 + (((v77 + v70 + 1272893353) << 11) | ((v77 + v70 + 1272893353) >> 21));
				unsigned int v79 = block_hash[7] + (v76 ^ v74 ^ v78) + v72 - 155497632; 
				int v80 = v78 + ((v79 << 16) | (v79 >> 16)); 
				unsigned int v81 = block_hash[10] + (v76 ^ v80 ^ v78) + v74 - 1094730640; 
				int v82 = v80 + ((v81 >> 9) | (v81 << 23)); 
				int v83 = block_hash[13] + (v82 ^ v80 ^ v78); 
				unsigned int v84 = v82 + (16 * (v76 + v83 + 681279174) | ((v76 + v83 + 681279174) >> 28)); 
				unsigned int v85 = v84 + (((block_hash[0] + (v84 ^ v82 ^ v80) + v78 - 358537222) << 11) | ((block_hash[0] + (v84 ^ v82 ^ v80) + v78 - 358537222) >> 21)); 
				unsigned int v86 = block_hash[3] + (v84 ^ v82 ^ v85) + v80 - 722521979; 
				int v87 = v85 + ((v86 << 16) | (v86 >> 16)); 
				unsigned int v88 = block_hash[6] + (v84 ^ v87 ^ v85) + v82 + 76029189; 
				int v89 = (v88 >> 9) | (v88 << 23); 
				int v90 = block_hash[9]; 
				int v91 = v87 + v89; 
				unsigned int v92 = v84 + v90 + (v91 ^ v87 ^ v85) - 640364487; 
				int v93 = v91 + (16 * v92 | (v92 >> 28)); 
				unsigned int v94 = block_hash[12] + (v93 ^ v91 ^ v87) + v85 - 421815835; 
				int v95 = v93 + ((v94 << 11) | (v94 >> 21)); 
				unsigned int v96 = block_hash[15] + (v93 ^ v91 ^ (v93 + ((v94 << 11) | (v94 >> 21)))) + v87 + 530742520; 
				int v97 = v95 + ((v96 << 16) | (v96 >> 16)); 
				unsigned int v98 = block_hash[2] + (v93 ^ v97 ^ v95) + v91 - 995338651; 
				int v99 = v97 + ((v98 >> 9) | (v98 << 23));
				unsigned int v100 = v93 + block_hash[0] + (v97 ^ (v99 | (-1 - v95))) - 198630844;
				int v101 = v99 + ((v100 << 6) | (v100 >> 26)); 
				int v102 = block_hash[7] + (v99 ^ (v101 | (-1 - v97))); 
				unsigned int v103 = v101 + (((v102 + v95 + 1126891415) << 10) | ((unsigned int)(v102 + v95 + 1126891415) >> 22)); 
				unsigned int v104 = block_hash[14] + (v101 ^ (v103 | (-1 - v99))) + v97 - 1416354905; 
				int v105 = v103 + ((v104 << 15) | (v104 >> 17)); 
				unsigned int v106 = block_hash[5] + (v103 ^ (v105 | (-1 - v101))) + v99 - 57434055;
				int v107 = v105 + ((v106 >> 11) | (v106 << 21)); 
				unsigned int v108 = block_hash[12] + (v105 ^ (v107 | (-1 - v103))) + v101 + 1700485571; 
				int v109 = v107 + ((v108 << 6) | (v108 >> 26)); 
				unsigned int v110 = v103 + block_hash[3] + (v107 ^ (v109 | (-1 - v105))) - 1894986606; 
				int v111 = v109 + ((v110 << 10) | (v110 >> 22)); 
				int v112 = block_hash[10] + (v109 ^ (v111 | (-1 - v107))); 
				unsigned int v113 = v111 + (((v112 + v105 - 1051523) << 15) | ((unsigned int)(v112 + v105 - 1051523) >> 17)); 
				unsigned int v114 = block_hash[1] + (v111 ^ (v113 | (-1 - v109))) + v107 - 2054922799; 
				int v115 = v113 + ((v114 >> 11) | (v114 << 21)); 
				unsigned int v116 = block_hash[8] + (v113 ^ (v115 | (-1 - v111))) + v109 + 1873313359;
				int v117 = v115 + ((v116 << 6) | (v116 >> 26)); 
				unsigned int v118 = block_hash[15] + (v115 ^ (v117 | (-1 - v113))) + v111 - 30611744; 
				int v119 = v117 + ((v118 << 10) | (v118 >> 22)); 
				unsigned int v120 = v113 + block_hash[6] + (v117 ^ (v119 | (-1 - v115))) - 1560198380; 
				int v121 = v119 + ((v120 << 15) | (v120 >> 17)); 
				int v122 = block_hash[13] + (v119 ^ (v121 | (-1 - v117)));
				unsigned int v123 = v121 + (((unsigned int)(v122 + v115 + 1309151649) >> 11) | ((v122 + v115 + 1309151649) << 21)); 
				unsigned int v124 = block_hash[4] + (v121 ^ (v123 | (-1 - v119))) + v117 - 145523070; 
				int v125 = v123 + ((v124 << 6) | (v124 >> 26)); 
				unsigned int v126 = block_hash[11] + (v123 ^ (v125 | (-1 - v121))) + v119 - 1120210379; 
				int v127 = v125 + ((v126 << 10) | (v126 >> 22)); 
				unsigned int v128 = block_hash[2] + (v125 ^ (v127 | (-1 - v123))) + v121 + 718787259; 
				int v129 = v127 + ((v128 << 15) | (v128 >> 17));
				int v130 = v90 + (v127 ^ (v129 | (-1 - v125))); 
				int v131 = v129 + hash[2];
				unsigned int v132 = v123 + v130 - 343485551; 
				int v133 = v125 + v7; 
				int v134 = v129 + ((v132 >> 11) | (v132 << 21)); 
				int v135 = v127 + hash[3];
				v6 += v134;
				hash[1] = v6;
				v7 = v133;
				hash[0] = v7;
				hash[2] = v131; 
				//result = hash[3];
				hash[3] = v135;
				return hash; 

	}



		void autosign_file(String^ SaveFile)
			{
				BinaryReader^ br_sign = gcnew BinaryReader( File::Open(SaveFile/*myStream_sign*/, FileMode::Open) );

				array<int>^ hash = gcnew array<int>(4){0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476};
				array<int>^ block_hash = gcnew array<int>(0x10); 

				br_sign->BaseStream->Seek( -4, SeekOrigin::End);
				int signature_offset;

				for (int n = 0; n < br_sign->BaseStream->Length / 4; n++){
					
					if(0xABCDABCD == br_sign->ReadInt32()){
					signature_offset = Convert::ToInt32(br_sign->BaseStream->Position) - 4;	
					break;
					}
					br_sign->BaseStream->Seek( -8, SeekOrigin::Current);
				}


				if((br_sign->BaseStream->Length - signature_offset) != 0x400){
				System::Windows::Forms::MessageBox::Show("Error len futter.","ERROR",MessageBoxButtons::OK, MessageBoxIcon::Error);
				return;
				}

				br_sign->BaseStream->Seek( 0, SeekOrigin::Begin);

				for(int k = 0; k < Math::Abs(signature_offset / 0x40); k++){

						for (int i = 0; i < 0x10; i++){
							block_hash[i] = br_sign->ReadInt32();
						}
					hash = sign_files(block_hash/*br_sign*/, hash);
				}


				if(br_sign->BaseStream->Length % 0x40){
					
					block_hash->Clear(block_hash, 0, block_hash->Length);
					
					for (int i = 0; i < (br_sign->BaseStream->Length % 0x40) / 4; i++){
						block_hash[i] = br_sign->ReadInt32();
					}
					hash = sign_files(block_hash/*br_sign*/, hash);
				}
				
				block_hash->Clear(block_hash, 0, block_hash->Length);
				block_hash[0] = 0x80;
				block_hash[block_hash->Length - 2] = ALIGN(signature_offset, 0x40) * 8;
				hash = sign_files(block_hash/*br_sign*/, hash);
				
				br_sign->Close();

				BinaryWriter^ bw_sign = gcnew BinaryWriter(File::Open( SaveFile, FileMode::Open ) );
				bw_sign->BaseStream->Seek( -0x1B8, SeekOrigin::End);
				
				 try
					  {
						 bw_sign->Write( hash[0] );
						 bw_sign->Write( hash[1] );
						 bw_sign->Write( hash[2] );
						 bw_sign->Write( hash[3] );
					  }
					  finally
					  {
						 bw_sign->Close();
					  }

					  System::Windows::Forms::MessageBox::Show("File is signed.","INFO",MessageBoxButtons::OK, MessageBoxIcon::Information);


		}




		void autosign_buffer(array <unsigned char>^ part)
			{
				MemoryStream^ stream = gcnew MemoryStream(part);
				BinaryReader^ br_sign = gcnew BinaryReader( stream/*File::Open(SaveFile, FileMode::Open)*/ );
				br_sign->BaseStream->Seek( -4, SeekOrigin::End);
				int signature_offset;

				for (int n = 0; n < br_sign->BaseStream->Length / 4; n++){
					if(0xABCDABCD == br_sign->ReadInt32()){
					signature_offset = Convert::ToInt32(br_sign->BaseStream->Position) - 4;	
					break;
					}
					br_sign->BaseStream->Seek( -8, SeekOrigin::Current);
				}
				
				if((br_sign->BaseStream->Length - signature_offset) != 0x400){
				System::Windows::Forms::MessageBox::Show("Error len futter.","ERROR",MessageBoxButtons::OK, MessageBoxIcon::Error);
				return;
				}

				br_sign->BaseStream->Seek( 0, SeekOrigin::Begin);
				array<unsigned char>^ buff = gcnew array<unsigned char> (signature_offset);
				br_sign->Read(buff,0,buff->Length);
				MD5^ Md5hash = MD5::Create();
				array<unsigned char>^ sign = Md5hash->ComputeHash(buff);

				BinaryWriter^ bw_sign = gcnew BinaryWriter(stream/*File::Open( SaveFile, FileMode::Open )*/ );
				bw_sign->BaseStream->Seek( -0x1B8, SeekOrigin::End);
				bw_sign->Write(sign,0,sign->Length);
//				bw_sign->Flush();
//				System::Windows::Forms::MessageBox::Show("File is signed.","INFO",MessageBoxButtons::OK, MessageBoxIcon::Information);
				
				bw_sign->BaseStream->Seek(0,SeekOrigin::Begin);
				bw_sign->BaseStream->Read(part,0,part->Length);
				
				stream->Close();
				br_sign->Close();
				bw_sign->Close();				

		}




			typedef struct
			{
				unsigned int magic;					//ABCDABCD
				unsigned int unknown0;
				unsigned int null1;					//0x00000000
				unsigned char name[0x20];			//S8500
				unsigned char type_file[0x4];		//bin
				unsigned int null2;
				unsigned int unknown1;				//0x06
				unsigned int check_sec;				//0x02 check--0x01uncheck
				unsigned int unknown2;				//0x02
				unsigned int unknown3;				//0x800
				unsigned int unknown4;				//0x20000
				unsigned int unknown5;				//0x79461379
				unsigned int unknown6;				//
				unsigned char RSA_HASH[0xC0];		//
				unsigned int SEED_KEY[32];
				unsigned int unknown7;				//0x79461379
				unsigned int file_len;
				unsigned int key_end[0x4];
				unsigned char RSA1_SIGN[0x40];		//
				unsigned char firmware_name[0x40];	//
				unsigned char Tk_Tool[0x20];		//
				unsigned int MD5_HASH[0x4];			//
				unsigned char futter[0x1A8];		//null

			} t_futter;




};