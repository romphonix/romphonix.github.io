﻿
//#include "Crc32.h"
//#include "ZipDirectoryEntry.h"
//#include "ZipEntry.h"
#include "ZipFileEntry.h"


using namespace System;
using namespace System::Collections::Generic;
using namespace System::Text;
using namespace System::IO;
using namespace System::IO::Compression;
using namespace System::Runtime::InteropServices;

namespace TinySharpZip
{
    public enum CompressionMethod
    {
        Store = 0,
        Deflate = 8
    };

	public ref class ZipArchive
	{
		#pragma region Private Variables

	private:
		static initonly System::UInt32 LOCAL_FILE_HEADER_SIGNATURE = 0x04034b50;
		static initonly System::UInt32 CENTRAL_FILE_HEADER_SIGNATURE = 0x02014b50;
		static initonly System::UInt32 END_OF_CENTRAL_DIR_SIGNATURE = 0x06054b50;
		static initonly System::UInt16 VERSION_NEEDED_TO_EXTRACT = 0x0014;
		static initonly System::UInt16 COMPRESSION_STORE = 0;
		static initonly System::UInt16 COMPRESSION_DEFLATE = 8;
		static initonly System::UInt16 UTF8_FILE_NAME_ENCODING_FLAG = 1 << 11;

		static initonly int STREAM_EXCHANGE_BUFFER_SIZE = 0x1000;
		static initonly System::String ^ARCHIVE_FORMAT_NOT_SUPPORTED_STRING = "Archive format is not supported.";

		List<ZipEntry^> ^entries;

		#pragma endregion

		#pragma region Constructors

	public:
		ZipArchive()
		{
			entries = gcnew List<ZipEntry^>();
		}

		#pragma endregion

		#pragma region Public Properties

		property List<ZipEntry^> ^Entries
		{
			List<ZipEntry^> ^get()
			{
				return entries;
			}
			void set(List<ZipEntry^> ^value)
			{
				entries = value;
			}
		}

		#pragma endregion


        [DllImport("kernel32.dll")]
        static System::UInt32 GetOEMCP();




		void ReadFrom(Stream ^zipStream)
		{
			while (zipStream->Position < zipStream->Length)
			{
				BinaryReader ^reader = gcnew BinaryReader(zipStream, Encoding::ASCII);
				System::UInt32 localFileHeaderSignature = reader->ReadUInt32();
				if (localFileHeaderSignature != LOCAL_FILE_HEADER_SIGNATURE)
				{
					// Local file entries are finished, next records are central directory records
					break;
				}
				System::UInt16 versionNeededToExtract = reader->ReadUInt16();
				System::UInt16 generalPurposeBitFlag = reader->ReadUInt16();
				System::UInt16 compressionMethod = reader->ReadUInt16();
				if (compressionMethod != COMPRESSION_DEFLATE && compressionMethod != COMPRESSION_STORE)
				{
					throw gcnew NotSupportedException(ARCHIVE_FORMAT_NOT_SUPPORTED_STRING);
				}
				System::UInt32 lastModifiedDateTime = reader->ReadUInt32();
				System::UInt32 crc32 = reader->ReadUInt32();
				System::UInt32 compressedSize = reader->ReadUInt32();
				System::UInt32 uncompressedSize = reader->ReadUInt32();
				System::UInt16 fileNameLength = reader->ReadUInt16();
				System::UInt16 extraFieldLength = reader->ReadUInt16();
				if (extraFieldLength != 0)
				{
					throw gcnew NotSupportedException(ARCHIVE_FORMAT_NOT_SUPPORTED_STRING);
				}

				array<System::Byte> ^fileNameBytes = reader->ReadBytes(fileNameLength);
				Encoding ^fileNameEncoding;
				if ((generalPurposeBitFlag & UTF8_FILE_NAME_ENCODING_FLAG) != 0)
				{
					fileNameEncoding = gcnew UTF8Encoding();
				}
				else
				{
					fileNameEncoding = Encoding::GetEncoding(safe_cast<int>(GetOEMCP()));
				}
				System::String ^fileName = fileNameEncoding->GetString(fileNameBytes);

				// According to ZIP specification, ZIP archives generally 
				// contain forward slashes so make Windows file name
				fileName = fileName->Replace('/', Path::DirectorySeparatorChar);

				ZipEntry ^entry = nullptr;
				if (uncompressedSize != 0)
				{
					array<System::Byte> ^fileData = reader->ReadBytes(safe_cast<int>(compressedSize));
					MemoryStream ^fileDataStream = gcnew MemoryStream(fileData);
					ZipFileEntry ^fileEntry = gcnew ZipFileEntry(fileName, fileDataStream);
					if (compressionMethod == COMPRESSION_DEFLATE)
					{
						fileDataStream->Position = 0;
						DeflateStream ^deflateStream = gcnew DeflateStream(fileDataStream, CompressionMode::Decompress);

						array<System::Byte> ^uncompressedFileData = gcnew array<System::Byte>(uncompressedSize);

						deflateStream->Read(uncompressedFileData, 0, safe_cast<int>(uncompressedSize));
						fileEntry->Data = gcnew MemoryStream(uncompressedFileData);
					}
					entry = fileEntry;
				}
				else if (fileName->EndsWith("\\"))
				{
					entry = gcnew ZipDirectoryEntry(fileName);
				}
				else
				{
					entry = gcnew ZipFileEntry(fileName, nullptr);
				}
				entry->SetLastModifiedDateTime(lastModifiedDateTime);
				entries->Add(entry);
			}

		}


		void WriteTo(Stream ^zipStream)
		{
			WriteTo(zipStream, CompressionMethod::Deflate);
		}

		void WriteTo(Stream ^zipStream, CompressionMethod compressionMethod)
		{
			WriteTo(zipStream, CompressionMethod::Deflate, false);
		}

		void WriteTo(Stream ^zipStream, CompressionMethod compressionMethod, bool encodeFileNamesInUTF8)
		{
			MemoryStream ^centralDirectory = gcnew MemoryStream();
			BinaryWriter ^centralDirectoryWriter = gcnew BinaryWriter(centralDirectory);
			BinaryWriter ^zipStreamWriter = gcnew BinaryWriter(zipStream);
			for each (ZipEntry ^entry in entries)
			{
				Encoding ^fileNameEncoding = encodeFileNamesInUTF8 ? gcnew UTF8Encoding() : Encoding::GetEncoding(safe_cast<int>(GetOEMCP()));

				System::UInt32 crc32 = 0;
				System::UInt32 compressedSize = 0;
				System::UInt32 uncompressedSize = 0;
				System::String ^fileName = nullptr;
				Stream ^compressedData = nullptr;

				if (dynamic_cast<ZipFileEntry^>(entry) != nullptr)
				{
					ZipFileEntry ^fileEntry = dynamic_cast<ZipFileEntry^>(entry);
					fileName = fileEntry->FileName;

					if (fileEntry->Data != nullptr && fileEntry->Data->Length != 0)
					{
						compressedData = fileEntry->Data;
						if (compressionMethod == CompressionMethod::Deflate)
						{
							MemoryStream ^compressedStream = gcnew MemoryStream();
							DeflateStream ^deflateStream = gcnew DeflateStream(compressedStream, CompressionMode::Compress, true);
							WriteStream(fileEntry->Data, deflateStream);
							deflateStream->Close();
							compressedData = compressedStream;
						}
						crc32 = fileEntry->Crc;
						compressedSize = safe_cast<System::UInt32>(compressedData->Length);
						uncompressedSize = safe_cast<System::UInt32>(fileEntry->Data->Length);
					}
					else
					{
						crc32 = 0;
						compressedSize = 0;
						uncompressedSize = 0;
					}
				}
				else
				{
					ZipDirectoryEntry ^directoryEntry = dynamic_cast<ZipDirectoryEntry^>(entry);
					fileName = directoryEntry->DirectoryName;
				}
				// According to ZIP specification, file names should use only forward slashes
				// to be compatible with Unix file systems
				fileName = fileName->Replace(Path::DirectorySeparatorChar, '/');
				if (dynamic_cast<ZipDirectoryEntry^>(entry) != nullptr && !fileName->EndsWith("/"))
				{
					// Directories should contain slash at the end
					fileName += "/";
				}
				array<System::Byte> ^fileNameBytes = fileNameEncoding->GetBytes(fileName);

				System::UInt16 versionNeededToExtract = VERSION_NEEDED_TO_EXTRACT;
				System::UInt16 generalPurposeBitFlag = encodeFileNamesInUTF8 ? UTF8_FILE_NAME_ENCODING_FLAG : safe_cast<System::UInt16>(0);
				System::UInt32 lastModifiedDateTime = entry->GetLastModifiedDateTime();
				System::UInt16 fileNameLength = safe_cast<System::UInt16>(fileNameBytes->Length);
				System::UInt16 extraFieldLength = 0;

				System::UInt32 localHeaderPosition = safe_cast<System::UInt32>(zipStream->Position);
				zipStreamWriter->Write(LOCAL_FILE_HEADER_SIGNATURE);
				zipStreamWriter->Write(versionNeededToExtract);
				zipStreamWriter->Write(generalPurposeBitFlag);
				zipStreamWriter->Write(safe_cast<System::UInt16>(compressionMethod));
				zipStreamWriter->Write(lastModifiedDateTime);
				zipStreamWriter->Write(crc32);
				zipStreamWriter->Write(compressedSize);
				zipStreamWriter->Write(uncompressedSize);
				zipStreamWriter->Write(fileNameLength);
				zipStreamWriter->Write(extraFieldLength);
				zipStreamWriter->Write(fileNameBytes, 0, fileNameBytes->Length);

				if (compressedData != nullptr)
				{
					WriteStream(compressedData, zipStream);
				}

				centralDirectoryWriter->Write(CENTRAL_FILE_HEADER_SIGNATURE);
				centralDirectoryWriter->Write(VERSION_NEEDED_TO_EXTRACT);
				centralDirectoryWriter->Write(VERSION_NEEDED_TO_EXTRACT);
				centralDirectoryWriter->Write(generalPurposeBitFlag);
				centralDirectoryWriter->Write(safe_cast<System::UInt16>(compressionMethod));
				centralDirectoryWriter->Write(lastModifiedDateTime);
				centralDirectoryWriter->Write(crc32);
				centralDirectoryWriter->Write(compressedSize);
				centralDirectoryWriter->Write(uncompressedSize);
				centralDirectoryWriter->Write(fileNameLength);
				centralDirectoryWriter->Write(extraFieldLength);
				centralDirectoryWriter->Write(safe_cast<System::UInt16>(0)); // file comment length
				centralDirectoryWriter->Write(safe_cast<System::UInt16>(0)); // disk number start
				centralDirectoryWriter->Write(safe_cast<System::UInt16>(0)); // internal file attributes
				centralDirectoryWriter->Write(safe_cast<System::UInt32>(0)); // external file attributes
				centralDirectoryWriter->Write(localHeaderPosition); // relative offset of local header
				centralDirectoryWriter->Write(fileNameBytes, 0, fileNameBytes->Length);
			}
			System::UInt32 centralDirectorySize = safe_cast<System::UInt32>(centralDirectory->Length);
			System::UInt32 centralDirectoryOffset = safe_cast<System::UInt32>(zipStream->Position);
			centralDirectoryWriter->Write(END_OF_CENTRAL_DIR_SIGNATURE);
			centralDirectoryWriter->Write(safe_cast<System::UInt16>(0)); // number of this disk
			centralDirectoryWriter->Write(safe_cast<System::UInt16>(0)); // number of the disk with the start of the central directory
			centralDirectoryWriter->Write(safe_cast<System::UInt16>(entries->Count)); // total number of entries in the central directory on this disk
			centralDirectoryWriter->Write(safe_cast<System::UInt16>(entries->Count)); // total number of entries in the central directory
			centralDirectoryWriter->Write(safe_cast<System::UInt32>(centralDirectorySize)); // size of the central directory
			centralDirectoryWriter->Write(safe_cast<System::UInt32>(centralDirectoryOffset)); // offset of start of central directory with respect to the starting disk number
			centralDirectoryWriter->Write(safe_cast<System::UInt16>(0)); //.ZIP file comment length
			WriteStream(centralDirectory, zipStream);
		}




		static void Extract(Stream ^zipStream, System::String ^targetDirectory)
		{
			ZipArchive ^zipArchive = gcnew ZipArchive();
			zipArchive->ReadFrom(zipStream);
			for each (ZipEntry ^entry in zipArchive->Entries)
			{
				if (dynamic_cast<ZipFileEntry^>(entry) != nullptr)
				{
					ZipFileEntry ^fileEntry = dynamic_cast<ZipFileEntry^>(entry);
					System::String ^absoluteFilePath = Path::Combine(targetDirectory, fileEntry->FileName);
					System::String ^directoryName = Path::GetDirectoryName(absoluteFilePath);
					if (!Directory::Exists(directoryName))
					{
						Directory::CreateDirectory(directoryName);
					}
					if (File::Exists(absoluteFilePath))
					{
						File::Delete(absoluteFilePath);
					}
					FileStream ^fileStream = gcnew FileStream(absoluteFilePath, FileMode::CreateNew);
					if (fileEntry->Data != nullptr && fileEntry->Data->Length != 0)
					{
						WriteStream(fileEntry->Data, fileStream);
					}
					fileStream->Close();
				}
				else if (dynamic_cast<ZipDirectoryEntry^>(entry) != nullptr)
				{
					ZipDirectoryEntry ^directoryEntry = dynamic_cast<ZipDirectoryEntry^>(entry);
					System::String ^directoryName = Path::Combine(targetDirectory, directoryEntry->DirectoryName);
					if (!Directory::Exists(directoryName))
					{
						Directory::CreateDirectory(directoryName);
					}
				}
			}
		}



		static void CreateFromFile(System::String ^sourceFile, Stream ^outputZipStream)
		{
			if (File::Exists(sourceFile))
			{
				ZipArchive ^archive = gcnew ZipArchive();
				System::String ^fileName = Path::GetFileName(sourceFile);
				Stream ^fileData = gcnew FileStream(sourceFile, FileMode::Open);
				ZipFileEntry ^fileEntry = gcnew ZipFileEntry(fileName, fileData);
				archive->Entries->Add(fileEntry);
				archive->WriteTo(outputZipStream);
			}
		}



		static void CreateFromDirectory(System::String ^sourceDirectory, Stream ^outputZipStream)
		{
			CreateFromDirectory(sourceDirectory, outputZipStream, true);
		}

		static void CreateFromDirectory(System::String ^sourceDirectory, Stream ^outputZipStream, bool includeRootDirectoryName)
		{
			if (Directory::Exists(sourceDirectory))
			{
				DirectoryInfo ^rootDirectoryInfo = gcnew DirectoryInfo(sourceDirectory);
				ZipArchive ^archive = gcnew ZipArchive();
				System::String ^currentDirectory = "";
				if (includeRootDirectoryName)
				{
					currentDirectory = rootDirectoryInfo->Name;
					rootDirectoryInfo = rootDirectoryInfo->Parent;
				}

				bool directoryHasEntries = AddDirectory(archive, rootDirectoryInfo, currentDirectory);
				archive->WriteTo(outputZipStream);

			}
		}





	private:
		static void WriteStream(Stream ^sourceStream, Stream ^targetStream)
		{
			sourceStream->Position = 0;
			array<System::Byte> ^buffer = gcnew array<System::Byte>(STREAM_EXCHANGE_BUFFER_SIZE);
			while (true)
			{
				int bytesRead = sourceStream->Read(buffer, 0, buffer->Length);
				if (bytesRead == 0)
				{
					break;
				}
				targetStream->Write(buffer, 0, bytesRead);
			}
		}

		static bool AddDirectory(ZipArchive ^zipArchive, DirectoryInfo ^rootDirectoryInfo, System::String ^currentDirectory)
		{
			System::String ^fullDirectoryPath = Path::Combine(rootDirectoryInfo->FullName, currentDirectory);
			DirectoryInfo ^directoryInfo = gcnew DirectoryInfo(fullDirectoryPath);
			array<FileSystemInfo^> ^fileSystemInfos = directoryInfo->GetFileSystemInfos();
			for each (FileSystemInfo ^fileSystemInfo in fileSystemInfos)
			{
				if (dynamic_cast<FileInfo^>(fileSystemInfo) != nullptr)
				{
					FileInfo ^childFileInfo = dynamic_cast<FileInfo^>(fileSystemInfo);
					System::String ^fileName = Path::Combine(currentDirectory, childFileInfo->Name);
					FileStream ^fileData = gcnew FileStream(childFileInfo->FullName, FileMode::Open);
					ZipFileEntry ^fileEntry = gcnew ZipFileEntry(fileName, fileData);
					zipArchive->Entries->Add(fileEntry);
				}
				else if (dynamic_cast<DirectoryInfo^>(fileSystemInfo) != nullptr)
				{
					DirectoryInfo ^childDirectoryInfo = dynamic_cast<DirectoryInfo^>(fileSystemInfo);
					System::String ^directoryName = Path::Combine(currentDirectory, childDirectoryInfo->Name);
					bool directoryHasEntries = AddDirectory(zipArchive, rootDirectoryInfo, directoryName);
					if (!directoryHasEntries)
					{
						ZipDirectoryEntry ^directoryEntry = gcnew ZipDirectoryEntry(directoryName);
						zipArchive->Entries->Add(directoryEntry);
					}
				}
			}
			return (fileSystemInfos->Length != 0);
		}



    };
}
