#pragma once

#include "SEED_Crypto.h"


namespace ImageUtils {


//	using namespace System;
//	using namespace System::ComponentModel;
//	using namespace System::Collections;
//	using namespace System::Windows::Forms;
//	using namespace System::Data;
//	using namespace System::Drawing;
//	using namespace System::IO;


//	#define ALIGN(x,a) (((x)+(a)-1)&~((a)-1))

//	unsigned int G_CountBit;//
//	unsigned int G_BitOperation;//
//	unsigned int G_Offset;//
//	unsigned int G_CountDword;//
//	unsigned int G_CaseSwitch;// 
//	unsigned int G_R3;//
//	unsigned int G_BitsBuffer;//
//
//
//	static const unsigned short difftable[256] = {
//                1,               3,           0x100,               2,               8,               7,               6,           0x300,            0x10,               4,
//            0x200,               9,            0x40,            0x18,               5,            0x20,             0xC,             0xE,             0xF,             0xA,
//             0xC0,           0x800,           0x700,           0x400,             0xB,            0x30,            0x11,            0x80,           0x600,             0xD,
//             0x12,            0x1C,           0x500,            0x1B,            0x1E,            0x14,            0x1A,            0x28,            0x38,          0x1000,
//             0x1F,            0x19,            0x16,            0x60,          0x2000,            0x13,            0x1D,            0x24,            0x17,            0x15,
//            0xF00,            0x3C,           0xC00,          0x1800,            0x48,            0x21,            0x34,           0xE00,            0x2C,            0x70,
//            0xA00,            0x36,            0x3F,           0xD00,            0x3E,          0x3000,           0x900,            0x78,            0x22,            0x50,
//             0x3A,            0x41,            0x33,            0x26,            0x2A,            0xA0,            0x23,            0x29,            0x88,            0x44,
//             0x3D,            0xE0,            0x32,            0x2E,            0x39,            0x31,            0x2D,            0xF0,           0xB00,            0x3B,
//             0x58,          0x4000,            0x37,            0x35,            0x68,            0x7C,            0x2F,            0x27,            0x64,            0x90,
//             0x74,            0x6C,          0x1100,            0xFF,            0x25,          0xF000,          0x1F00,            0x42,            0x7F,            0x2B,
//             0x54,          0x1C00,            0x4C,            0x43,          0x6000,            0x5C,            0x7E,            0xE8,            0xF8,          0xE000,
//           0x1E00,            0x61,            0x7A,            0x4E,            0xC8,          0x8000,          0x1D00,            0xD0,            0x72,            0x49,
//           0x1600,          0x1A00,            0x46,          0x7000,            0x76,          0x1200,          0x1400,            0xFC,          0x1700,            0x6E,
//             0xFE,          0x1300,            0x62,            0x66,          0xC000,            0x63,            0x55,            0x47,            0x6A,            0x52,
//             0xD8,            0x73,            0x4A,            0x5A,            0xB0,            0x45,            0x5E,            0x79,          0x3800,            0xF4,
//           0x1500,          0x1B00,            0x71,            0xC1,            0xE4,            0x56,            0x7D,            0x81,            0x77,            0xCC,
//           0x5000,            0x82,            0x67,          0xFF00,            0x69,            0x98,            0xC3,          0x1900,            0x65,            0x7B,
//             0xEC,            0x59,            0xFA,            0x75,            0x6F,          0x3100,          0x3300,            0x4F,            0xB8,            0x6D,
//             0x4D,            0x51,            0xDC,            0xC4,          0x2100,            0xA8,            0xEE,            0xF6,            0xD4,            0xF2,
//             0xE2,            0x5F,            0xC6,            0xE6,            0xA4,            0xEA,            0x53,            0x6B,            0xC2,            0xB4,
//             0xDA,            0xDE,            0x84,            0xAC,            0x9C,            0x5D,            0xD2,            0xD6,            0xCE,            0x8C,
//             0xBC,            0xCA,            0x5B,            0x94,            0x57,            0x4B,            0x8E,            0xB6,            0xA2,            0xA6,
//             0xBA,            0xAA,            0xBE,            0xB2,            0xFD,            0xAE,            0xFB,            0x9A,            0x9E,            0xF1,
//             0x86,            0x8A,            0xF5,            0xF3,            0xF9,            0x96,            0xF7,          0x7F00,            0x92,          0x5F00,
//             0xE1,            0xEF,            0xE7,            0xE3,            0xE9,          0x2A00
//
//};
//	void Case_0 (MemoryStream^ StreamBlock3){
//						StreamBlock3->Seek(-4,SeekOrigin::Current);
//						array<unsigned char>^ buff = gcnew array<unsigned char>(4);
//						StreamBlock3->Read(buff,0,4);
//						StreamBlock3->Write(buff,0,4);
//						StreamBlock3->Write(buff,0,4);
//						StreamBlock3->Write(buff,0,4);
//						StreamBlock3->Write(buff,0,4);
//	}
//	void Case_0_copy(MemoryStream^ StreamBlock3){
//		G_CaseSwitch =  G_CaseSwitch & 7;  
//					while(G_BitOperation){
//								switch(G_CaseSwitch){
//									case 0:
//											Case_0 (StreamBlock3);
//										//break;
//									case 7:
//											Case_0 (StreamBlock3);
//										//break;
//									case 6:
//											Case_0 (StreamBlock3);
//										//break;
//									case 5:
//											Case_0 (StreamBlock3);
//										//break;
//									case 4:
//											Case_0 (StreamBlock3);
//										//break;
//									case 3:
//											Case_0 (StreamBlock3);
//										//break;
//									case 2:
//											Case_0 (StreamBlock3);
//										//break;
//									case 1:
//											Case_0 (StreamBlock3);
//										//break;
//
//									//default:
//										//break;
//								}//switch
//					
//					G_CaseSwitch = 0;
//					G_BitOperation--;// = G_BitOperation - 1;
//				}
//	}
//
//	void Case_1(MemoryStream^ StreamBlock3){
//						StreamBlock3->Seek(-6,SeekOrigin::Current);
//						unsigned char a1 = StreamBlock3->ReadByte();
//						unsigned char a2 = StreamBlock3->ReadByte();
//						unsigned char a3 = StreamBlock3->ReadByte();
//						unsigned char a4 = StreamBlock3->ReadByte();
//						unsigned char a5 = StreamBlock3->ReadByte();
//						unsigned char a6 = StreamBlock3->ReadByte();
//						
//						StreamBlock3->WriteByte(a1);
//						StreamBlock3->WriteByte(a2);
//						StreamBlock3->WriteByte(a3);
//						StreamBlock3->WriteByte(a4);
//						StreamBlock3->WriteByte(a5);
//						StreamBlock3->WriteByte(a6);
//						StreamBlock3->WriteByte(a1);
//						StreamBlock3->WriteByte(a2);
//						StreamBlock3->WriteByte(a3);
//						StreamBlock3->WriteByte(a4);
//						StreamBlock3->WriteByte(a5);
//						StreamBlock3->WriteByte(a6);
//						StreamBlock3->WriteByte(a1);
//						StreamBlock3->WriteByte(a2);
//						StreamBlock3->WriteByte(a3);
//						StreamBlock3->WriteByte(a4);
//
//	}
//	void Case_1_copy(MemoryStream^ StreamBlock3){
//		G_CaseSwitch =  G_CaseSwitch & 7;
//				while(G_BitOperation){
//								switch(G_CaseSwitch){
//									case 0:
//											Case_1 (StreamBlock3);
//										//break;
//									case 7:
//											Case_1 (StreamBlock3);
//										//break;
//									case 6:
//											Case_1 (StreamBlock3);
//										//break;
//									case 5:
//											Case_1 (StreamBlock3);
//										//break;
//									case 4:
//											Case_1 (StreamBlock3);
//										//break;
//									case 3:
//											Case_1 (StreamBlock3);
//										//break;
//									case 2:
//											Case_1 (StreamBlock3);
//										//break;
//									case 1:
//											Case_1 (StreamBlock3);
//										//break;
//
//									//default:
//										//break;
//								}//switch
//
//					G_CaseSwitch = 0;
//					G_BitOperation--;// = G_BitOperation - 1;
//				}
//	}
//
//	void Case_2(MemoryStream^ StreamBlock3){
//						StreamBlock3->Seek(-8,SeekOrigin::Current);
//						array<unsigned char>^ buff = gcnew array<unsigned char>(8);
//						StreamBlock3->Read(buff,0,8);
//						StreamBlock3->Write(buff,0,8);
//						StreamBlock3->Write(buff,0,8);
//
//	}
//	void Case_2_copy(MemoryStream^ StreamBlock3){																
//		G_CaseSwitch =  G_CaseSwitch & 7;
//				while(G_BitOperation){
//								switch(G_CaseSwitch){
//									case 0:
//											Case_2 (StreamBlock3);
//										//break;
//									case 7:
//											Case_2 (StreamBlock3);
//										//break;
//									case 6:
//											Case_2 (StreamBlock3);
//										//break;
//									case 5:
//											Case_2 (StreamBlock3);
//										//break;
//									case 4:
//											Case_2 (StreamBlock3);
//										//break;
//									case 3:
//											Case_2 (StreamBlock3);
//										//break;
//									case 2:
//											Case_2 (StreamBlock3);
//										//break;
//									case 1:
//											Case_2 (StreamBlock3);
//										//break;
//
//									//default:
//										//break;
//								}//switch
//
//					G_CaseSwitch = 0;
//					G_BitOperation--;// = G_BitOperation - 1;
//				}
//		}
//	void Case_3(MemoryStream^ StreamBlock3){
//						StreamBlock3->Seek(-0xA,SeekOrigin::Current);
//						unsigned char a1 = StreamBlock3->ReadByte();
//						unsigned char a2 = StreamBlock3->ReadByte();
//						unsigned char a3 = StreamBlock3->ReadByte();
//						unsigned char a4 = StreamBlock3->ReadByte();
//						unsigned char a5 = StreamBlock3->ReadByte();
//						unsigned char a6 = StreamBlock3->ReadByte();
//						unsigned char a7 = StreamBlock3->ReadByte();
//						unsigned char a8 = StreamBlock3->ReadByte();
//						unsigned char a9 = StreamBlock3->ReadByte();
//						unsigned char a10 = StreamBlock3->ReadByte();
//
//						StreamBlock3->WriteByte(a1);
//						StreamBlock3->WriteByte(a2);
//						StreamBlock3->WriteByte(a3);
//						StreamBlock3->WriteByte(a4);
//						StreamBlock3->WriteByte(a5);
//						StreamBlock3->WriteByte(a6);
//						StreamBlock3->WriteByte(a7);
//						StreamBlock3->WriteByte(a8);
//						StreamBlock3->WriteByte(a9);
//						StreamBlock3->WriteByte(a10);
//						StreamBlock3->WriteByte(a1);
//						StreamBlock3->WriteByte(a2);
//						StreamBlock3->WriteByte(a3);
//						StreamBlock3->WriteByte(a4);
//						StreamBlock3->WriteByte(a5);
//						StreamBlock3->WriteByte(a6);
//	}
//	void Case_3_copy(MemoryStream^ StreamBlock3){
//		G_CaseSwitch =  G_CaseSwitch & 7;
//				while(G_BitOperation){
//								switch(G_CaseSwitch){
//									case 0:
//											Case_3 (StreamBlock3);
//										//break;
//									case 7:
//											Case_3 (StreamBlock3);
//										//break;
//									case 6:
//											Case_3 (StreamBlock3);
//										//break;
//									case 5:
//											Case_3 (StreamBlock3);
//										//break;
//									case 4:
//											Case_3 (StreamBlock3);
//										//break;
//									case 3:
//											Case_3 (StreamBlock3);
//										//break;
//									case 2:
//											Case_3 (StreamBlock3);
//										//break;
//									case 1:
//											Case_3 (StreamBlock3);
//										//break;
//
//									//default:
//										//break;
//								}//switch
//
//					G_CaseSwitch = 0;
//					G_BitOperation--;// = G_BitOperation - 1;
//				}
//	}
//	void Case_4(MemoryStream^ StreamBlock3){
//						StreamBlock3->Seek(-0xC,SeekOrigin::Current);
//						array<unsigned char>^ buff1 = gcnew array<unsigned char>(4);
//						array<unsigned char>^ buff2 = gcnew array<unsigned char>(4);
//						array<unsigned char>^ buff3 = gcnew array<unsigned char>(4);
//						StreamBlock3->Read(buff1,0,4);
//						StreamBlock3->Read(buff2,0,4);
//						StreamBlock3->Read(buff3,0,4);
//						StreamBlock3->Write(buff1,0,4);
//						StreamBlock3->Write(buff2,0,4);
//						StreamBlock3->Write(buff3,0,4);
//						StreamBlock3->Write(buff1,0,4);
//
//	}
//	void Case_4_copy(MemoryStream^ StreamBlock3){
//		G_CaseSwitch =  G_CaseSwitch & 7;
//				while(G_BitOperation){
//								switch(G_CaseSwitch){
//									case 0:
//											Case_4 (StreamBlock3);
//										//break;
//									case 7:
//											Case_4 (StreamBlock3);
//										//break;
//									case 6:
//											Case_4 (StreamBlock3);
//										//break;
//									case 5:
//											Case_4 (StreamBlock3);
//										//break;
//									case 4:
//											Case_4 (StreamBlock3);
//										//break;
//									case 3:
//											Case_4 (StreamBlock3);
//										//break;
//									case 2:
//											Case_4 (StreamBlock3);
//										//break;
//									case 1:
//											Case_4 (StreamBlock3);
//										//break;
//
//									//default:
//										//break;
//								}//switch
//
//					G_CaseSwitch = 0;
//					G_BitOperation--;// = G_BitOperation - 1;
//				}
//	}
//
//	void Case_5 (MemoryStream^ StreamBlock3){
//						StreamBlock3->Seek(-0xE,SeekOrigin::Current);
//						array<unsigned char>^ buff1 = gcnew array<unsigned char>(2);
//						array<unsigned char>^ buff2 = gcnew array<unsigned char>(2);
//						array<unsigned char>^ buff3 = gcnew array<unsigned char>(2);
//						array<unsigned char>^ buff4 = gcnew array<unsigned char>(2);
//						array<unsigned char>^ buff5 = gcnew array<unsigned char>(2);
//						array<unsigned char>^ buff6 = gcnew array<unsigned char>(2);
//						array<unsigned char>^ buff7 = gcnew array<unsigned char>(2);
//																	
//						StreamBlock3->Read(buff1,0,2);
//						StreamBlock3->Read(buff2,0,2);
//						StreamBlock3->Read(buff3,0,2);
//						StreamBlock3->Read(buff4,0,2);
//						StreamBlock3->Read(buff5,0,2);
//						StreamBlock3->Read(buff6,0,2);
//						StreamBlock3->Read(buff7,0,2);
//						StreamBlock3->Write(buff1,0,2);
//						StreamBlock3->Write(buff2,0,2);
//						StreamBlock3->Write(buff3,0,2);
//						StreamBlock3->Write(buff4,0,2);
//						StreamBlock3->Write(buff5,0,2);
//						StreamBlock3->Write(buff6,0,2);
//						StreamBlock3->Write(buff7,0,2);
//						StreamBlock3->Write(buff1,0,2);
//	}
//	void Case_5_copy(MemoryStream^ StreamBlock3){
//		G_CaseSwitch =  G_CaseSwitch & 7;
//				while(G_BitOperation){
//								switch(G_CaseSwitch){
//									case 0:
//											Case_5 (StreamBlock3);
//										//break;
//									case 7:
//											Case_5 (StreamBlock3);
//										//break;
//									case 6:
//											Case_5 (StreamBlock3);
//										//break;
//									case 5:
//											Case_5 (StreamBlock3);
//										//break;
//									case 4:
//											Case_5 (StreamBlock3);
//										//break;
//									case 3:
//											Case_5 (StreamBlock3);
//										//break;
//									case 2:
//											Case_5 (StreamBlock3);
//										//break;
//									case 1:
//											Case_5 (StreamBlock3);
//										//break;
//
//									//default:
//										//break;
//								}//switch
//					G_CaseSwitch = 0;
//					G_BitOperation--;// = G_BitOperation - 1;
//				}
//	}
//
//	void Case_default(MemoryStream^ StreamBlock3){
//							int offset = G_R3 *2;
//							StreamBlock3->Seek(-offset,SeekOrigin::Current);
//							array<unsigned char>^ buff1 = gcnew array<unsigned char>(8);
//							StreamBlock3->Read(buff1, 0, 8);
//							StreamBlock3->Seek(0,SeekOrigin::End);
//							StreamBlock3->Write(buff1, 0, 8);
//																				
//							StreamBlock3->Seek(-offset,SeekOrigin::Current);
//							StreamBlock3->Read(buff1,0,8);
//							StreamBlock3->Seek(0,SeekOrigin::End);
//							StreamBlock3->Write(buff1,0,8);
//
//	}
//
//	void Case_default_copy(MemoryStream^ StreamBlock3){
//		G_CaseSwitch =  G_CaseSwitch & 7;
//					while(G_BitOperation){
//								switch(G_CaseSwitch){
//									case 0:
//											Case_default (StreamBlock3);
//										//break;
//									case 7:
//											Case_default (StreamBlock3);
//										//break;
//									case 6:
//											Case_default (StreamBlock3);
//										//break;
//									case 5:
//											Case_default (StreamBlock3);
//										//break;
//									case 4:
//											Case_default (StreamBlock3);
//										//break;
//									case 3:
//											Case_default (StreamBlock3);
//										//break;
//									case 2:
//											Case_default (StreamBlock3);
//										//break;
//									case 1:
//											Case_default (StreamBlock3);
//										break;
//
//									//default:
//										//break;
//								}//switch
//
//								G_CaseSwitch = 0;
//						G_BitOperation--;// = G_BitOperation - 1;
//					}
//	}
//
//
//
//
//
//	
//	void copy_2_bytes_from_offset_out_stream(MemoryStream^ StreamBlock3){
//							int offset = G_R3*2;
//							StreamBlock3->Seek(-offset, SeekOrigin::Current);
//							unsigned short a = StreamBlock3->ReadByte();
//							unsigned short b = StreamBlock3->ReadByte();
//							StreamBlock3->Seek(0, SeekOrigin::End);
//							StreamBlock3->WriteByte(a);
//							StreamBlock3->WriteByte(b);
//	}
//	void copy_2_bytes_from_compressed_stream(MemoryStream^ StreamBlock3, array<unsigned char>^ block_3){
//							StreamBlock3->WriteByte(block_3[G_Offset]);
//							StreamBlock3->WriteByte(block_3[G_Offset+1]);
//							G_Offset+=2;
//	}
//	void copy_2_bytes_with_xor(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3){
//					int offset = G_R3*2;
//					StreamBlock3->Seek( -offset, SeekOrigin::Current);
//					unsigned short a = StreamBlock3->ReadByte();
//					unsigned short b = StreamBlock3->ReadByte();
//					b = b << 8;
//					b = b | a;
//					b = b ^ difftable[StreamBlock2->ReadByte() ];
//					StreamBlock3->Seek(0, SeekOrigin::End);
//					a = b & 0xFF;
//					b = b >> 8;
//					StreamBlock3->WriteByte(a);
//					StreamBlock3->WriteByte(b);
//	}
//
//	
//	void Case_0_decompress1(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
//				G_CountBit-=2;// 
//				unsigned int Operation = 3 &  (G_BitsBuffer >> G_CountBit);//������� ��� ����
//				if(Operation == 0){
//					copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//					copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//				}else if(Operation == 1){
//						copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//					}else if(Operation == 2){
//							copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						}else if(Operation == 3){
//								copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//								copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//					}
//
//					if((G_BitOperation & /*4*/ext) != 0){
//					G_CountBit--;// 
//						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
//							G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
//							G_Offset+=2;
//						}else{//���� ����� ��� == 1
//							G_R3 = StreamBlock2->ReadByte();
//						}
//					}
//
//				G_CountBit-=2;// 
//				Operation = 3 &  (G_BitsBuffer >> G_CountBit);//������� ��� ����
//				if(Operation == 0){
//						copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//				}else if(Operation == 1){
//						copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//					}else if(Operation == 2){
//							copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						}else if(Operation == 3){
//								copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//								copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//						}
//	}
//	void Case_1_decompress1(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
//			G_CountBit-=2;// 
//			unsigned int Operation = 3 &  (G_BitsBuffer >> G_CountBit);//������� ��� ����
//			if(Operation == 0){
//					copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//					copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//			}else if(Operation == 1){
//						copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//				}else if(Operation == 2){
//							copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//					}else if(Operation == 3){
//								copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//								copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//					}
//
//					if((G_BitOperation & /*4*/ext) != 0){
//					G_CountBit--;// 
//						if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
//							G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
//							G_Offset+=2;
//						}else{//���� ����� ��� == 1
//							G_R3 = StreamBlock2->ReadByte();
//						}
//					}
//
//					G_CountBit--;// 
//						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						}else{
//							copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//						}
//						copy_2_bytes_from_offset_out_stream(StreamBlock3);
//	}	
//	void Case_2_decompress1(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
//			G_CountBit-=2;// 
//			unsigned int Operation = 3 &  (G_BitsBuffer >> G_CountBit);//������� ��� ����
//			if(Operation == 0){
//					copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//					copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//			}else if(Operation == 1){
//						copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//				}else if(Operation == 2){
//							copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//					}else if(Operation == 3){
//								copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//								copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//					}
//
//					if((G_BitOperation & /*4*/ext) != 0){
//					G_CountBit--;//=1;// 
//						if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
//							G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
//							G_Offset+=2;
//						}else{//���� ����� ��� == 1
//							G_R3 = StreamBlock2->ReadByte();
//						}
//					}
//					copy_2_bytes_from_offset_out_stream(StreamBlock3);
//					G_CountBit--;// 
//						if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						}else{
//							copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//						}
//	}	
//	void Case_3_decompress1(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
//			G_CountBit-=2;// 
//			unsigned int Operation = 3 &  (G_BitsBuffer >> G_CountBit);//������� ��� ����
//			if(Operation == 0){
//					copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//					copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//			}else if(Operation == 1){
//						copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//				}else if(Operation == 2){
//							copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//					}else if(Operation == 3){
//								copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//								copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//					}
//
//					if((G_BitOperation & /*4*/ext) != 0){
//					G_CountBit--;//=1;// 
//						if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
//							G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
//							G_Offset+=2;
//						}else{//���� ����� ��� == 1
//							G_R3 = StreamBlock2->ReadByte();
//						}
//					}
//					copy_2_bytes_from_offset_out_stream(StreamBlock3);
//					copy_2_bytes_from_offset_out_stream(StreamBlock3);
//	}	
//	void Case_4_decompress1(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
//					G_CountBit--;//
//						if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						}else{
//							copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//						}
//					copy_2_bytes_from_offset_out_stream(StreamBlock3);
//
//					if((G_BitOperation & /*4*/ext) != 0){
//						G_CountBit--;// 
//							if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){//
//								G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
//								G_Offset+=2;
//							}else{//
//								G_R3 = StreamBlock2->ReadByte();
//							}
//					}
//					G_CountBit-=2;// 
//						unsigned int Operation = 3 &  (G_BitsBuffer >> G_CountBit);//
//						if(Operation == 0){
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						}else if(Operation == 1){
//								copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//								copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//							}else if(Operation == 2){
//									copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//									copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//								}else if(Operation == 3){
//										copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//										copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//								}
//	}	
//	void Case_5_decompress1(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
//					G_CountBit--;//
//						if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						}else{
//							copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//						}
//					copy_2_bytes_from_offset_out_stream(StreamBlock3);
//
//					if((G_BitOperation & /*4*/ext) != 0){
//						G_CountBit--;// 
//							if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){//
//								G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
//								G_Offset+=2;
//							}else{//
//								G_R3 = StreamBlock2->ReadByte();
//							}
//					}
//						G_CountBit--;// 
//							if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){//
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						}else{
//							copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//							}
//						copy_2_bytes_from_offset_out_stream(StreamBlock3);
//						
//	}	
//	void Case_6_decompress1(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
//					G_CountBit--;//
//						if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						}else{
//							copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//						}
//					copy_2_bytes_from_offset_out_stream(StreamBlock3);
//
//					if((G_BitOperation & /*4*/ext) != 0){
//						G_CountBit--;// 
//							if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){//
//								G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
//								G_Offset+=2;
//							}else{//
//								G_R3 = StreamBlock2->ReadByte();
//							}
//					}
//						copy_2_bytes_from_offset_out_stream(StreamBlock3);
//						G_CountBit--;// 
//							if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){//
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						}else{
//							copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//							}
//						
//	}	
//	void Case_7_decompress1(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
//					G_CountBit--;//
//						if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						}else{
//							copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//						}
//						copy_2_bytes_from_offset_out_stream(StreamBlock3);
//
//					if((G_BitOperation & /*4*/ext) != 0){
//						G_CountBit--;// 
//							if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){//
//								G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
//								G_Offset+=2;
//							}else{//
//								G_R3 = StreamBlock2->ReadByte();
//							}
//					}
//						copy_2_bytes_from_offset_out_stream(StreamBlock3);
//						copy_2_bytes_from_offset_out_stream(StreamBlock3);
//	}	
//	void Case_8_decompress1(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
//					
//					copy_2_bytes_from_offset_out_stream(StreamBlock3);
//					G_CountBit--;//
//						if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						}else{
//							copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//						}
//					if((G_BitOperation & /*4*/ext) != 0){
//						G_CountBit--;// 
//							if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){//
//								G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
//								G_Offset+=2;
//							}else{//
//								G_R3 = StreamBlock2->ReadByte();
//							}
//					}
//						G_CountBit-=2;// 
//						unsigned int Operation = 3 &  (G_BitsBuffer >> G_CountBit);//
//						if(Operation == 0){
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						}else if(Operation == 1){
//								copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//								copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//							}else if(Operation == 2){
//									copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//									copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//								}else if(Operation == 3){
//										copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//										copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//								}
//	}	
//	void Case_9_decompress1(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
//					
//					copy_2_bytes_from_offset_out_stream(StreamBlock3);
//					G_CountBit--;//
//						if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						}else{
//							copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//						}
//					if((G_BitOperation & /*4*/ext) != 0){
//						G_CountBit--;// 
//							if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){//
//								G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
//								G_Offset+=2;
//							}else{//
//								G_R3 = StreamBlock2->ReadByte();
//							}
//					}
//						G_CountBit--;// 
//							if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){//
//								copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//							}else{
//								copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//							}
//							copy_2_bytes_from_offset_out_stream(StreamBlock3);
//	}	
//	void Case_10_decompress1(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
//					
//					copy_2_bytes_from_offset_out_stream(StreamBlock3);
//					G_CountBit--;//
//						if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						}else{
//							copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//						}
//					if((G_BitOperation & /*4*/ext) != 0){
//						G_CountBit--;// 
//							if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){//
//								G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
//								G_Offset+=2;
//							}else{//
//								G_R3 = StreamBlock2->ReadByte();
//							}
//					}
//						copy_2_bytes_from_offset_out_stream(StreamBlock3);
//						G_CountBit--;// 
//							if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){//
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						}else{
//							copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//							}
//	}	
//	void Case_11_decompress1(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
//					
//					copy_2_bytes_from_offset_out_stream(StreamBlock3);
//					G_CountBit--;//
//						if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						}else{
//							copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//						}
//					if((G_BitOperation & /*4*/ext) != 0){
//						G_CountBit--;// 
//							if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){//
//								G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
//								G_Offset+=2;
//							}else{//
//								G_R3 = StreamBlock2->ReadByte();
//							}
//					}
//						copy_2_bytes_from_offset_out_stream(StreamBlock3);
//						copy_2_bytes_from_offset_out_stream(StreamBlock3);
//	}	
//	void Case_12_decompress1(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
//					
//					copy_2_bytes_from_offset_out_stream(StreamBlock3);
//					copy_2_bytes_from_offset_out_stream(StreamBlock3);
//					if((G_BitOperation & /*4*/ext) != 0){
//						G_CountBit--;// 
//							if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){//
//								G_R3 = block_3[G_Offset] |(block_3[G_Offset + 1] << 8);
//								G_Offset+=2;
//							}else{//
//								G_R3 = StreamBlock2->ReadByte();
//							}
//					}
//						G_CountBit-=2;// 
//						unsigned int Operation = 3 &  (G_BitsBuffer >> G_CountBit);//
//						if(Operation == 0){
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						}else if(Operation == 1){
//								copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//								copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//							}else if(Operation == 2){
//									copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//									copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//								}else if(Operation == 3){
//										copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//										copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//								}
//	}		
//	void Case_13_decompress1(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
//					
//					copy_2_bytes_from_offset_out_stream(StreamBlock3);
//					copy_2_bytes_from_offset_out_stream(StreamBlock3);
//					if((G_BitOperation & ext) != 0){
//						G_CountBit--;// 
//							if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){//
//								G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
//								G_Offset+=2;
//							}else{//
//								G_R3 = StreamBlock2->ReadByte();
//							}
//					}
//						G_CountBit--;// 
//							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						}else{
//							copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//							}
//						copy_2_bytes_from_offset_out_stream(StreamBlock3);
//	}	
//	void Case_14_decompress1(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
//					
//					copy_2_bytes_from_offset_out_stream(StreamBlock3);
//					copy_2_bytes_from_offset_out_stream(StreamBlock3);
//					if((G_BitOperation & /*4*/ext) != 0){
//						G_CountBit--;// 
//							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
//								G_R3 = block_3[G_Offset] |(block_3[G_Offset + 1] << 8);
//								G_Offset+=2;
//							}else{//
//								G_R3 = StreamBlock2->ReadByte();
//							}
//					}
//						copy_2_bytes_from_offset_out_stream(StreamBlock3);
//						G_CountBit--;// 
//							if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
//							copy_2_bytes_with_xor(StreamBlock2, StreamBlock3);
//						}else{
//							copy_2_bytes_from_compressed_stream(StreamBlock3, block_3);
//							}
//	}	
//	void Case_15_decompress1(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock3, array<unsigned char>^ block_3, int ext){	
//					
//					copy_2_bytes_from_offset_out_stream(StreamBlock3);
//					copy_2_bytes_from_offset_out_stream(StreamBlock3);
//					if((G_BitOperation & /*4*/ext) != 0){
//						G_CountBit--;// 
//							if((/*Operation*/(G_BitsBuffer >> G_CountBit) & 1) == 0){//
//								G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
//								G_Offset+=2;
//							}else{//
//								G_R3 = StreamBlock2->ReadByte();
//							}
//					}
//						copy_2_bytes_from_offset_out_stream(StreamBlock3);
//						copy_2_bytes_from_offset_out_stream(StreamBlock3);
//	}	
//
//
//
//
//	
//	
//	array<unsigned char>^ DecompressAppBada2( array<unsigned char>^ decrypt, BackgroundWorker^ bwAsync){
//			
//	
//				MemoryStream^ stream = gcnew MemoryStream(decrypt);
//				BinaryReader^ br = gcnew BinaryReader( stream );
//
//				int first = br->ReadInt32();
//				int len_1 = br->ReadInt32();
//				int len_2 = br->ReadInt32();
//
//				array<unsigned char>^ block_1 = gcnew array<unsigned char>(len_1 + 0x10);
//				array<unsigned char>^ block_2 = gcnew array<unsigned char>(len_2 + 0x10);
//				array<unsigned char>^ block_3 = gcnew array<unsigned char>((br->BaseStream->Length -(len_1 + len_2 + 0xC)) + 0x100);
//
//				br->Read(block_1, 0, len_1);
//				MemoryStream^ StreamBlock1 = gcnew MemoryStream( block_1->Length );// ����� ������� �����
//				StreamBlock1->Write(block_1, 0, block_1->Length);
//				StreamBlock1->Seek(0, SeekOrigin::Begin);
//
//				br->Read(block_2, 0, len_2);
//				MemoryStream^ StreamBlock2 = gcnew MemoryStream( block_2->Length );// ����� ������� �����
//				StreamBlock2->Write(block_2, 0, block_2->Length);
//				StreamBlock2->Seek(0, SeekOrigin::Begin);
//
//				br->Read(block_3, 0, block_3->Length);
//				MemoryStream^ StreamBlock3 = gcnew MemoryStream( first >> 4 << 2  /*0x4000*/ ); ///������ ����� ��������. ��� �������� �����
//				StreamBlock3->Seek(0, SeekOrigin::Begin);
//					
//				br->Close();
////////////
//				G_CountBit = 0;
//				G_BitOperation = 0;
//				G_Offset = 0;
//				G_CountDword = (first >> 4 << 2);
//				G_CaseSwitch = 0;
//				G_R3 = 2;
//				G_BitsBuffer = 0;
////int n = 0;
//				/////���������� �� 3 ����� 16 ���� � �����
//				StreamBlock3->Write(block_3, G_Offset, 0x10);
//				G_Offset += 0x10;
//				G_CountDword-=4;//
//				
/////////////////////////
//				while(G_CountDword != 0){
//				if(G_CountBit <= 0x10){
//				unsigned short a = StreamBlock1->ReadByte();// ������� 1 ���� Count < 0x10
//				unsigned short b = StreamBlock1->ReadByte();
//				G_BitsBuffer = a | (G_BitsBuffer << 8);
//				G_BitsBuffer = b | (G_BitsBuffer << 8);
//				G_CountBit += 0x10;
//				}
//
//
//				G_CountBit--;//������� ���� Count > 0x10
//				if((G_BitsBuffer >> G_CountBit & 1) == 0){//���� ��� == 0 �� ������ ������ ���
//					//loc_620FC
//					G_CountBit--;// 
//					if((G_BitsBuffer >> G_CountBit & 1) == 0){//���� ������ ��� == 00
//						//loc_621B0
//							G_CountBit --;//
//							if((G_BitsBuffer >> G_CountBit & 1) == 0){//���� ������ ��� == 0/////////
//								//loc_63274	
//								G_CountBit--;//
//								if((G_BitsBuffer >> G_CountBit & 1) == 0){ //���� ������ ���� == 0 (0000)//////////
//									//loc_6329C
//										G_CountBit-= 4;
//										G_CaseSwitch = (G_BitsBuffer >> G_CountBit) & 0xF;//����� ������ ���� �� ������ ����� - ���������� ���������� ����� (������ == 4 �����)
//										G_CountDword = G_CountDword - (G_CaseSwitch << 2);//-(CaseSwitch * 4);
//										G_BitOperation = (G_CaseSwitch + 7) >> 3;//ASR#3;
//									}else{//���� ������ ���� = (0001)
//										G_CaseSwitch = StreamBlock2->ReadByte();//����� ���� �� ������� ������ - ���������� ���������� ����� (������ == 4 �����)
//										G_CountDword = G_CountDword - (G_CaseSwitch << 2);////+ ((0 - CaseSwitch) << 2);
//										G_BitOperation = (G_CaseSwitch + 7) >> 3;//5,6.7 � �.�. ���� ���������� ���-�� ����������� ������ �� 8 �����, ��������� ��� ���� �� ����������� ���������� ������ ������������� �� ���� ������� �����
//									}
//								G_CaseSwitch =  G_CaseSwitch & 7;//��� ������� ����
//								while(G_BitOperation){
//	
//									switch(G_CaseSwitch){
//									case 0:
//											StreamBlock3->Write(block_3, G_Offset, 0x10);
//											G_Offset += 0x10;
//										//break;
//									case 7:
//											StreamBlock3->Write(block_3, G_Offset, 0x10);
//											G_Offset += 0x10;
//										//break;
//									case 6:
//											StreamBlock3->Write(block_3, G_Offset, 0x10);
//											G_Offset += 0x10;
//										//break;
//									case 5:
//											StreamBlock3->Write(block_3, G_Offset, 0x10);
//											G_Offset += 0x10;
//											//break;
//									case 4:
//											StreamBlock3->Write(block_3, G_Offset, 0x10);
//											G_Offset += 0x10;
//										//break;
//									case 3:
//											StreamBlock3->Write(block_3, G_Offset, 0x10);
//											G_Offset += 0x10;
//										//break;
//									case 2:
//											StreamBlock3->Write(block_3, G_Offset, 0x10);
//											G_Offset += 0x10;
//										//break;
//									case 1:
//											StreamBlock3->Write(block_3, G_Offset, 0x10);
//											G_Offset += 0x10;
//										break;
//									default:
//											//goto label1;
//										break;
//								}//switch
//
//											G_CaseSwitch = 0;
//											G_BitOperation--;// = G_BitOperation - 1;
//										}
//								//goto label1;
//
//							}else{//���� ������ ���� == (001~) �.�. ������ ���  == 1
//								
//								G_CountBit--;//
//								if((G_BitsBuffer >> G_CountBit & 1) == 0){//���� ������ ���� == (0010)
//										G_CountBit-= 4;
//										G_CaseSwitch = (G_BitsBuffer >> G_CountBit) & 0xF;
//										G_CountDword = G_CountDword - (G_CaseSwitch << 2);//+ ((0 - CaseSwitch) << 2);
//										G_BitOperation = (G_CaseSwitch + 7) >> 3;//ASR#3;
//								}else{//���� ������ ���� == (0011)
//										G_CaseSwitch = StreamBlock2->ReadByte();
//										G_CountDword = G_CountDword - (G_CaseSwitch << 2);//+ ((0 - CaseSwitch) << 2);
//										G_BitOperation = (G_CaseSwitch + 7) >> 3;
//								}
//								switch(G_R3 - 2){
//									case 0:
//										Case_0_copy(StreamBlock3);
//										break;
//									case 1:
//										Case_1_copy(StreamBlock3);
//										break;
//									case 2:
//										Case_2_copy(StreamBlock3);
//										break;
//									case 3:
//										Case_3_copy(StreamBlock3);
//										break;
//									case 4:
//										Case_4_copy(StreamBlock3);
//										break;
//									case 5:
//										Case_5_copy(StreamBlock3);
//										break;
//									default:
//										Case_default_copy(StreamBlock3);
//										break;
//								}//switch
//								
//							}
//
//					}else{//���� ������ ��� ����� 1 (01)
//						StreamBlock3->Write(block_3, G_Offset, 0x10);
//						G_Offset += 0x10;
//						G_CountDword-=4;
//
//						}
//
//				}else{//���� ��� ��������� �� ������� ������ ����� 1
//					
//					G_CaseSwitch = StreamBlock2->ReadByte();// >> 4;//������� 4 ������� ���� �� ����� ���������� �� ������� ������
//							G_CountBit-=4;//
//									G_BitOperation = ((G_BitsBuffer >> G_CountBit) & 0xF);// ������� 4 ���� �� ������ �����
//											if((G_BitOperation & 8) != 0)	{//���� ������� �� ������� ��� == 1 (1~~~)			
//													G_CountBit--;
//														if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//���� ����� ��� == 0
//															G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
//															G_Offset+=2;
//														}else{//���� ����� ��� == 1
//															G_R3 = StreamBlock2->ReadByte();
//														}
//												}
// 												switch(G_CaseSwitch >> 4){
//
//													case 0:
//														Case_0_decompress1(StreamBlock2, StreamBlock3, block_3, 4);
//														break;
//													case 1:
//														Case_1_decompress1(StreamBlock2, StreamBlock3, block_3, 4);
//														break;
//													case 2:
//														Case_2_decompress1(StreamBlock2, StreamBlock3, block_3, 4);
//														break;
//													case 3:
//														Case_3_decompress1(StreamBlock2, StreamBlock3, block_3, 4);
//														break;
//													case 4:
//														Case_4_decompress1(StreamBlock2, StreamBlock3, block_3, 4);
//														break;
//													case 5:
//														Case_5_decompress1(StreamBlock2, StreamBlock3, block_3, 4);
//														break;
//													case 6:
//														Case_6_decompress1(StreamBlock2, StreamBlock3, block_3, 4);
//														break;
//													case 7:
//														Case_7_decompress1(StreamBlock2, StreamBlock3, block_3, 4);
//														break;
//													case 8:
//														Case_8_decompress1(StreamBlock2, StreamBlock3, block_3, 4);
//														break;
//													case 9:
//														Case_9_decompress1(StreamBlock2, StreamBlock3, block_3, 4);
//														break;
//													case 10:
//														Case_10_decompress1(StreamBlock2, StreamBlock3, block_3, 4);
//														break;
//													case 11:
//														Case_11_decompress1(StreamBlock2, StreamBlock3, block_3, 4);
//														break;
//													case 12:
//														Case_12_decompress1(StreamBlock2, StreamBlock3, block_3, 4);
//														break;
//													case 13:
//														Case_13_decompress1(StreamBlock2, StreamBlock3, block_3, 4);
//														break;
//													case 14:
//														Case_14_decompress1(StreamBlock2, StreamBlock3, block_3, 4);
//													break;
//													case 15:
//														Case_15_decompress1(StreamBlock2, StreamBlock3, block_3, 4);
//													break;
//													default:
//														break;
//												}//Switch
//
//							if(G_CountBit <= 0x10){
//							unsigned short a = StreamBlock1->ReadByte();// ������� 1 ���� Count < 0x10
//							unsigned short b = StreamBlock1->ReadByte();
//							G_BitsBuffer = a | (G_BitsBuffer << 8);
//							G_BitsBuffer = b | (G_BitsBuffer << 8);
//							G_CountBit += 0x10;
//							}							
//
//							if((G_BitOperation & 2) != 0){
//								G_CountBit--;// 
//									if(((G_BitsBuffer >> G_CountBit) & 1) == 0){//
//										G_R3 = block_3[G_Offset] | (block_3[G_Offset + 1] << 8);
//										G_Offset+=2;
//									}else{//
//										G_R3 = StreamBlock2->ReadByte();
//									}
//							}
//
//												switch(G_CaseSwitch & 0xF){
//
//													case 0:
//														Case_0_decompress1(StreamBlock2, StreamBlock3, block_3, 1);
//														break;
//													case 1:
//														Case_1_decompress1(StreamBlock2, StreamBlock3, block_3, 1);
//														break;
//													case 2:
//														Case_2_decompress1(StreamBlock2, StreamBlock3, block_3, 1);
//														break;
//													case 3:
//														Case_3_decompress1(StreamBlock2, StreamBlock3, block_3, 1);
//														break;
//													case 4:
//														Case_4_decompress1(StreamBlock2, StreamBlock3, block_3, 1);
//														break;
//													case 5:
//														Case_5_decompress1(StreamBlock2, StreamBlock3, block_3, 1);
//														break;
//													case 6:
//														Case_6_decompress1(StreamBlock2, StreamBlock3, block_3, 1);
//														break;
//													case 7:
//														Case_7_decompress1(StreamBlock2, StreamBlock3, block_3, 1);
//														break;
//													case 8:
//														Case_8_decompress1(StreamBlock2, StreamBlock3, block_3, 1);
//														break;
//													case 9:
//														Case_9_decompress1(StreamBlock2, StreamBlock3, block_3, 1);
//														break;
//													case 10:
//														Case_10_decompress1(StreamBlock2, StreamBlock3, block_3, 1);
//														break;
//													case 11:
//														Case_11_decompress1(StreamBlock2, StreamBlock3, block_3, 1);
//														break;
//													case 12:
//														Case_12_decompress1(StreamBlock2, StreamBlock3, block_3, 1);
//														break;
//													case 13:
//														Case_13_decompress1(StreamBlock2, StreamBlock3, block_3, 1);
//														break;
//													case 14:
//														Case_14_decompress1(StreamBlock2, StreamBlock3, block_3, 1);
//														break;
//													case 15:
//														Case_15_decompress1(StreamBlock2, StreamBlock3, block_3, 1);
//														break;
//													default:
//														break;
//												}//Switch
//									G_CountDword-=4;
//							}
//							//G_CountDword-=4;
//			}//while
//							array<unsigned char>^ decompress = gcnew array<unsigned char>(StreamBlock3->Length);
//							StreamBlock3->Seek(0, SeekOrigin::Begin);
//							StreamBlock3->Read(decompress, 0, decompress->Length);
//
//							return decompress;
//
//}
//
//
//				array<unsigned char>^ ParserAppBada2(array<unsigned char>^ decompress, BackgroundWorker^ bwAsync){
//				
//				int  type;
//				MemoryStream^ myStreamParser = gcnew MemoryStream(decompress);
//				BinaryReader^ br = gcnew BinaryReader(myStreamParser);
//				
//				br->BaseStream->Seek(0x40000, SeekOrigin::Begin);
//				if( br->ReadInt32() == 0x444D51){
//					br->BaseStream->Seek(0x40100, SeekOrigin::Begin);
//				}else{ 
//					br->BaseStream->Seek(0x80000, SeekOrigin::Begin);
//					if( br->ReadInt32() == 0x444D51){
//						br->BaseStream->Seek(0x80100, SeekOrigin::Begin);
//						}
//				}
//				MemoryStream^ Stream = gcnew MemoryStream();
//				BinaryWriter^ bw = gcnew BinaryWriter(Stream);
//				
//
//				while((type = br->ReadInt32()) != 0){
//				int len = br->ReadInt32();
//				int offset = br->ReadUInt32();
//				int position2 = br->BaseStream->Position;
//				
//				array<unsigned char>^ CompressedBlock = gcnew array<unsigned char>(len);
//				
//				switch(type){
//
//				case 0xF:
//				case 0xA:
//				case 0x3:
//						br->BaseStream->Seek(offset, SeekOrigin::Begin);
//						br->BaseStream->Read(CompressedBlock, 0, len);
//						bw->BaseStream->Write(CompressedBlock, 0, len);
//					break;
//				
//				case 0x1:
//						br->BaseStream->Seek(offset, SeekOrigin::Begin);
//						br->BaseStream->Read(CompressedBlock, 0, len);
//						bw->BaseStream->Write((DecompressAppBada2(CompressedBlock, bwAsync)), 0, 0x40000);
//						bwAsync->ReportProgress(Convert::ToInt32( br->BaseStream->Position *  100 / br->BaseStream->Length));
//					break;
//
//				case 0x8:
//						int position = br->BaseStream->Position;
//						br->BaseStream->Seek(offset, SeekOrigin::Begin);
//						unsigned int LenBlock = 0;
//						int m = 0;
//						
//						for(int i = 0; i < 0x40; i++){
//							LenBlock = br->ReadInt16();
//							int position1 = br->BaseStream->Position;
//
//							br->BaseStream->Seek(offset + 0x80 + m, SeekOrigin::Begin);
//							br->BaseStream->Read(CompressedBlock, 0, LenBlock);
//						if(LenBlock == 0x1000){
//						
//							bw->BaseStream->Write(CompressedBlock, 0, LenBlock);	
//						}else{
//						
//							bw->BaseStream->Write((DecompressAppBada2(CompressedBlock, bwAsync)), 0, 0x1000);
//							bwAsync->ReportProgress(Convert::ToInt32( br->BaseStream->Position *  100 / br->BaseStream->Length));
//						}
//							m += LenBlock;
//							br->BaseStream->Seek(position1, SeekOrigin::Begin);
//
//						}
//						br->BaseStream->Seek(position, SeekOrigin::Begin);
//
//						break;
//					}//case
//						
//				br->BaseStream->Seek(position2, SeekOrigin::Begin);
//
//			}//while
//
//					array<unsigned char>^ decrypt_decompress = gcnew array<unsigned char>(bw->BaseStream->Length);
//					bw->BaseStream->Seek(0,SeekOrigin::Begin);
//					bw->BaseStream->Read(decrypt_decompress, 0, decrypt_decompress->Length);
//
//					bw->Close();
//					br->Close();
//
//					return decrypt_decompress;
//	}
//
//
//				array<unsigned char>^ DecryptCompressedBin2( array<unsigned char>^ buffer, BackgroundWorker^ bwAsync){
//					//return ParserAppBada2(Decrypt( buffer, bwAsync), bwAsync);
//					return Decompress(Decrypt( buffer, bwAsync), bwAsync);
//				}
//



}