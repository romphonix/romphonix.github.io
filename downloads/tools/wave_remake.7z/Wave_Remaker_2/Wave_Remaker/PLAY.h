#pragma once

#include <memory.h>
#include <stdlib.h>

using namespace System::Threading;
using namespace System::IO;
using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
//using namespace ImageUtils;
using namespace System::Runtime::InteropServices;


#define BYTE(data,pos)                  (*(unsigned char *)((data)+(pos)))
#define HALF(data,pos)                  (*(unsigned short *)((data)+(pos)))
#define WORD(data,pos)                  (*(unsigned int *)((data)+(pos)))

#define GET_BYTE( data, pos )           ( ( (unsigned char *)( data ) )[pos] )
#define GET_HALF( data, pos )           ( ( GET_BYTE ( data, ( ( pos ) + 1 ) ) << 8 ) | GET_BYTE ( data, ( pos ) ) )
#define GET_WORD( data, pos )           ( ( GET_HALF ( data, ( ( pos ) + 2 ) ) << 16 ) | GET_HALF ( data, ( pos ) ) )
#define SET_BYTE( data, pos, val )      do { ( (unsigned char *)( data ) )[pos] = val; } while ( 0 )
#define SET_HALF( data, pos, val )      do { SET_BYTE ( data, ( pos ) + 1, ( ( val ) >> 8 ) & 0xFF ); SET_BYTE ( data, ( pos ), ( val ) & 0xFF ); } while ( 0 )
#define SET_WORD( data, pos, val )      do { SET_HALF ( data, ( pos ) + 2, ( ( val ) >> 16 ) & 0xFFFF ); SET_HALF ( data, ( pos ), ( val ) & 0xFFFF ); } while ( 0 )



namespace Wave_Remaker {

	/// <summary>
	/// ������ ��� PLAY
	///
	/// ��������! ��� ��������� ����� ����� ������ ���������� ����� ��������
	///          �������� ����� ����� �������� ("Resource File Name") ��� �������� ���������� ������������ �������,
	///          ���������� �� ����� ������� � ����������� .resx, �� ������� ������� ������ �����. � ��������� ������,
	///          ������������ �� ������ ��������� �������� � ���������������
	///          ���������, ��������������� ������ �����.
	/// </summary>
	public ref class PLAY : public System::Windows::Forms::Form
	{
	public:
		PLAY(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~PLAY()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::MenuStrip^  menuStrip1;
	protected: 


	private: System::Windows::Forms::PictureBox^  pictureBox1;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Button^  button2;
	private: System::Windows::Forms::Button^  button3;
	private: System::ComponentModel::BackgroundWorker^  backgroundWorker1;

	protected: 

	protected: 

	private:
		/// <summary>
		/// ��������� ���������� ������������.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ������������ ����� ��� ��������� ������������ - �� ���������
		/// ���������� ������� ������ ��� ������ ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->backgroundWorker1 = (gcnew System::ComponentModel::BackgroundWorker());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// menuStrip1
			// 
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(232, 24);
			this->menuStrip1->TabIndex = 0;
			this->menuStrip1->Text = L"menuStrip1";
			// 
			// pictureBox1
			// 
			this->pictureBox1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->pictureBox1->Location = System::Drawing::Point(0, 24);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(232, 372);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox1->TabIndex = 1;
			this->pictureBox1->TabStop = false;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(79, 0);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 2;
			this->button1->Text = L"Play";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &PLAY::button1_Click);
			// 
			// button2
			// 
			this->button2->DialogResult = System::Windows::Forms::DialogResult::Cancel;
			this->button2->Location = System::Drawing::Point(158, 0);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 23);
			this->button2->TabIndex = 3;
			this->button2->Text = L"Cancel";
			this->button2->UseVisualStyleBackColor = true;
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(0, 0);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(75, 23);
			this->button3->TabIndex = 4;
			this->button3->Text = L"Open";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &PLAY::button3_Click);
			// 
			// backgroundWorker1
			// 
			this->backgroundWorker1->WorkerSupportsCancellation = true;
			this->backgroundWorker1->DoWork += gcnew System::ComponentModel::DoWorkEventHandler(this, &PLAY::backgroundWorker1_DoWork);
			// 
			// PLAY
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->CancelButton = this->button2;
			this->ClientSize = System::Drawing::Size(232, 396);
			this->ControlBox = false;
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->pictureBox1);
			this->Controls->Add(this->menuStrip1);
			this->MainMenuStrip = this->menuStrip1;
			this->Name = L"PLAY";
			this->ShowIcon = false;
			this->ShowInTaskbar = false;
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"PLAY";
			this->Load += gcnew System::EventHandler(this, &PLAY::PLAY_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	String^ AppPath;

	unsigned int IMG_decompress(unsigned char* src, unsigned char* pWrite){


				unsigned int count_in1=0, count_in2=0, count_write=0;
				unsigned char *src1, *src2, *pRead;
				unsigned int data=0, count=0;

				unsigned int offset = (GET_HALF(src, 0)<<0x8 | GET_HALF(src, 0)>>0x8) & 0xFFFF;
				src2 = src + 2 + offset;
				src1 = src+2;
				
				if(offset & 1 != 0){ //���� ���������� ������� ���, �.�. ����� �������� �����
					
					offset = (offset & 0xFFFE) | ( GET_BYTE(src, 2) << 15 ) | ( GET_BYTE(src, 3) << 23);
					src2 = src + 4 + offset;
					src1 = src + 4;
				}

				do{
					data = GET_HALF(src2, (count_in2<<1));
					SET_HALF( pWrite, (count_write<<1), data );
					count_write++; count_in2++;

				}while((data & 0x20) == 0);

				SET_HALF( pWrite, (count_write - 1)<<1, (data&~0x20) );
				
				if(offset > 0){ // ���� ������� ��� �� ����������
					
					do{

					unsigned short  a = BYTE(src1, count_in1);
					unsigned short  b = BYTE(src1, (count_in1+1));

					pRead = pWrite + ((count_write - ((a & 7)<<8 | b))<<1);
					
					count = 0;

					do{
					SET_HALF( pWrite, (count_write)<<1,	GET_HALF(pRead, count<<1));
					SET_HALF( pWrite, (count_write+1)<<1, GET_HALF(pRead, (count+1)<<1));
					count_write+=2; count+=2;
					}while(count < (a>>4)-2);

					while(count < (a>>4)){
						SET_HALF( pWrite, count_write<<1,	GET_HALF(pRead, count<<1));
						count_write++; count++;
						
					}
					
					if((a & 8) != 0){ // ���� 4� ��� �� ����������
						
						do{
							data = GET_HALF(src2, (count_in2<<1));
							SET_HALF( pWrite, (count_write<<1), data );
							count_write++; count_in2++;

						}while((data & 0x20) == 0);

						SET_HALF( pWrite, (count_write - 1)<<1, (data&~0x20) ); 
					}
					
					count_in1+=2;
					
					}while(count_in1 < offset);
				
				}
						if(offset & 1 != 0){
							data = GET_HALF(src2, (count_in2<<1));
							SET_HALF( pWrite, (count_write<<1), data );
							count_write++; count_in2++;
						}
						return count_write;
}


	void ViewIMG ( array<unsigned char>^ buffer, PictureBox^ pictureBox1 )
	{

		unsigned int length = buffer->Length;
		unsigned char *src = (unsigned char *)malloc ( length - 0x10 );
		
		Marshal::Copy(buffer, 0x10, IntPtr(src), buffer->Length - 0x10);

		unsigned char *dst = (unsigned char *)malloc ( 800 * 480 * 2 );
		unsigned int Length_Img = IMG_decompress( src, dst);		
		
			
		unsigned int width;// = 480;
		unsigned int height;// = 800;
		if(Length_Img == 0x5DC00){
		width = 480;
		height = 800;
		}else if(Length_Img == 0x1F400){
		width = 320;
		height = 400;
		}else if(Length_Img == 0x12C00){
		width = 240;
		height = 320;
		}else{
			return;
		}

			Bitmap^ bmp = gcnew Bitmap(width, height, Imaging::PixelFormat::Format16bppRgb565);
				Rectangle rect = Rectangle(0,0,width,height);
					System::Drawing::Imaging::BitmapData^ bmpData = bmp->LockBits( rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, bmp->PixelFormat );
						IntPtr ptr = bmpData->Scan0;
							int bytes = Math::Abs(bmpData->Stride) * height;
								memcpy( (void*)(ptr), dst, bytes);
					
						bmp->UnlockBits( bmpData );
					pictureBox1->Image = dynamic_cast<Image^>(bmp);

			free( src );
			free ( dst );


	}
	void Play_IMG(){
				//unsigned int count=0;
				//unsigned int files_count = Directory::GetFiles(OpenFolder, "*.img")->Length;
		if(pictureBox1->Tag == nullptr){return;}
		for each(String^ PathFile in Directory::GetFiles(dynamic_cast<String^>(pictureBox1->Tag), "*.img")){	
			array<unsigned char>^ myStreamOpen ;
				if ( (myStreamOpen = File::ReadAllBytes(PathFile)) == nullptr ){ Environment::CurrentDirectory = AppPath; return; }

				ViewIMG (myStreamOpen, pictureBox1 );
				Thread::Sleep(100);

				}
	}

	void Start_Play_IMG(){

				 if( backgroundWorker1->IsBusy )
						{
							backgroundWorker1->CancelAsync();
						}
						else
						{
							//DumpArgumentSave^ dump_argument = gcnew DumpArgumentSave;
							//dump_argument->SaveFileName = SaveFileName;
							//dump_argument->path = OpenFileName;
							//dump_argument->decompress = true;
							backgroundWorker1->RunWorkerAsync(/* dynamic_cast <System::Object^> (dump_argument)*/ );
				 }


	}

private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {

			Start_Play_IMG();
		 }
//private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {
//
//			DialogResult = System::Windows::Forms::DialogResult::Cancel;
//
//		 }
private: System::Void button3_Click(System::Object^  sender, System::EventArgs^  e) {

			FolderBrowserDialog^ FolderBrowserDialog1 = gcnew FolderBrowserDialog;
			FolderBrowserDialog1->ShowNewFolderButton = false;
			FolderBrowserDialog1->SelectedPath = Environment::CurrentDirectory;
			if (FolderBrowserDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}
			Environment::CurrentDirectory = AppPath;

			pictureBox1->Tag = FolderBrowserDialog1->SelectedPath;
			Start_Play_IMG();

		 }
private: System::Void PLAY_Load(System::Object^  sender, System::EventArgs^  e) {

			 AppPath = Environment::CurrentDirectory;
		 }
private: System::Void backgroundWorker1_DoWork(System::Object^  sender, System::ComponentModel::DoWorkEventArgs^  e) {

				Play_IMG();

		 }
};
}
