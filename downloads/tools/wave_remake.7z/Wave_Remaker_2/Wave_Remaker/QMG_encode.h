#pragma once


//#include "Qmage.h"
#include <stdlib.h>
#include <memory.h>

//	const unsigned short difftableQMG[256] = {
//          1,         3,     0x100,         2,         8,	    7,         6,     0x300,
//		  0x10,      4,     0x200,         9,      0x40,      0x18,         5,     0x20,
//		  0xC,     0xE,       0xF,       0xA,      0xC0,     0x800,     0x700,     0x101,
//		  0x400,      0xB,      0x30,      0x11,      0x80,     0x600,    0xD,      0x12,
//		  0x1C,     0x500,      0x1B,     0x1E,      0x14,      0x1A,      0x28,     0x38,
//     0x1000,      0x1F,      0x19,      0x16,      0x60,   0x2000,      0x13,      0x1D, 
//	 0x103,      0x24,       0x17,      0x15,     0x102,     0x1C0,     0xF00,     0x3C, 
//	 0x301,     0xC00,    0x1800,      0x48,       0x21,      0x34,     0xE00,     0x202, 
//	 0x2C,     0x70,     0xA00,     0x303,      0x36,     0x201,       0x3F,     0xD00,    
//	 0x180,      0x3E,    0x3000,    0x900,      0x78,      0x22,      0x50,      0x3A,
//       0x41,     0x107,      0x33,     0x106,      0x26,     0x2A,      0xA0,      0x23, 
//	   0x29,      0x88,       0x44,      0x3D,      0xE0,      0x32,      0x2E,     0x39,  
//	   0x31,      0x2D,      0xF0,     0x140,      0xB00,      0x3B,      0x58,    0x4000, 
//	   0x37,     0x35,      0x68,     0x302,      0x7C,      0x2F,       0x27,      0x64,   
//	   0x90,      0x74,     0x203,    0x104,      0x6C,    0x1100,     0x3C0,      0xFF,
//       0x25,    0xF000,    0x1F00,     0x701,      0x42,     0x7F,      0x2B,     0x105,  
//	   0x54,    0x1C00,       0x4C,     0x801,      0x43,    0x6000,      0x5C,     0x7E,  
//	   0xE8,     0x108,      0xF8,    0xE000,      0x206,    0x1E00,     0x380,      0x61,
//	   0x7A,     0x4E,     0x601,    0x1001,      0xC8,    0x8000,     0x1D00,      0xD0, 
//	   0x72,      0x49,    0x1600,   0x1A00,      0x46,    0x7000,     0x10F,     0x110,
//       0x76,    0x1200,    0x1400,     0x404,     0x606,    0x10E,      0xFC,    0x1700,  
//	   0x6E,      0xFE,     0x1300,      0x62,      0x66,    0xC000,     0x204,    0x306,  
//	   0x63,     0x707,     0x280,     0x602,       0x55,      0x47,      0x6A,     0x10C, 
//	   0x52,    0x501,      0xD8,     0x307,      0x73,     0x109,      0x808,     0x401, 
//	   0x4A,    0x2020,      0x5A,    0x702,      0xB0,      0x45,     0x207,     0x304,
//      0x402,      0x5E,     0x10A,      0x79,    0x3800,     0xF4,    0x1500,     0x1E0, 
//	  0x1B00,      0x71,     0x1010,      0xC1,      0xE4,     0x502,      0x56,     0x7D,
//	  0x81,      0x77,      0xCC,     0x703,      0x10D,     0x205,     0x340,    0x5000,  
//	  0x82,     0x67,    0xFF00,     0x120,      0x69,      0x98,       0xC3,    0x1900, 
//	  0x65,      0x7B,     0x240,    0x603,      0xEC,      0x59,      0xFA,     0x403,
//       0x75,      0x6F,    0x3100,    0x3300,      0x4F,     0xB8,      0x6D,     0x208, 
//	   0x4D,     0x111,       0x51,     0x20E,      0xDC,      0xC4,    0x2100,     0xA8
//};

namespace ImageUtils
{
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	using namespace System::Runtime::InteropServices;



void * sub_4DCD30(void *a1, const void *a2, unsigned int a3) 
{
	void *result;

	memcpy(a1, a2, 4 * (a3 >> 2));
	result = a1;
	memcpy((char *)a1 + 4 * (a3 >> 2), (char *)a2 + 4 * (a3 >> 2), a3 & 3);
	return result; 
}


int QM_WCodec_1st_encode(unsigned char* src, /*unsigned char* pBloc1, unsigned char* pBloc2, unsigned char* pBloc3,*/ unsigned char* pOut, int HW, int _2or4) { 


unsigned int v7; // ebx@1 
void * pBuff; // ebp@1 
unsigned int _HW; // edi@1 
signed int count; // esi@1 
size_t len_16; // ST08_4@1 
void * pArray; // eax@3 
unsigned char* v14; // ebp@6 
signed int v15; // eax@7 
void *v16; // ecx@8 
signed int v17; // edx@18 
const void *v18; // ecx@18 
void *v19; // ecx@23 
signed int v20; // ebx@23 
void *v21; // eax@25 
int v22; // ebp@25 
int v23; // edx@27 
int v24; // esi@27 
void *v25; // eax@30 
signed int v26; // edx@30 
const void *v27; // ecx@30 
signed int v28; // eax@35 
//unsigned char* v29; // ebp@35 
int count_bloc1; // esi@35 
const void *v31; // ecx@36 
unsigned int v32; // ecx@40 
unsigned int v33; // edx@41 
int i; // ecx@41 
int v35; // edi@41 
void *v36; // edi@41 
unsigned int v37; // ecx@41 
unsigned char* v38; // edi@49 
unsigned int v39; // edx@54 
unsigned int j; // ecx@54 
unsigned char* v41; // edi@54 
signed int v42; // eax@59 
const void *v43; // ecx@60 
unsigned int v44; // ebx@64 
unsigned int k; // ecx@65 
unsigned int v46; // edi@65 
void *v47; // edi@65 
char v48; // zf@72 
unsigned int v49; // edx@75 
unsigned int l; // ecx@75 
unsigned char* v51; // edi@75 
unsigned int count_bloc2; // edi@79 
int v53; // ecx@81 
unsigned char* v54; // eax@82 
signed int v55; // [sp+10h] [bp-2Ch]@1 
//void *v56; // [sp+14h] [bp-28h]@3 
signed int v57; // [sp+18h] [bp-24h]@1 
//const void *v58; // [sp+1Ch] [bp-20h]@1 
signed int v59; // [sp+20h] [bp-1Ch]@1 
unsigned int v60; // [sp+24h] [bp-18h]@1 
int v61; // [sp+24h] [bp-18h]@49 
signed int v62; // [sp+28h] [bp-14h]@1 
unsigned char* v63; // [sp+28h] [bp-14h]@49 
unsigned char* v64; // [sp+2Ch] [bp-10h]@49 
int v65; // [sp+30h] [bp-Ch]@1 
int v66; // [sp+34h] [bp-8h]@1 
signed int v67; // [sp+4Ch] [bp+10h]@64 
//int v68; // [sp+54h] [bp+18h]@1 
unsigned int v69; // [sp+58h] [bp+1Ch]@1 


_HW = (_2or4 * HW) >> 2; 
count = 0; 
v7 = 0; 
v55 = 0; 
v60 = (_2or4 * HW) >> 2; 
v65 = _2or4 * HW - 4 * _HW; 
len_16 = 4 * (_2or4 * HW) >> 2 >> 1; 
v66 = 4 * _HW; 
v62 = 0; 
v69 = 0; 
count_bloc2 = 0; 
v59 = 0; 
v57 = 0; 

unsigned char* pBloc1 = (unsigned char*)malloc(_2or4 * HW);
unsigned char* pBloc2 = (unsigned char*)malloc(_2or4 * HW);
unsigned char* pBloc3 = (unsigned char*)malloc(_2or4 * HW);

pBuff = malloc(len_16); 
//v58 = v8; 
if ( !pBuff ) 
{
	//dword_1670FE0 = -13;
	return -1;
}
pArray = calloc(8u, _HW); 
//v56 = pArray; 
if ( !pArray ) 
{
	//dword_1670FE0 = -13;
	free(pBuff); 
	return -1; 
}
if ( _HW > 0 )
{
	v14 = src;
	do {
		v15 = 0;
		if ( count > 0 )
		{
			v16 = pArray;
			while ( *(unsigned int *)v14 != *(unsigned int *)v16 )
			{
				++v15;
				v16 = (char *)v16 + 8;
				if ( v15 >= count ) 
					goto LABEL_13;
			}
			++*((unsigned int *)pArray + 2 * v15 + 1);
		}
LABEL_13:
		if ( v15 == count )
		{
			++count;
			*((unsigned int *)pArray + 2 * v15) = *(unsigned int *)v14;
		}
		v14 += 4;
		--_HW;
	}while ( _HW );
	
	_HW = v60;
	//pArray = v56;
	v62 = count;
}
if ( count > 0 ) 
{
	v18 = pBuff; 
	v17 = count; 
	do { 
		if ( *((unsigned int *)pArray + 1) > 1u )
		{
			*(unsigned int *)v18 = *(unsigned int *)pArray;
			v18 = (unsigned char *)v18 + 4;
			++v55;
		}
		pArray = (unsigned int*)pArray + 8;
		--v17;
	}while ( v17 );

	if ( v55 > 508 ) 
	{
		v19 = pArray;
		v20 = 0; 
		do { 
			if ( v20 < count ) 
			{
				v21 = v19;
			v22 = count - v20;
			do { 
				if ( *((unsigned int *)v19 + 1) < *((unsigned int *)v21 + 1) )
				{ 
					v23 = *(unsigned int *)v19;
					v24 = *((unsigned int *)v19 + 1);
					*(unsigned int *)v19 = *(unsigned int *)v21;
					*((unsigned int *)v19 + 1) = *((unsigned int *)v21 + 1);
					_HW = v60;
					*(unsigned int *)v21 = v23;
					*((unsigned int *)v21 + 1) = v24;
					count = v62;
				}
				v21 = (char *)v21 + 8;
				--v22;
			
			}while ( v22 );

			} 
			++v20;
			v19 = (char *)v19 + 8;
		}while ( v20 < 508 );
		


		v27 = pBuff;
		v25 = pArray;
		v55 = 0;
		v26 = 508;
		do {
			if ( *((unsigned int *)v25 + 1) > 1u )
			{
				*(unsigned int *)v27 = *(unsigned int *)v25;
				++v55; 
				v27 = (char *)v27 + 4;
			}
			v25 = (char *)v25 + 8;
			--v26;
		} while ( v26 );
		
		v7 = v69; 
	}
}
//v29 = pBloc1;
count_bloc1 = 4 * v55;
sub_4DCD30((void *)pBloc1, pBuff, 4 * v55); 
v28 = 0;
if ( v55 > 0 ) 
{
	v31 = pBuff;
	while ( *(unsigned int *)src != *(unsigned int *)v31 )
	{
		++v28;
		v31 = (char *)v31 + 4;
		if ( v28 >= v55 )
			goto LABEL_46;
	}
	v32 = v28 + 1; 
	if ( v28 + 1 >= 255 )
	{
		v36 = pBloc1 + count_bloc1;
		v33 = v32 / 0xFF; 
		count_bloc1 += v32 / 0xFF;
		v37 = v32 / 0x3FC;
		memset(v36, -1, 4 * v37);
		v35 = (int)((unsigned char *)v36 + 4 * v37);
		v7 = v69;
			
		for ( i = v33 & 3; i; i-- )
				*(unsigned char *)v35++ = -1;

		_HW = v60;
		v32 = -255 * v33 + v28 + 1;
	}
	*(unsigned char *)( pBloc1 + count_bloc1++) = v32;
	v57 = 0;
}
LABEL_46: 
if ( v28 == v55 ) 
{
	*(unsigned char *)(pBloc1 + count_bloc1++) = 0;
	*(unsigned int *)pBloc3 = *(unsigned int *)src;
	v59 = 1;
	v57 = 1;
}
if ( _HW > 1 )
{
	v64 = pBloc3 + 4 * v59;
	v38 = src + 4;
	v63 = src + 4;
	v61 = v60 - 1;
	do {
		if ( v57 )
			goto LABEL_59; 
		if ( *(unsigned int *)v38 != *(unsigned int *)(v38 - 4) ) 
		{
			if ( (signed int)v7 >= 255 )
			{
				v39 = v7 / 0xFF;
				memset((void *)((unsigned char*)(pBloc2) + count_bloc2), -1, 4 * v7 / 0x3FC);
				v41 = pBloc2 + count_bloc2 + 4 * v7 / 0x3FC;
				for ( j = v7 / 0xFF & 3; j; --j ) 
					*(unsigned char *)v41++ = -1;

				v38 = v63;
				v7 = -255 * v39 + v69;
				count_bloc2 += v39;
			}
			v69 = 0;
			*(unsigned char *)(pBloc2 + count_bloc2++) = v7;
			v7 = 0;
			//++count_bloc2;
LABEL_59:
			v42 = 0;
			if ( v55 > 0 )
			{
				v43 = pBuff;
				while ( *(unsigned int *)v38 != *(unsigned int *)v43 )
				{
					++v42;
					v43 = (char *)v43 + 4;
					if ( v42 >= v55 )
						goto LABEL_70;
				}
				v44 = v42 + 1;
				v67 = v42;
				if ( v42 + 1 >= 255 ) 
				{
					v47 = (void *)(pBloc1 + count_bloc1);
					count_bloc1 += v44 / 0xFF;
					memset(v47, -1, 4 * v44 / 0x3FC);
					v46 = (unsigned int)((char *)v47 + 4 * v44 / 0x3FC);
					//v29 = (unsigned char*)pBloc1;
					for ( k = v44 / 0xFF & 3; k; --k )
						*(unsigned char *)v46++ = -1;
					v38 = v63;
					v44 %= 0xFFu;
					v42 = v67;
				}
				*(unsigned char *)(pBloc1 + count_bloc1++) = v44;
				v7 = v69;
				//++count_bloc1;
				v57 = 0;
			}
LABEL_70: 
			if ( v42 == v55 )
			{
				*(unsigned char *)(pBloc1 + count_bloc1++) = 0;
				*(unsigned int *)v64 = *(unsigned int *)v38;
				++v59;
				v64 += 4;
				v57 = 1;
			}
			goto LABEL_72;
		}
		++v7;
		v69 = v7; 
LABEL_72: 
		v38 += 4;/////////////
		v48 = v61 == 1;
		v63 = v38;////////////
		--v61;
	}while ( !v48 );
}
	if (! v57 ) 
	{
//		count_bloc2 = v68;
//	} else { 
			if ( (signed int)v7 >= 255 )
			{
				//v49 = v7 / 0xFF; 
				memset((void *)( pBloc2 + count_bloc2), -1, 4 * v7 / 0x3FC);
				v51 =  pBloc2 + count_bloc2 + 4 * v7 / 0x3FC;
					for ( l = v7 / 0xFF & 3; l; --l )
						*(unsigned char *)v51++ = -1;
				
				v7 = -255 * v7 / 0xFF + v69;
				count_bloc2 += v7 / 0xFF;
			}
	*(unsigned char *)( pBloc2 + count_bloc2++) = v7;
	//count_bloc2 = count_bloc2 + 1;
	}
v53 = v65;
if ( v65 )
{
	v54 = src + v66;
	do {
		*(unsigned char *)( pBloc1 + count_bloc1++) = *(unsigned char *)v54++;
		--v53; 
	} while ( v53 );
}

if ( count_bloc1 & 3 )
count_bloc1 += 4 - (count_bloc1 & 3);
if ( count_bloc2 & 3 )
count_bloc2 += 4 - (count_bloc2 & 3);

*(unsigned int *)pOut = v55;
*(unsigned int *)(pOut + 4) = count_bloc1 - 4 * v55;
*(unsigned int *)(pOut + 8) = count_bloc2;
*(unsigned int *)(pOut + 12) = v59;
	free((void *)pBuff);
	free(pArray);
return count_bloc1 + count_bloc2 + 4 * v59 + 16;



}










void IMG_Compress( String^ path/*, String^ SaveFileName, BackgroundWorker^ bwAsync*/){

			Bitmap^ bmp = gcnew Bitmap(path);
				
			if(bmp->PixelFormat != Imaging::PixelFormat::Format24bppRgb 
				&& bmp->PixelFormat != Imaging::PixelFormat::Format32bppArgb
				&& bmp->PixelFormat != Imaging::PixelFormat::Format32bppRgb){
					
			MessageBox::Show("Pixel format is not correct", "ERROR",  MessageBoxButtons::OK, MessageBoxIcon::Error);
				
					return;
				}//else if(bmp->Height != 800 || bmp->Width != 480){
//				
//					return;
//				}
			
			Rectangle rect = Rectangle(0,0,bmp->Width,bmp->Height);
					System::Drawing::Imaging::BitmapData^ bmpData = bmp->LockBits( rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, bmp->PixelFormat );
						IntPtr ptrbmp = bmpData->Scan0;
							unsigned int len = Math::Abs(bmpData->Stride) * bmp->Height;
							
			unsigned char *src = (unsigned char *)malloc ( len );
				memcpy( src, (const void*)(ptrbmp), len);
					unsigned char *dst = (unsigned char *)malloc ( bmp->Width * bmp->Height * 2 );


}


}