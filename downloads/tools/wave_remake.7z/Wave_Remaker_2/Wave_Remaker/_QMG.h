#pragma once




namespace ImageUtils {


	using namespace System;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;



	static const unsigned short difftable[256] = {
          1,         3,     0x100,         2,         8,	    7,         6,     0x300,
		  0x10,      4,     0x200,         9,      0x40,      0x18,         5,     0x20,
		  0xC,     0xE,       0xF,       0xA,      0xC0,     0x800,     0x700,     0x101,
		  0x400,      0xB,      0x30,      0x11,      0x80,     0x600,    0xD,      0x12,
		  0x1C,     0x500,      0x1B,     0x1E,      0x14,      0x1A,      0x28,     0x38,
     0x1000,      0x1F,      0x19,      0x16,      0x60,   0x2000,      0x13,      0x1D,     0x103,      0x24,
       0x17,      0x15,     0x102,     0x1C0,     0xF00,     0x3C,     0x301,     0xC00,    0x1800,      0x48,
       0x21,      0x34,     0xE00,     0x202,      0x2C,     0x70,     0xA00,     0x303,      0x36,     0x201,
       0x3F,     0xD00,     0x180,      0x3E,    0x3000,    0x900,      0x78,      0x22,      0x50,      0x3A,
       0x41,     0x107,      0x33,     0x106,      0x26,     0x2A,      0xA0,      0x23,      0x29,      0x88,
       0x44,      0x3D,      0xE0,      0x32,      0x2E,     0x39,      0x31,      0x2D,      0xF0,     0x140,
      0xB00,      0x3B,      0x58,    0x4000,      0x37,     0x35,      0x68,     0x302,      0x7C,      0x2F,
       0x27,      0x64,      0x90,      0x74,     0x203,    0x104,      0x6C,    0x1100,     0x3C0,      0xFF,
       0x25,    0xF000,    0x1F00,     0x701,      0x42,     0x7F,      0x2B,     0x105,      0x54,    0x1C00,
       0x4C,     0x801,      0x43,    0x6000,      0x5C,     0x7E,      0xE8,     0x108,      0xF8,    0xE000,
      0x206,    0x1E00,     0x380,      0x61,      0x7A,     0x4E,     0x601,    0x1001,      0xC8,    0x8000,
     0x1D00,      0xD0,      0x72,      0x49,    0x1600,   0x1A00,      0x46,    0x7000,     0x10F,     0x110,
       0x76,    0x1200,    0x1400,     0x404,     0x606,    0x10E,      0xFC,    0x1700,      0x6E,      0xFE,
     0x1300,      0x62,      0x66,    0xC000,     0x204,    0x306,      0x63,     0x707,     0x280,     0x602,
       0x55,      0x47,      0x6A,     0x10C,      0x52,    0x501,      0xD8,     0x307,      0x73,     0x109,
      0x808,     0x401,      0x4A,    0x2020,      0x5A,    0x702,      0xB0,      0x45,     0x207,     0x304,
      0x402,      0x5E,     0x10A,      0x79,    0x3800,     0xF4,    0x1500,     0x1E0,    0x1B00,      0x71,
     0x1010,      0xC1,      0xE4,     0x502,      0x56,     0x7D,      0x81,      0x77,      0xCC,     0x703,
      0x10D,     0x205,     0x340,    0x5000,      0x82,     0x67,    0xFF00,     0x120,      0x69,      0x98,
       0xC3,    0x1900,      0x65,      0x7B,     0x240,    0x603,      0xEC,      0x59,      0xFA,     0x403,
       0x75,      0x6F,    0x3100,    0x3300,      0x4F,     0xB8,      0x6D,     0x208,      0x4D,     0x111,
       0x51,     0x20E,      0xDC,      0xC4,    0x2100,     0xA8
};

	void copy_2_bytes_from_offset_out_stream(MemoryStream^ StreamBlock4, int offset){
							int offset1 = offset*2;
							StreamBlock4->Seek(-offset1, SeekOrigin::Current);
							unsigned char a = StreamBlock4->ReadByte();
							unsigned char b = StreamBlock4->ReadByte();
							StreamBlock4->Seek(0, SeekOrigin::End);
							StreamBlock4->WriteByte(a);
							StreamBlock4->WriteByte(b);
	}
	void copy_2_bytes_from_compressed_stream(MemoryStream^ StreamBlock3, MemoryStream^ StreamBlock4) {
							StreamBlock4->WriteByte(StreamBlock3->ReadByte());
							StreamBlock4->WriteByte(StreamBlock3->ReadByte());
							//G_Offset+=2;
	}
	void copy_2_bytes_with_xor(MemoryStream^ StreamBlock2, MemoryStream^ StreamBlock4, int offset){
					int offset1 = offset*2;
					StreamBlock4->Seek( -offset1, SeekOrigin::Current);
					unsigned short a = StreamBlock4->ReadByte();
					unsigned short b = StreamBlock4->ReadByte();
					b = b << 8;
					b = b | a;
					b = b ^ difftable[StreamBlock2->ReadByte() ];
					StreamBlock4->Seek(0, SeekOrigin::End);
					a = b & 0xFF;
					b = b >> 8;
					StreamBlock4->WriteByte(a);
					StreamBlock4->WriteByte(b);
	}


	array<unsigned char>^ QMG( array<unsigned char>^ compress/*, BackgroundWorker^ bwAsync*/){
			
	
				MemoryStream^ stream = gcnew MemoryStream(compress);
				BinaryReader^ br = gcnew BinaryReader( stream );

				br->BaseStream->Seek(0x6, SeekOrigin::Begin);

				unsigned short width = br->ReadInt16();
				unsigned short height = br->ReadInt16();
				
				br->BaseStream->Seek(0x10, SeekOrigin::Begin);

				int first = br->ReadInt32();
				int len_1 = br->ReadInt32();
				int len_2 = br->ReadInt32();

				array<unsigned char>^ block_1 = gcnew array<unsigned char>(len_1 + 0x10);
				array<unsigned char>^ block_2 = gcnew array<unsigned char>(len_2 + 0x10);
				array<unsigned char>^ block_3 = gcnew array<unsigned char>((br->BaseStream->Length -(len_1 + len_2 + 0xC)) + 0x100);

				br->Read(block_1, 0, len_1);
				MemoryStream^ StreamBlock1 = gcnew MemoryStream( block_1->Length );// ����� ������� �����
				StreamBlock1->Write(block_1, 0, len_1);
				StreamBlock1->Seek(0, SeekOrigin::Begin);

				br->Read(block_2, 0, len_2);
				MemoryStream^ StreamBlock2 = gcnew MemoryStream( block_2->Length );// ����� ������� �����
				StreamBlock2->Write(block_2, 0, len_2);
				StreamBlock2->Seek(0, SeekOrigin::Begin);

				br->Read(block_3, 0, block_3->Length);
				MemoryStream^ StreamBlock3 = gcnew MemoryStream(block_3->Length );//first >> 4 << 2 ); ///������ ����� ��������. ��� �������� �����
				StreamBlock3->Write(block_3, 0, block_3->Length);
				StreamBlock3->Seek(0, SeekOrigin::Begin);

				MemoryStream^ StreamBlock4 = gcnew MemoryStream( );
				StreamBlock4->Seek(0, SeekOrigin::Begin);


				br->Close();
////////////
				unsigned int CountBit = 0;
//				unsigned int BitOperation = 0;
				unsigned int Offset = 0;
				unsigned int Count = (first & 0xFFFFFFF0) >> 2;
				unsigned int CountDword = 4;
				unsigned int Switch = 0;
				unsigned int BitsBuffer = 0;

				for(int d=0; d<0x4; d++){
					StreamBlock4->WriteByte(StreamBlock3->ReadByte());
				}

				//while(CountBit < 0x12){
				//do{	
				while ( CountBit <= 17 ){
				BitsBuffer =( BitsBuffer << 8) | StreamBlock1->ReadByte();
					CountBit+= 0x8;
				}//while(CountBit < 0x17);

				for(int n = 0; n < 4; n++){
				CountBit--;
					if((BitsBuffer>>CountBit)/*<<0x1F*/&1 == 0){
						CountBit--;	
							if((BitsBuffer>>CountBit)<<0x1F == 0){
								unsigned short a = StreamBlock3->ReadByte();
								unsigned short b = StreamBlock3->ReadByte();
									Offset = b << 8;
									Offset = Offset | a;
							}else{
								Offset = StreamBlock2->ReadByte();
							}
					}

			for(int i = 0; i < 2; i++){
				
				CountBit--;
					if((BitsBuffer>>CountBit)/*<<0x1F*/&1 == 0){
						CountBit--;	
							if((BitsBuffer>>CountBit)/*<<0x1F*/&1 == 0){
								//diff � �������� ������
								copy_2_bytes_with_xor(StreamBlock2, StreamBlock4, Offset);
							}else{
								//������ �������� �� 3 � �����
								copy_2_bytes_from_compressed_stream(StreamBlock3, StreamBlock4);
							}
					}else{
								//�� ������ �� ������� ��� �����
								copy_2_bytes_from_offset_out_stream(StreamBlock4, Offset);
					}
			}//for 2
		}//for 3

		while( CountDword <  Count){

							//CountDword+=4;

							while( CountBit < 2){
								BitsBuffer =( BitsBuffer << 8) | StreamBlock1->ReadByte();
								CountBit+= 0x8;
							}

						CountBit--;	
						if((BitsBuffer>>CountBit)<<0x1F == 0){
//////����� ��� ����� �������
							CountBit--;	
								if((BitsBuffer>>CountBit)<<0x1F == 0){
//�������� 0�10 ���� �� 3 ������
									for(int d=0; d<0x10; d++){
										StreamBlock4->WriteByte(StreamBlock3->ReadByte());
									}
								}else{
// �������� 8 ��� �� ��� ����� �� ������� �� ������
									for(int g=0; g<0x8; g++){
									int Offset1 = Offset * 2;
									StreamBlock4->Seek(-Offset1, SeekOrigin::Current);
									unsigned char a = StreamBlock4->ReadByte();
									unsigned char b = StreamBlock4->ReadByte();
									StreamBlock4->Seek(0, SeekOrigin::End);
									StreamBlock4->WriteByte(a);
									StreamBlock4->WriteByte(b);
									}
							}

							}else{
								
								Switch = StreamBlock2->ReadByte();
							
								while( CountBit <= 0xF){
								BitsBuffer =( BitsBuffer << 8) | StreamBlock1->ReadByte();
								CountBit+= 0x8;
								}//while

					unsigned int Shift = 0x18;
					for(int n = 0; n < 4; n++){

						CountBit--;
							if((BitsBuffer>>CountBit)<<0x1F == 0){
								CountBit--;	
									if((BitsBuffer>>CountBit)<<0x1F == 0){
										unsigned short a = StreamBlock3->ReadByte();
										unsigned short b = StreamBlock3->ReadByte();
											Offset = b << 8;
											Offset = Offset | a;
									}else{
										Offset = StreamBlock2->ReadByte();
									}
							}

							for(int i = 0; i < 2; i++){
								
								if(Switch << Shift/*0x18*/ >= 0){
									CountBit--;	
										if((BitsBuffer>>CountBit)<<0x1F == 0){
											//diff � �������� ������
											copy_2_bytes_with_xor(StreamBlock2, StreamBlock4, Offset);
										}else{
											//������ �������� �� 3 � �����
											copy_2_bytes_from_compressed_stream(StreamBlock3, StreamBlock4);
										}
								}else{
									//�� ������ �� ������� ��� �����
									copy_2_bytes_from_offset_out_stream(StreamBlock4, Offset);
								}

									Shift++;
								}//for 2

							}//for 4

						}//else		
					
								CountDword+=4;			
					
					}//while




					
					
					
					array<unsigned char>^ decompress = gcnew array<unsigned char>(StreamBlock4->Length);
							StreamBlock4->Seek(0, SeekOrigin::Begin);
							StreamBlock4->Read(decompress, 0, decompress->Length);

				return decompress;
}




	void Rbm_QM32_View(unsigned int Width, unsigned int Height, array<unsigned char>^ data, PictureBox^ pictureBox1){


array<unsigned char>^ dst = gcnew array<unsigned char>(Width * Height * 4);

dst = QMG(data);
int p = 0;
	}
};