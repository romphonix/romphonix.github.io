﻿



using namespace System;
using namespace System::Collections::Generic;
using namespace System::Text;
using namespace System::IO;

namespace TinySharpZip
{
//     ref class ZipEntry
//    {
//
//         System::DateTime lastModified;
//
//
//         ZipEntry()
//        {
//			lastModified = System::DateTime::Now;
//        }
//
//
//	public: property System::DateTime LastModified
//        {
//           System::DateTime get() { return lastModified; }
//           void/*System::DateTime*/ set (System::DateTime value){ lastModified = value; }
//        }
//
//
//         void SetLastModifiedDateTime(unsigned int dosTime)
//        {
//			unsigned int second = Math::Min((unsigned int)59, (unsigned int)(2 * (dosTime & 0x1f)));
//			unsigned int minute = Math::Min((unsigned int)59, (unsigned int)((dosTime >> 5) & 0x3f));
//			unsigned int hour = Math::Min((unsigned int)23, (unsigned int)((dosTime >> 11) & 0x1f));
//			unsigned int month = Math::Max((unsigned int)1, Math::Min((unsigned int)12,(unsigned int) ((dosTime >> 21) & 0xf)));
//            unsigned int year = ((dosTime >> 25) & 0x7f) + 1980;
//			int day = Math::Max((unsigned int)1, Math::Min((unsigned int)( DateTime::DaysInMonth((unsigned int)year, (unsigned int)month)), (unsigned int)((dosTime >> 16) & 0x1f)));
//            lastModified = DateTime((unsigned int)year, (unsigned int)month, day, (unsigned int)hour, (unsigned int)minute, (unsigned int)second);
//        }
//
//         unsigned int GetLastModifiedDateTime()
//        {
//			unsigned int year = (unsigned int)lastModified.Year;
//			unsigned int month = (unsigned int)lastModified.Month;
//			unsigned int day = (unsigned int)lastModified.Day;
//			unsigned int hour = (unsigned int)lastModified.Hour;
//			unsigned int minute = (unsigned int)lastModified.Minute;
//			unsigned int second = (unsigned int)lastModified.Second;
//
//            if (year < 1980)
//            {
//                year = 1980;
//                month = 1;
//                day = 1;
//                hour = 0;
//                minute = 0;
//                second = 0;
//            }
//            else if (year > 2107)
//            {
//                year = 2107;
//                month = 12;
//                day = 31;
//                hour = 23;
//                minute = 59;
//                second = 59;
//            }
//
//            unsigned int dosTime = ((year - 1980) & 0x7f) << 25 |
//                (month << 21) |
//                (day << 16) |
//                (hour << 11) |
//                (minute << 5) |
//                (second >> 1);
//            return dosTime;
//        }
//
////        #endregion
//    };
}
