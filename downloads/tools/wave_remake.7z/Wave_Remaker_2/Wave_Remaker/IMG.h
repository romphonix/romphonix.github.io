#pragma once

#include <memory.h>



namespace ImageUtils
{


	
	unsigned int IMG_decompress(unsigned char* src, unsigned char* pWrite){


				unsigned int count_in1=0, count_in2=0, count_write=0;
				unsigned char *src1, *src2, *pRead;
				unsigned int data=0, count=0;

				unsigned int offset = (GET_HALF(src, 0)<<0x8 | GET_HALF(src, 0)>>0x8) & 0xFFFF;
				src2 = src + 2 + offset;
				src1 = src+2;
				
				if(offset & 1 != 0){ //���� ���������� ������� ���, �.�. ����� �������� �����
					
					offset = (offset & 0xFFFE) | ( GET_BYTE(src, 2) << 15 ) | ( GET_BYTE(src, 3) << 23);
					src2 = src + 4 + offset;
					src1 = src + 4;
				}

				do{
					data = GET_HALF(src2, (count_in2<<1));
					SET_HALF( pWrite, (count_write<<1), data );
					count_write++; count_in2++;

				}while((data & 0x20) == 0);

				SET_HALF( pWrite, (count_write - 1)<<1, (data&~0x20) );
				
				if(offset > 0){ // ���� ������� ��� �� ����������
					
					do{

					unsigned short  a = BYTE(src1, count_in1);
					unsigned short  b = BYTE(src1, (count_in1+1));


					pRead = pWrite + ((count_write - ((a & 7)<<8 | b))<<1);
					
					count = 0;

					do{
					SET_HALF( pWrite, (count_write)<<1,	GET_HALF(pRead, count<<1));
					SET_HALF( pWrite, (count_write+1)<<1, GET_HALF(pRead, (count+1)<<1));
					count_write+=2; count+=2;
					}while(count < (a>>4)-2);

					while(count < (a>>4)){
						SET_HALF( pWrite, count_write<<1,	GET_HALF(pRead, count<<1));
						count_write++; count++;
						
					}
					
					if((a & 8) != 0){ // ���� 4� ��� �� ����������
						
						do{
							data = GET_HALF(src2, (count_in2<<1));
							SET_HALF( pWrite, (count_write<<1), data );
							count_write++; count_in2++;

						}while((data & 0x20) == 0);

						SET_HALF( pWrite, (count_write - 1)<<1, (data&~0x20) ); 
					}
					
					count_in1+=2;
					
					}while(count_in1 < offset);
				
				}
						if(offset & 1 != 0){
							data = GET_HALF(src2, (count_in2<<1));
							SET_HALF( pWrite, (count_write<<1), data );
							count_write++; count_in2++;
						}
						return count_write;
}


	void ViewIMG ( array<unsigned char>^ buffer, PictureBox^ pictureBox1 )
	{

		unsigned int length = buffer->Length;
		unsigned char *src = (unsigned char *)malloc ( length - 0x10 );
		
		Marshal::Copy(buffer, 0x10, IntPtr(src), buffer->Length - 0x10);

		unsigned char *dst = (unsigned char *)malloc ( 800 * 480 * 2 );
		unsigned int Length_Img = IMG_decompress( src, dst);		
		
			
		unsigned int width;// = 480;
		unsigned int height;// = 800;
		if(Length_Img == 0x5DC00){
		width = 480;
		height = 800;
		}else if(Length_Img == 0x1F400){
		width = 320;
		height = 400;
		}else if(Length_Img == 0x12C00){
		width = 240;
		height = 320;
		}else{
			return;
		}



			Bitmap^ bmp = gcnew Bitmap(width, height, Imaging::PixelFormat::Format16bppRgb565);
				Rectangle rect = Rectangle(0,0,width,height);
					System::Drawing::Imaging::BitmapData^ bmpData = bmp->LockBits( rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, bmp->PixelFormat );
						IntPtr ptr = bmpData->Scan0;
							int bytes = Math::Abs(bmpData->Stride) * height;
								memcpy( (void*)(ptr), dst, bytes);
					
						bmp->UnlockBits( bmpData );
					pictureBox1->Image = dynamic_cast<Image^>(bmp);

			free( src );
			free ( dst );


	}




	void Save_Image(String^ OpenPath, String^ SavePath, BackgroundWorker^ bwAsync){

			array<unsigned char>^ myStreamOpen ;
			if ( (myStreamOpen = File::ReadAllBytes(OpenPath)) == nullptr ){ return; }
			unsigned char *src = (unsigned char *)malloc ( myStreamOpen->Length - 0x10 );
			
			Marshal::Copy(myStreamOpen, 0x10, IntPtr(src), myStreamOpen->Length - 0x10);

			unsigned char *dst = (unsigned char *)malloc ( 800 * 480 * 2 );
			unsigned int Length_Img = IMG_decompress( src, dst);		
		
			
			unsigned int width;// = 480;
			unsigned int height;// = 800;
			if(Length_Img == 0x5DC00){
			width = 480;
			height = 800;
			}else if(Length_Img == 0x1F400){
			width = 320;
			height = 400;
			}else if(Length_Img == 0x12C00){
			width = 240;
			height = 320;
			}else{
				return;
			}
			Bitmap^ bmp = gcnew Bitmap(width, height, Imaging::PixelFormat::Format16bppRgb565);
				Rectangle rect = Rectangle(0,0,width,height);
					System::Drawing::Imaging::BitmapData^ bmpData = bmp->LockBits( rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, bmp->PixelFormat );
						IntPtr ptr = bmpData->Scan0;
							int bytes = Math::Abs(bmpData->Stride) * height;
								memcpy( (void*)(ptr), dst, bytes);
					
				bmp->UnlockBits( bmpData );

				String^ ext = Path::GetExtension(SavePath)->ToLower();
					if(ext == ".bmp" ){
						bmp->Save(SavePath,Imaging::ImageFormat::Bmp);
					}else if(ext == ".png"){
						bmp->Save(SavePath,Imaging::ImageFormat::Png);
					}else if(ext == ".jpg"){
						bmp->Save(SavePath,Imaging::ImageFormat::Jpeg);
					}else{
						MessageBox::Show("Extension is not correct", "ERROR",  MessageBoxButtons::OK, MessageBoxIcon::Error);
					}
				
	}				


	void Decode_Folder(String^ OpenFolder, String^ SaveFolder, String^ ext, BackgroundWorker^ bwAsync){

				unsigned int count=0;
				unsigned int files_count = Directory::GetFiles(OpenFolder, "*.img")->Length;
				for each(String^ PathFile in Directory::GetFiles(OpenFolder, "*.img")){	
				String^ FileName = Path::GetFileNameWithoutExtension(PathFile);
				String^ SavePath = SaveFolder + L"\\" + FileName + ext;
				Save_Image(PathFile, SavePath, bwAsync);
				count++;
				bwAsync->ReportProgress(Convert::ToInt32( count *  100 /files_count));
				
				}

	}


};