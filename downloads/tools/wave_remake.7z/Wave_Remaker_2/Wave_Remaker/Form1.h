#pragma once

#include "ImageUtils.h"
#include "RC1.h"
#include "CSC.h"
#include "RC2.h"
#include "SEED_Crypto.h"
#include "HightLightXML.h"
#include "RSR.h"
#include "RBM.h"
#include "QMD.h"
#include "LZ32.h"
//#include "QMG__.h"
#include "LanguageID.h"
#include "IMG.h"
#include "IMG_compress.h"
#include "PLAY.h"
#include "LZ16.h"
#include "Qmage.h"
#include "SMT.h"
#include "QMG_encode.h"




namespace Wave_Remaker {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	using namespace ImageUtils;
//	using namespace System::Security::Cryptography;
	using namespace System::Text;
//	using namespace ImageUtils;



//#define DIR_PROJECT		"\\Bada\\"
//#define ROOT_NAME		"FW"



	/// <summary>
	/// ������ ��� Form1
	///
	/// ��������! ��� ��������� ����� ����� ������ ���������� ����� ��������
	///          �������� ����� ����� �������� ("Resource File Name") ��� �������� ���������� ������������ �������,
	///          ���������� �� ����� ������� � ����������� .resx, �� ������� ������� ������ �����. � ��������� ������,
	///          ������������ �� ������ ��������� �������� � ���������������
	///          ���������, ��������������� ������ �����.
	/// </summary>
	public ref class Form1 : public System::Windows::Forms::Form
	{
	public:
		Form1(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~Form1()
		{
			if (components)
			{
				delete components;
			}
		}


	private: Point screenOffset;

	private: System::Windows::Forms::StatusStrip^  statusStrip1;


	private: System::Windows::Forms::TabControl^  tabControl1;









	private: System::ComponentModel::BackgroundWorker^  backgroundWorker1;
	private: System::Windows::Forms::ToolStripStatusLabel^  toolStripProgressBar1;
	private: System::Windows::Forms::ToolStripStatusLabel^  toolStripStatusLabel1;
	private: System::Windows::Forms::ToolStripProgressBar^  toolStripProgressBar2;
	private: System::Windows::Forms::ImageList^  imageList1;

	private: System::ComponentModel::BackgroundWorker^  backgroundWorker2;



































	private: System::Windows::Forms::SplitContainer^  splitContainer3;

	private: System::Windows::Forms::SplitContainer^  splitContainer4;

private: System::ComponentModel::BackgroundWorker^  backgroundWorker3;
private: System::Windows::Forms::ContextMenuStrip^  contextMenuStrip1;
private: System::Windows::Forms::ToolStripMenuItem^  deleteToolStripMenuItem;
private: System::Windows::Forms::TabPage^  tabPage1;
private: System::Windows::Forms::SplitContainer^  splitContainer2;
private: System::Windows::Forms::TreeView^  treeView2;
private: System::Windows::Forms::SplitContainer^  splitContainer5;
private: System::Windows::Forms::MenuStrip^  menuStrip2;
private: System::Windows::Forms::ToolStripMenuItem^  fileToolStripMenuItem1;
private: System::Windows::Forms::ToolStripMenuItem^  dumpFileToolStripMenuItem1;
private: System::Windows::Forms::ToolStripMenuItem^  openDumpToolStripMenuItem1;
private: System::Windows::Forms::PictureBox^  pictureBox4;
private: System::Windows::Forms::PictureBox^  pictureBox5;
private: System::Windows::Forms::ToolStripMenuItem^  imageToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  openImageToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  changeImageToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  saveFileAsToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  debugLToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  debugLevel1ToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  debugLevel2ToolStripMenuItem;



private: System::ComponentModel::BackgroundWorker^  backgroundWorker4;






















private: System::Windows::Forms::ToolStripMenuItem^  closeDumpToolStripMenuItem2;


















private: System::Windows::Forms::TreeView^  treeView5;
private: System::Windows::Forms::SplitContainer^  splitContainer10;
private: System::Windows::Forms::ContextMenuStrip^  contextMenuStrip2;
private: System::Windows::Forms::ToolStripMenuItem^  deleteToolStripMenuItem1;







private: System::Windows::Forms::TabPage^  tabPage2;
private: System::Windows::Forms::SplitContainer^  splitContainer8;
private: System::Windows::Forms::TreeView^  treeView6;
private: System::Windows::Forms::SplitContainer^  splitContainer9;
private: System::Windows::Forms::TreeView^  treeView7;
private: System::Windows::Forms::MenuStrip^  menuStrip1;
private: System::Windows::Forms::ToolStripMenuItem^  fileToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  dumpFileToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  openDumpToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  closeDumpToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  saveFileToolStripMenuItem;
private: System::Windows::Forms::ToolStripTextBox^  toolStripTextBox1;
private: System::Windows::Forms::MenuStrip^  menuStrip4;
private: System::Windows::Forms::ToolStripMenuItem^  fileToolStripMenuItem3;
private: System::Windows::Forms::ToolStripMenuItem^  dumpFileToolStripMenuItem3;
private: System::Windows::Forms::ToolStripMenuItem^  openDumpToolStripMenuItem3;
private: System::Windows::Forms::ToolStripMenuItem^  closeDumpToolStripMenuItem3;
private: System::Windows::Forms::ToolStripTextBox^  toolStripTextBox3;
private: System::Windows::Forms::MenuStrip^  menuStrip5;
private: System::Windows::Forms::ToolStripMenuItem^  fileToolStripMenuItem4;
private: System::Windows::Forms::ToolStripMenuItem^  saveAsORGToolStripMenuItem;
private: System::Windows::Forms::RichTextBox^  richTextBox1;
private: System::Windows::Forms::PictureBox^  pictureBox1;
private: System::Windows::Forms::DataGridView^  dataGridView1;
private: System::ComponentModel::BackgroundWorker^  backgroundWorker5;
private: System::Windows::Forms::ContextMenuStrip^  contextMenuStrip3;


private: System::Windows::Forms::ContextMenuStrip^  contextMenuStrip4;
private: System::Windows::Forms::ToolStripMenuItem^  deleteItLanguageToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  saveChangesToolStripMenuItem;
private: System::Windows::Forms::TabPage^  tabPage6;
//private: System::Windows::Forms::Splitter^  splitter1;
private: System::Windows::Forms::GroupBox^  groupBox2;

private: System::Windows::Forms::GroupBox^  groupBox1;
private: System::Windows::Forms::Button^  button11;
private: System::Windows::Forms::GroupBox^  groupBox3;
private: System::Windows::Forms::GroupBox^  groupBox5;
private: System::Windows::Forms::Button^  button10;
private: System::Windows::Forms::Button^  button1;
private: System::Windows::Forms::GroupBox^  groupBox6;







private: System::Windows::Forms::ToolStripMenuItem^  sToolStripMenuItem;
private: System::Windows::Forms::Button^  button15;
private: System::Windows::Forms::Button^  button4;
private: System::Windows::Forms::ToolStripMenuItem^  deleteItIDSToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  exportLanguageTotxtToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  importLanguageFromtxtToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  saveAsNonCompressedrc1ToolStripMenuItem;

private: System::Windows::Forms::ToolStripMenuItem^  copyToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  cutToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  pasteToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  deleteToolStripMenuItem2;

private: System::Windows::Forms::Button^  button5;

private: System::Windows::Forms::GroupBox^  groupBox4;
private: System::Windows::Forms::GroupBox^  groupBox7;
private: System::Windows::Forms::Button^  button6;
private: System::Windows::Forms::Button^  button8;
private: System::Windows::Forms::Button^  button7;
private: System::Windows::Forms::Button^  button9;
private: System::Windows::Forms::RadioButton^  radioButton1;
private: System::Windows::Forms::RadioButton^  radioButton3;
private: System::Windows::Forms::RadioButton^  radioButton2;
private: System::Windows::Forms::RadioButton^  radioButton6;
private: System::Windows::Forms::RadioButton^  radioButton5;
private: System::Windows::Forms::RadioButton^  radioButton4;
private: System::Windows::Forms::CheckBox^  checkBox1;
private: System::Windows::Forms::ToolStripMenuItem^  addLanguageToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  addIDSToolStripMenuItem;
private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator2;
private: System::Windows::Forms::ToolStripSeparator^  toolStripSeparator1;
private: System::Windows::Forms::Button^  button2;
private: System::Windows::Forms::ContextMenuStrip^  contextMenuStrip5;
private: System::Windows::Forms::ToolStripMenuItem^  extractToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  exstractAllToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  replacePictureToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  extractAsPNGToolStripMenuItem;
private: System::Windows::Forms::ToolStripMenuItem^  extractAllAsPNGToolStripMenuItem;


		 //private: System::Windows::Forms::Button^  button3;











	private: System::ComponentModel::IContainer^  components;


	protected: 




	protected: 





	private:
		/// <summary>
		/// ��������� ���������� ������������.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// ������������ ����� ��� ��������� ������������ - �� ���������
		/// ���������� ������� ������ ��� ������ ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^  resources = (gcnew System::ComponentModel::ComponentResourceManager(Form1::typeid));
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle4 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle5 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			System::Windows::Forms::DataGridViewCellStyle^  dataGridViewCellStyle6 = (gcnew System::Windows::Forms::DataGridViewCellStyle());
			this->statusStrip1 = (gcnew System::Windows::Forms::StatusStrip());
			this->toolStripProgressBar1 = (gcnew System::Windows::Forms::ToolStripStatusLabel());
			this->toolStripProgressBar2 = (gcnew System::Windows::Forms::ToolStripProgressBar());
			this->toolStripStatusLabel1 = (gcnew System::Windows::Forms::ToolStripStatusLabel());
			this->imageList1 = (gcnew System::Windows::Forms::ImageList(this->components));
			this->tabControl1 = (gcnew System::Windows::Forms::TabControl());
			this->tabPage2 = (gcnew System::Windows::Forms::TabPage());
			this->splitContainer8 = (gcnew System::Windows::Forms::SplitContainer());
			this->treeView6 = (gcnew System::Windows::Forms::TreeView());
			this->menuStrip1 = (gcnew System::Windows::Forms::MenuStrip());
			this->fileToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->dumpFileToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->openDumpToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->closeDumpToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripSeparator2 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->saveAsORGToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripSeparator1 = (gcnew System::Windows::Forms::ToolStripSeparator());
			this->saveFileToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->sToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->saveAsNonCompressedrc1ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripTextBox1 = (gcnew System::Windows::Forms::ToolStripTextBox());
			this->splitContainer9 = (gcnew System::Windows::Forms::SplitContainer());
			this->treeView7 = (gcnew System::Windows::Forms::TreeView());
			this->menuStrip4 = (gcnew System::Windows::Forms::MenuStrip());
			this->fileToolStripMenuItem3 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->dumpFileToolStripMenuItem3 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->openDumpToolStripMenuItem3 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->closeDumpToolStripMenuItem3 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->toolStripTextBox3 = (gcnew System::Windows::Forms::ToolStripTextBox());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->richTextBox1 = (gcnew System::Windows::Forms::RichTextBox());
			this->contextMenuStrip3 = (gcnew System::Windows::Forms::ContextMenuStrip(this->components));
			this->copyToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->cutToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->pasteToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->deleteToolStripMenuItem2 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->menuStrip5 = (gcnew System::Windows::Forms::MenuStrip());
			this->fileToolStripMenuItem4 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->saveChangesToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->tabPage1 = (gcnew System::Windows::Forms::TabPage());
			this->splitContainer2 = (gcnew System::Windows::Forms::SplitContainer());
			this->treeView2 = (gcnew System::Windows::Forms::TreeView());
			this->menuStrip2 = (gcnew System::Windows::Forms::MenuStrip());
			this->fileToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->dumpFileToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->openDumpToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->closeDumpToolStripMenuItem2 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->saveFileAsToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->debugLToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->debugLevel1ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->debugLevel2ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->imageToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->openImageToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->changeImageToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->splitContainer5 = (gcnew System::Windows::Forms::SplitContainer());
			this->pictureBox4 = (gcnew System::Windows::Forms::PictureBox());
			this->pictureBox5 = (gcnew System::Windows::Forms::PictureBox());
			this->tabPage6 = (gcnew System::Windows::Forms::TabPage());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->button11 = (gcnew System::Windows::Forms::Button());
			this->groupBox3 = (gcnew System::Windows::Forms::GroupBox());
			this->button4 = (gcnew System::Windows::Forms::Button());
			this->button15 = (gcnew System::Windows::Forms::Button());
			this->groupBox5 = (gcnew System::Windows::Forms::GroupBox());
			this->checkBox1 = (gcnew System::Windows::Forms::CheckBox());
			this->button10 = (gcnew System::Windows::Forms::Button());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->groupBox6 = (gcnew System::Windows::Forms::GroupBox());
			this->button9 = (gcnew System::Windows::Forms::Button());
			this->groupBox7 = (gcnew System::Windows::Forms::GroupBox());
			this->radioButton6 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton5 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton4 = (gcnew System::Windows::Forms::RadioButton());
			this->button6 = (gcnew System::Windows::Forms::Button());
			this->button5 = (gcnew System::Windows::Forms::Button());
			this->groupBox4 = (gcnew System::Windows::Forms::GroupBox());
			this->radioButton3 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton2 = (gcnew System::Windows::Forms::RadioButton());
			this->radioButton1 = (gcnew System::Windows::Forms::RadioButton());
			this->button8 = (gcnew System::Windows::Forms::Button());
			this->button7 = (gcnew System::Windows::Forms::Button());
			this->contextMenuStrip4 = (gcnew System::Windows::Forms::ContextMenuStrip(this->components));
			this->deleteItLanguageToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->deleteItIDSToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->addLanguageToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->addIDSToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->exportLanguageTotxtToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->importLanguageFromtxtToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->backgroundWorker1 = (gcnew System::ComponentModel::BackgroundWorker());
			this->backgroundWorker2 = (gcnew System::ComponentModel::BackgroundWorker());
			this->splitContainer3 = (gcnew System::Windows::Forms::SplitContainer());
			this->splitContainer4 = (gcnew System::Windows::Forms::SplitContainer());
			this->backgroundWorker3 = (gcnew System::ComponentModel::BackgroundWorker());
			this->contextMenuStrip1 = (gcnew System::Windows::Forms::ContextMenuStrip(this->components));
			this->deleteToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->backgroundWorker4 = (gcnew System::ComponentModel::BackgroundWorker());
			this->splitContainer10 = (gcnew System::Windows::Forms::SplitContainer());
			this->contextMenuStrip2 = (gcnew System::Windows::Forms::ContextMenuStrip(this->components));
			this->deleteToolStripMenuItem1 = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->backgroundWorker5 = (gcnew System::ComponentModel::BackgroundWorker());
			this->contextMenuStrip5 = (gcnew System::Windows::Forms::ContextMenuStrip(this->components));
			this->extractToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->exstractAllToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->replacePictureToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->extractAsPNGToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->extractAllAsPNGToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->statusStrip1->SuspendLayout();
			this->tabControl1->SuspendLayout();
			this->tabPage2->SuspendLayout();
			this->splitContainer8->Panel1->SuspendLayout();
			this->splitContainer8->Panel2->SuspendLayout();
			this->splitContainer8->SuspendLayout();
			this->menuStrip1->SuspendLayout();
			this->splitContainer9->Panel1->SuspendLayout();
			this->splitContainer9->Panel2->SuspendLayout();
			this->splitContainer9->SuspendLayout();
			this->menuStrip4->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->BeginInit();
			this->contextMenuStrip3->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->BeginInit();
			this->menuStrip5->SuspendLayout();
			this->tabPage1->SuspendLayout();
			this->splitContainer2->Panel1->SuspendLayout();
			this->splitContainer2->Panel2->SuspendLayout();
			this->splitContainer2->SuspendLayout();
			this->menuStrip2->SuspendLayout();
			this->splitContainer5->Panel1->SuspendLayout();
			this->splitContainer5->Panel2->SuspendLayout();
			this->splitContainer5->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox4))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox5))->BeginInit();
			this->tabPage6->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->groupBox1->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->groupBox5->SuspendLayout();
			this->groupBox6->SuspendLayout();
			this->groupBox7->SuspendLayout();
			this->groupBox4->SuspendLayout();
			this->contextMenuStrip4->SuspendLayout();
			this->splitContainer3->SuspendLayout();
			this->splitContainer4->SuspendLayout();
			this->contextMenuStrip1->SuspendLayout();
			this->splitContainer10->SuspendLayout();
			this->contextMenuStrip2->SuspendLayout();
			this->contextMenuStrip5->SuspendLayout();
			this->SuspendLayout();
			// 
			// statusStrip1
			// 
			this->statusStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->toolStripProgressBar1, 
				this->toolStripProgressBar2, this->toolStripStatusLabel1});
			this->statusStrip1->Location = System::Drawing::Point(0, 411);
			this->statusStrip1->Name = L"statusStrip1";
			this->statusStrip1->Size = System::Drawing::Size(978, 22);
			this->statusStrip1->TabIndex = 0;
			this->statusStrip1->Text = L"statusStrip1";
			// 
			// toolStripProgressBar1
			// 
			this->toolStripProgressBar1->Name = L"toolStripProgressBar1";
			this->toolStripProgressBar1->Size = System::Drawing::Size(0, 17);
			// 
			// toolStripProgressBar2
			// 
			this->toolStripProgressBar2->Name = L"toolStripProgressBar2";
			this->toolStripProgressBar2->Size = System::Drawing::Size(200, 16);
			this->toolStripProgressBar2->Step = 1;
			// 
			// toolStripStatusLabel1
			// 
			this->toolStripStatusLabel1->AutoSize = false;
			this->toolStripStatusLabel1->Name = L"toolStripStatusLabel1";
			this->toolStripStatusLabel1->Size = System::Drawing::Size(200, 17);
			this->toolStripStatusLabel1->TextAlign = System::Drawing::ContentAlignment::MiddleLeft;
			// 
			// imageList1
			// 
			this->imageList1->ImageStream = (cli::safe_cast<System::Windows::Forms::ImageListStreamer^  >(resources->GetObject(L"imageList1.ImageStream")));
			this->imageList1->TransparentColor = System::Drawing::Color::Transparent;
			this->imageList1->Images->SetKeyName(0, L"4_51.ico");
			this->imageList1->Images->SetKeyName(1, L"105_53.ico");
			this->imageList1->Images->SetKeyName(2, L"5_67.ico");
			this->imageList1->Images->SetKeyName(3, L"151.ico");
			this->imageList1->Images->SetKeyName(4, L"225.ico");
			this->imageList1->Images->SetKeyName(5, L"156.ico");
			this->imageList1->Images->SetKeyName(6, L"154.ico");
			this->imageList1->Images->SetKeyName(7, L"Toolbox.ico");
			// 
			// tabControl1
			// 
			this->tabControl1->Controls->Add(this->tabPage2);
			this->tabControl1->Controls->Add(this->tabPage1);
			this->tabControl1->Controls->Add(this->tabPage6);
			this->tabControl1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->tabControl1->Location = System::Drawing::Point(0, 0);
			this->tabControl1->Name = L"tabControl1";
			this->tabControl1->SelectedIndex = 0;
			this->tabControl1->Size = System::Drawing::Size(978, 411);
			this->tabControl1->TabIndex = 0;
			// 
			// tabPage2
			// 
			this->tabPage2->Controls->Add(this->splitContainer8);
			this->tabPage2->Location = System::Drawing::Point(4, 22);
			this->tabPage2->Name = L"tabPage2";
			this->tabPage2->Padding = System::Windows::Forms::Padding(3);
			this->tabPage2->Size = System::Drawing::Size(970, 385);
			this->tabPage2->TabIndex = 11;
			this->tabPage2->Text = L"FW view";
			this->tabPage2->UseVisualStyleBackColor = true;
			// 
			// splitContainer8
			// 
			this->splitContainer8->Dock = System::Windows::Forms::DockStyle::Fill;
			this->splitContainer8->Location = System::Drawing::Point(3, 3);
			this->splitContainer8->Name = L"splitContainer8";
			// 
			// splitContainer8.Panel1
			// 
			this->splitContainer8->Panel1->Controls->Add(this->treeView6);
			this->splitContainer8->Panel1->Controls->Add(this->menuStrip1);
			// 
			// splitContainer8.Panel2
			// 
			this->splitContainer8->Panel2->Controls->Add(this->splitContainer9);
			this->splitContainer8->Size = System::Drawing::Size(964, 379);
			this->splitContainer8->SplitterDistance = 297;
			this->splitContainer8->TabIndex = 0;
			// 
			// treeView6
			// 
			this->treeView6->AllowDrop = true;
			this->treeView6->Dock = System::Windows::Forms::DockStyle::Fill;
			this->treeView6->ImageIndex = 0;
			this->treeView6->ImageList = this->imageList1;
			this->treeView6->Location = System::Drawing::Point(0, 0);
			this->treeView6->Name = L"treeView6";
			this->treeView6->SelectedImageIndex = 0;
			this->treeView6->ShowNodeToolTips = true;
			this->treeView6->Size = System::Drawing::Size(297, 379);
			this->treeView6->TabIndex = 0;
			this->treeView6->NodeMouseHover += gcnew System::Windows::Forms::TreeNodeMouseHoverEventHandler(this, &Form1::treeView6_NodeMouseHover);
			this->treeView6->DragDrop += gcnew System::Windows::Forms::DragEventHandler(this, &Form1::treeView6_DragDrop);
			this->treeView6->KeyUp += gcnew System::Windows::Forms::KeyEventHandler(this, &Form1::treeView6_KeyUp);
			this->treeView6->NodeMouseClick += gcnew System::Windows::Forms::TreeNodeMouseClickEventHandler(this, &Form1::treeView6_NodeMouseClick);
			this->treeView6->DragOver += gcnew System::Windows::Forms::DragEventHandler(this, &Form1::treeView6_DragOver);
			// 
			// menuStrip1
			// 
			this->menuStrip1->BackColor = System::Drawing::SystemColors::InactiveCaptionText;
			this->menuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->fileToolStripMenuItem, 
				this->toolStripTextBox1});
			this->menuStrip1->Location = System::Drawing::Point(0, 0);
			this->menuStrip1->Name = L"menuStrip1";
			this->menuStrip1->Size = System::Drawing::Size(297, 24);
			this->menuStrip1->TabIndex = 3;
			this->menuStrip1->Text = L"menuStrip1";
			this->menuStrip1->Visible = false;
			// 
			// fileToolStripMenuItem
			// 
			this->fileToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(9) {this->dumpFileToolStripMenuItem, 
				this->openDumpToolStripMenuItem, this->closeDumpToolStripMenuItem, this->toolStripSeparator2, this->saveAsORGToolStripMenuItem, 
				this->toolStripSeparator1, this->saveFileToolStripMenuItem, this->sToolStripMenuItem, this->saveAsNonCompressedrc1ToolStripMenuItem});
			this->fileToolStripMenuItem->Name = L"fileToolStripMenuItem";
			this->fileToolStripMenuItem->Size = System::Drawing::Size(35, 20);
			this->fileToolStripMenuItem->Text = L"File";
			// 
			// dumpFileToolStripMenuItem
			// 
			this->dumpFileToolStripMenuItem->Name = L"dumpFileToolStripMenuItem";
			this->dumpFileToolStripMenuItem->Size = System::Drawing::Size(226, 22);
			this->dumpFileToolStripMenuItem->Text = L"Dump File";
			this->dumpFileToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::dumpFileToolStripMenuItem_Click);
			// 
			// openDumpToolStripMenuItem
			// 
			this->openDumpToolStripMenuItem->Name = L"openDumpToolStripMenuItem";
			this->openDumpToolStripMenuItem->Size = System::Drawing::Size(226, 22);
			this->openDumpToolStripMenuItem->Text = L"Open Dump";
			this->openDumpToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::openDumpToolStripMenuItem_Click);
			// 
			// closeDumpToolStripMenuItem
			// 
			this->closeDumpToolStripMenuItem->Name = L"closeDumpToolStripMenuItem";
			this->closeDumpToolStripMenuItem->Size = System::Drawing::Size(226, 22);
			this->closeDumpToolStripMenuItem->Text = L"Close Dump";
			this->closeDumpToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::closeDumpToolStripMenuItem_Click);
			// 
			// toolStripSeparator2
			// 
			this->toolStripSeparator2->Name = L"toolStripSeparator2";
			this->toolStripSeparator2->Size = System::Drawing::Size(223, 6);
			// 
			// saveAsORGToolStripMenuItem
			// 
			this->saveAsORGToolStripMenuItem->Name = L"saveAsORGToolStripMenuItem";
			this->saveAsORGToolStripMenuItem->Size = System::Drawing::Size(226, 22);
			this->saveAsORGToolStripMenuItem->Text = L"Save as .org";
			this->saveAsORGToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::saveAsORGToolStripMenuItem_Click);
			// 
			// toolStripSeparator1
			// 
			this->toolStripSeparator1->Name = L"toolStripSeparator1";
			this->toolStripSeparator1->Size = System::Drawing::Size(223, 6);
			// 
			// saveFileToolStripMenuItem
			// 
			this->saveFileToolStripMenuItem->Name = L"saveFileToolStripMenuItem";
			this->saveFileToolStripMenuItem->Size = System::Drawing::Size(226, 22);
			this->saveFileToolStripMenuItem->Text = L"Save as .app, .pfs, .ffs";
			this->saveFileToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::saveFileToolStripMenuItem_Click);
			// 
			// sToolStripMenuItem
			// 
			this->sToolStripMenuItem->Name = L"sToolStripMenuItem";
			this->sToolStripMenuItem->Size = System::Drawing::Size(226, 22);
			this->sToolStripMenuItem->Text = L"Save as non compressed .csc";
			this->sToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::sToolStripMenuItem_Click);
			// 
			// saveAsNonCompressedrc1ToolStripMenuItem
			// 
			this->saveAsNonCompressedrc1ToolStripMenuItem->Name = L"saveAsNonCompressedrc1ToolStripMenuItem";
			this->saveAsNonCompressedrc1ToolStripMenuItem->Size = System::Drawing::Size(226, 22);
			this->saveAsNonCompressedrc1ToolStripMenuItem->Text = L"Save as non compressed .rc1";
			this->saveAsNonCompressedrc1ToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::saveAsNonCompressedrc1ToolStripMenuItem_Click);
			// 
			// toolStripTextBox1
			// 
			this->toolStripTextBox1->BackColor = System::Drawing::SystemColors::InactiveCaptionText;
			this->toolStripTextBox1->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->toolStripTextBox1->Font = (gcnew System::Drawing::Font(L"Tahoma", 10, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic))));
			this->toolStripTextBox1->Name = L"toolStripTextBox1";
			this->toolStripTextBox1->ReadOnly = true;
			this->toolStripTextBox1->Size = System::Drawing::Size(200, 20);
			this->toolStripTextBox1->Text = L"Any FW files Drag and Drop";
			// 
			// splitContainer9
			// 
			this->splitContainer9->Dock = System::Windows::Forms::DockStyle::Fill;
			this->splitContainer9->Location = System::Drawing::Point(0, 0);
			this->splitContainer9->Name = L"splitContainer9";
			// 
			// splitContainer9.Panel1
			// 
			this->splitContainer9->Panel1->Controls->Add(this->treeView7);
			this->splitContainer9->Panel1->Controls->Add(this->menuStrip4);
			// 
			// splitContainer9.Panel2
			// 
			this->splitContainer9->Panel2->Controls->Add(this->dataGridView1);
			this->splitContainer9->Panel2->Controls->Add(this->richTextBox1);
			this->splitContainer9->Panel2->Controls->Add(this->pictureBox1);
			this->splitContainer9->Panel2->Controls->Add(this->menuStrip5);
			this->splitContainer9->Size = System::Drawing::Size(663, 379);
			this->splitContainer9->SplitterDistance = 315;
			this->splitContainer9->TabIndex = 0;
			// 
			// treeView7
			// 
			this->treeView7->AllowDrop = true;
			this->treeView7->Dock = System::Windows::Forms::DockStyle::Fill;
			this->treeView7->ImageIndex = 0;
			this->treeView7->ImageList = this->imageList1;
			this->treeView7->Location = System::Drawing::Point(0, 0);
			this->treeView7->Name = L"treeView7";
			this->treeView7->SelectedImageIndex = 0;
			this->treeView7->ShowNodeToolTips = true;
			this->treeView7->Size = System::Drawing::Size(315, 379);
			this->treeView7->TabIndex = 0;
			this->treeView7->QueryContinueDrag += gcnew System::Windows::Forms::QueryContinueDragEventHandler(this, &Form1::treeView7_QueryContinueDrag);
			this->treeView7->NodeMouseHover += gcnew System::Windows::Forms::TreeNodeMouseHoverEventHandler(this, &Form1::treeView7_NodeMouseHover);
			this->treeView7->DragDrop += gcnew System::Windows::Forms::DragEventHandler(this, &Form1::treeView7_DragDrop);
			this->treeView7->KeyUp += gcnew System::Windows::Forms::KeyEventHandler(this, &Form1::treeView7_KeyUp);
			this->treeView7->NodeMouseClick += gcnew System::Windows::Forms::TreeNodeMouseClickEventHandler(this, &Form1::treeView7_NodeMouseClick);
			this->treeView7->ItemDrag += gcnew System::Windows::Forms::ItemDragEventHandler(this, &Form1::treeView7_ItemDrag);
			this->treeView7->DragOver += gcnew System::Windows::Forms::DragEventHandler(this, &Form1::treeView7_DragOver);
			// 
			// menuStrip4
			// 
			this->menuStrip4->BackColor = System::Drawing::SystemColors::InactiveCaptionText;
			this->menuStrip4->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->fileToolStripMenuItem3, 
				this->toolStripTextBox3});
			this->menuStrip4->Location = System::Drawing::Point(0, 0);
			this->menuStrip4->Name = L"menuStrip4";
			this->menuStrip4->Size = System::Drawing::Size(315, 24);
			this->menuStrip4->TabIndex = 3;
			this->menuStrip4->Text = L"menuStrip4";
			this->menuStrip4->Visible = false;
			// 
			// fileToolStripMenuItem3
			// 
			this->fileToolStripMenuItem3->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->dumpFileToolStripMenuItem3, 
				this->openDumpToolStripMenuItem3, this->closeDumpToolStripMenuItem3});
			this->fileToolStripMenuItem3->Name = L"fileToolStripMenuItem3";
			this->fileToolStripMenuItem3->Size = System::Drawing::Size(35, 20);
			this->fileToolStripMenuItem3->Text = L"File";
			// 
			// dumpFileToolStripMenuItem3
			// 
			this->dumpFileToolStripMenuItem3->Enabled = false;
			this->dumpFileToolStripMenuItem3->Name = L"dumpFileToolStripMenuItem3";
			this->dumpFileToolStripMenuItem3->Size = System::Drawing::Size(141, 22);
			this->dumpFileToolStripMenuItem3->Text = L"Dump File";
			// 
			// openDumpToolStripMenuItem3
			// 
			this->openDumpToolStripMenuItem3->Enabled = false;
			this->openDumpToolStripMenuItem3->Name = L"openDumpToolStripMenuItem3";
			this->openDumpToolStripMenuItem3->Size = System::Drawing::Size(141, 22);
			this->openDumpToolStripMenuItem3->Text = L"Open Dump";
			// 
			// closeDumpToolStripMenuItem3
			// 
			this->closeDumpToolStripMenuItem3->Enabled = false;
			this->closeDumpToolStripMenuItem3->Name = L"closeDumpToolStripMenuItem3";
			this->closeDumpToolStripMenuItem3->Size = System::Drawing::Size(141, 22);
			this->closeDumpToolStripMenuItem3->Text = L"Close Dump";
			// 
			// toolStripTextBox3
			// 
			this->toolStripTextBox3->BackColor = System::Drawing::SystemColors::InactiveCaptionText;
			this->toolStripTextBox3->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->toolStripTextBox3->Font = (gcnew System::Drawing::Font(L"Tahoma", 10, static_cast<System::Drawing::FontStyle>((System::Drawing::FontStyle::Bold | System::Drawing::FontStyle::Italic))));
			this->toolStripTextBox3->Name = L"toolStripTextBox3";
			this->toolStripTextBox3->Size = System::Drawing::Size(200, 20);
			this->toolStripTextBox3->Text = L"Any FW files Drag and Drop";
			// 
			// dataGridView1
			// 
			this->dataGridView1->AllowUserToAddRows = false;
			this->dataGridView1->AllowUserToResizeRows = false;
			this->dataGridView1->BackgroundColor = System::Drawing::SystemColors::ActiveCaptionText;
			this->dataGridView1->ClipboardCopyMode = System::Windows::Forms::DataGridViewClipboardCopyMode::Disable;
			dataGridViewCellStyle4->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleCenter;
			dataGridViewCellStyle4->BackColor = System::Drawing::SystemColors::Control;
			dataGridViewCellStyle4->Font = (gcnew System::Drawing::Font(L"Arial Unicode MS", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			dataGridViewCellStyle4->ForeColor = System::Drawing::SystemColors::WindowText;
			dataGridViewCellStyle4->SelectionBackColor = System::Drawing::SystemColors::Highlight;
			dataGridViewCellStyle4->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
			dataGridViewCellStyle4->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
			this->dataGridView1->ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			dataGridViewCellStyle5->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle5->BackColor = System::Drawing::SystemColors::Window;
			dataGridViewCellStyle5->Font = (gcnew System::Drawing::Font(L"Arial Unicode MS", 8.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			dataGridViewCellStyle5->ForeColor = System::Drawing::SystemColors::ControlText;
			dataGridViewCellStyle5->SelectionBackColor = System::Drawing::SystemColors::Highlight;
			dataGridViewCellStyle5->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
			dataGridViewCellStyle5->WrapMode = System::Windows::Forms::DataGridViewTriState::False;
			this->dataGridView1->DefaultCellStyle = dataGridViewCellStyle5;
			this->dataGridView1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->dataGridView1->EditMode = System::Windows::Forms::DataGridViewEditMode::EditProgrammatically;
			this->dataGridView1->Location = System::Drawing::Point(0, 24);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->RowHeadersBorderStyle = System::Windows::Forms::DataGridViewHeaderBorderStyle::Sunken;
			dataGridViewCellStyle6->Alignment = System::Windows::Forms::DataGridViewContentAlignment::MiddleLeft;
			dataGridViewCellStyle6->BackColor = System::Drawing::SystemColors::Control;
			dataGridViewCellStyle6->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 8.25F, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			dataGridViewCellStyle6->ForeColor = System::Drawing::SystemColors::WindowText;
			dataGridViewCellStyle6->SelectionBackColor = System::Drawing::SystemColors::Highlight;
			dataGridViewCellStyle6->SelectionForeColor = System::Drawing::SystemColors::HighlightText;
			dataGridViewCellStyle6->WrapMode = System::Windows::Forms::DataGridViewTriState::True;
			this->dataGridView1->RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
			this->dataGridView1->RowHeadersWidth = 60;
			this->dataGridView1->SelectionMode = System::Windows::Forms::DataGridViewSelectionMode::CellSelect;
			this->dataGridView1->Size = System::Drawing::Size(344, 355);
			this->dataGridView1->TabIndex = 7;
			this->dataGridView1->Visible = false;
			this->dataGridView1->CellDoubleClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &Form1::dataGridView1_CellDoubleClick);
			this->dataGridView1->CellMouseDown += gcnew System::Windows::Forms::DataGridViewCellMouseEventHandler(this, &Form1::dataGridView1_CellMouseDown);
			this->dataGridView1->VisibleChanged += gcnew System::EventHandler(this, &Form1::dataGridView1_VisibleChanged);
			// 
			// richTextBox1
			// 
			this->richTextBox1->ContextMenuStrip = this->contextMenuStrip3;
			this->richTextBox1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->richTextBox1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 9.75F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point, 
				static_cast<System::Byte>(204)));
			this->richTextBox1->Location = System::Drawing::Point(0, 24);
			this->richTextBox1->Name = L"richTextBox1";
			this->richTextBox1->Size = System::Drawing::Size(344, 355);
			this->richTextBox1->TabIndex = 6;
			this->richTextBox1->Text = L"";
			this->richTextBox1->Visible = false;
			this->richTextBox1->VisibleChanged += gcnew System::EventHandler(this, &Form1::richTextBox1_VisibleChanged);
			// 
			// contextMenuStrip3
			// 
			this->contextMenuStrip3->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {this->copyToolStripMenuItem, 
				this->cutToolStripMenuItem, this->pasteToolStripMenuItem, this->deleteToolStripMenuItem2});
			this->contextMenuStrip3->Name = L"contextMenuStrip3";
			this->contextMenuStrip3->Size = System::Drawing::Size(117, 92);
			this->contextMenuStrip3->Opening += gcnew System::ComponentModel::CancelEventHandler(this, &Form1::contextMenuStrip3_Opening);
			// 
			// copyToolStripMenuItem
			// 
			this->copyToolStripMenuItem->Enabled = false;
			this->copyToolStripMenuItem->Name = L"copyToolStripMenuItem";
			this->copyToolStripMenuItem->Size = System::Drawing::Size(116, 22);
			this->copyToolStripMenuItem->Text = L"Copy";
			this->copyToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::copyToolStripMenuItem_Click);
			// 
			// cutToolStripMenuItem
			// 
			this->cutToolStripMenuItem->Enabled = false;
			this->cutToolStripMenuItem->Name = L"cutToolStripMenuItem";
			this->cutToolStripMenuItem->Size = System::Drawing::Size(116, 22);
			this->cutToolStripMenuItem->Text = L"Cut";
			this->cutToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::cutToolStripMenuItem_Click);
			// 
			// pasteToolStripMenuItem
			// 
			this->pasteToolStripMenuItem->Enabled = false;
			this->pasteToolStripMenuItem->Name = L"pasteToolStripMenuItem";
			this->pasteToolStripMenuItem->Size = System::Drawing::Size(116, 22);
			this->pasteToolStripMenuItem->Text = L"Paste";
			this->pasteToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::pasteToolStripMenuItem_Click);
			// 
			// deleteToolStripMenuItem2
			// 
			this->deleteToolStripMenuItem2->Enabled = false;
			this->deleteToolStripMenuItem2->Name = L"deleteToolStripMenuItem2";
			this->deleteToolStripMenuItem2->Size = System::Drawing::Size(116, 22);
			this->deleteToolStripMenuItem2->Text = L"Delete";
			this->deleteToolStripMenuItem2->Click += gcnew System::EventHandler(this, &Form1::deleteToolStripMenuItem2_Click);
			// 
			// pictureBox1
			// 
			this->pictureBox1->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->pictureBox1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->pictureBox1->Location = System::Drawing::Point(0, 24);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(344, 355);
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox1->TabIndex = 5;
			this->pictureBox1->TabStop = false;
			this->pictureBox1->Visible = false;
			this->pictureBox1->VisibleChanged += gcnew System::EventHandler(this, &Form1::pictureBox1_VisibleChanged);
			// 
			// menuStrip5
			// 
			this->menuStrip5->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->fileToolStripMenuItem4});
			this->menuStrip5->Location = System::Drawing::Point(0, 0);
			this->menuStrip5->Name = L"menuStrip5";
			this->menuStrip5->Size = System::Drawing::Size(344, 24);
			this->menuStrip5->TabIndex = 4;
			this->menuStrip5->Text = L"menuStrip5";
			// 
			// fileToolStripMenuItem4
			// 
			this->fileToolStripMenuItem4->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->saveChangesToolStripMenuItem});
			this->fileToolStripMenuItem4->Name = L"fileToolStripMenuItem4";
			this->fileToolStripMenuItem4->Size = System::Drawing::Size(35, 20);
			this->fileToolStripMenuItem4->Text = L"File";
			// 
			// saveChangesToolStripMenuItem
			// 
			this->saveChangesToolStripMenuItem->Name = L"saveChangesToolStripMenuItem";
			this->saveChangesToolStripMenuItem->Size = System::Drawing::Size(78, 22);
			this->saveChangesToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::saveChangesToolStripMenuItem_Click);
			// 
			// tabPage1
			// 
			this->tabPage1->Controls->Add(this->splitContainer2);
			this->tabPage1->Location = System::Drawing::Point(4, 22);
			this->tabPage1->Name = L"tabPage1";
			this->tabPage1->Padding = System::Windows::Forms::Padding(3);
			this->tabPage1->Size = System::Drawing::Size(970, 385);
			this->tabPage1->TabIndex = 3;
			this->tabPage1->Text = L".Rc2 view";
			this->tabPage1->UseVisualStyleBackColor = true;
			// 
			// splitContainer2
			// 
			this->splitContainer2->Dock = System::Windows::Forms::DockStyle::Fill;
			this->splitContainer2->Location = System::Drawing::Point(3, 3);
			this->splitContainer2->Name = L"splitContainer2";
			// 
			// splitContainer2.Panel1
			// 
			this->splitContainer2->Panel1->Controls->Add(this->treeView2);
			this->splitContainer2->Panel1->Controls->Add(this->menuStrip2);
			// 
			// splitContainer2.Panel2
			// 
			this->splitContainer2->Panel2->Controls->Add(this->splitContainer5);
			this->splitContainer2->Size = System::Drawing::Size(964, 379);
			this->splitContainer2->SplitterDistance = 279;
			this->splitContainer2->TabIndex = 0;
			// 
			// treeView2
			// 
			this->treeView2->AllowDrop = true;
			this->treeView2->Dock = System::Windows::Forms::DockStyle::Fill;
			this->treeView2->ImageIndex = 0;
			this->treeView2->ImageList = this->imageList1;
			this->treeView2->Location = System::Drawing::Point(0, 0);
			this->treeView2->Name = L"treeView2";
			this->treeView2->SelectedImageIndex = 0;
			this->treeView2->Size = System::Drawing::Size(279, 379);
			this->treeView2->TabIndex = 0;
			this->treeView2->DragDrop += gcnew System::Windows::Forms::DragEventHandler(this, &Form1::treeView2_DragDrop);
			this->treeView2->NodeMouseClick += gcnew System::Windows::Forms::TreeNodeMouseClickEventHandler(this, &Form1::treeView2_NodeMouseClick);
			this->treeView2->DragOver += gcnew System::Windows::Forms::DragEventHandler(this, &Form1::treeView2_DragOver);
			// 
			// menuStrip2
			// 
			this->menuStrip2->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->fileToolStripMenuItem1, 
				this->imageToolStripMenuItem});
			this->menuStrip2->Location = System::Drawing::Point(0, 0);
			this->menuStrip2->Name = L"menuStrip2";
			this->menuStrip2->Size = System::Drawing::Size(279, 24);
			this->menuStrip2->TabIndex = 1;
			this->menuStrip2->Text = L"menuStrip2";
			this->menuStrip2->Visible = false;
			// 
			// fileToolStripMenuItem1
			// 
			this->fileToolStripMenuItem1->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {this->dumpFileToolStripMenuItem1, 
				this->openDumpToolStripMenuItem1, this->closeDumpToolStripMenuItem2, this->saveFileAsToolStripMenuItem});
			this->fileToolStripMenuItem1->Name = L"fileToolStripMenuItem1";
			this->fileToolStripMenuItem1->Size = System::Drawing::Size(35, 20);
			this->fileToolStripMenuItem1->Text = L"File";
			// 
			// dumpFileToolStripMenuItem1
			// 
			this->dumpFileToolStripMenuItem1->Name = L"dumpFileToolStripMenuItem1";
			this->dumpFileToolStripMenuItem1->Size = System::Drawing::Size(142, 22);
			this->dumpFileToolStripMenuItem1->Text = L"Dump File";
			this->dumpFileToolStripMenuItem1->Click += gcnew System::EventHandler(this, &Form1::dumpFileRc2ToolStripMenuItem1_Click);
			// 
			// openDumpToolStripMenuItem1
			// 
			this->openDumpToolStripMenuItem1->Name = L"openDumpToolStripMenuItem1";
			this->openDumpToolStripMenuItem1->Size = System::Drawing::Size(142, 22);
			this->openDumpToolStripMenuItem1->Text = L"Open Dump";
			this->openDumpToolStripMenuItem1->Click += gcnew System::EventHandler(this, &Form1::openDumpRc2ToolStripMenuItem1_Click);
			// 
			// closeDumpToolStripMenuItem2
			// 
			this->closeDumpToolStripMenuItem2->Name = L"closeDumpToolStripMenuItem2";
			this->closeDumpToolStripMenuItem2->Size = System::Drawing::Size(142, 22);
			this->closeDumpToolStripMenuItem2->Text = L"Close Dump";
			this->closeDumpToolStripMenuItem2->Click += gcnew System::EventHandler(this, &Form1::closeDumpRc2ToolStripMenuItem2_Click);
			// 
			// saveFileAsToolStripMenuItem
			// 
			this->saveFileAsToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(3) {this->debugLToolStripMenuItem, 
				this->debugLevel1ToolStripMenuItem, this->debugLevel2ToolStripMenuItem});
			this->saveFileAsToolStripMenuItem->Name = L"saveFileAsToolStripMenuItem";
			this->saveFileAsToolStripMenuItem->Size = System::Drawing::Size(142, 22);
			this->saveFileAsToolStripMenuItem->Text = L"Save File as";
			// 
			// debugLToolStripMenuItem
			// 
			this->debugLToolStripMenuItem->Name = L"debugLToolStripMenuItem";
			this->debugLToolStripMenuItem->Size = System::Drawing::Size(164, 22);
			this->debugLToolStripMenuItem->Text = L"Debug Level = 0";
			this->debugLToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::debugLToolStripMenuItem_Click);
			// 
			// debugLevel1ToolStripMenuItem
			// 
			this->debugLevel1ToolStripMenuItem->Name = L"debugLevel1ToolStripMenuItem";
			this->debugLevel1ToolStripMenuItem->Size = System::Drawing::Size(164, 22);
			this->debugLevel1ToolStripMenuItem->Text = L"Debug Level = 1";
			this->debugLevel1ToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::debugLevel1ToolStripMenuItem_Click);
			// 
			// debugLevel2ToolStripMenuItem
			// 
			this->debugLevel2ToolStripMenuItem->Name = L"debugLevel2ToolStripMenuItem";
			this->debugLevel2ToolStripMenuItem->Size = System::Drawing::Size(164, 22);
			this->debugLevel2ToolStripMenuItem->Text = L"DebugLevel = 2";
			this->debugLevel2ToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::debugLevel2ToolStripMenuItem_Click);
			// 
			// imageToolStripMenuItem
			// 
			this->imageToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(2) {this->openImageToolStripMenuItem, 
				this->changeImageToolStripMenuItem});
			this->imageToolStripMenuItem->Name = L"imageToolStripMenuItem";
			this->imageToolStripMenuItem->Size = System::Drawing::Size(49, 20);
			this->imageToolStripMenuItem->Text = L"Image";
			// 
			// openImageToolStripMenuItem
			// 
			this->openImageToolStripMenuItem->Name = L"openImageToolStripMenuItem";
			this->openImageToolStripMenuItem->Size = System::Drawing::Size(155, 22);
			this->openImageToolStripMenuItem->Text = L"Open Image";
			this->openImageToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::openImageToolStripMenuItem_Click_1);
			// 
			// changeImageToolStripMenuItem
			// 
			this->changeImageToolStripMenuItem->Name = L"changeImageToolStripMenuItem";
			this->changeImageToolStripMenuItem->Size = System::Drawing::Size(155, 22);
			this->changeImageToolStripMenuItem->Text = L"Change Image";
			this->changeImageToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::changeImageToolStripMenuItem_Click);
			// 
			// splitContainer5
			// 
			this->splitContainer5->Dock = System::Windows::Forms::DockStyle::Fill;
			this->splitContainer5->Location = System::Drawing::Point(0, 0);
			this->splitContainer5->Name = L"splitContainer5";
			// 
			// splitContainer5.Panel1
			// 
			this->splitContainer5->Panel1->Controls->Add(this->pictureBox4);
			// 
			// splitContainer5.Panel2
			// 
			this->splitContainer5->Panel2->Controls->Add(this->pictureBox5);
			this->splitContainer5->Size = System::Drawing::Size(681, 379);
			this->splitContainer5->SplitterDistance = 334;
			this->splitContainer5->TabIndex = 0;
			// 
			// pictureBox4
			// 
			this->pictureBox4->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->pictureBox4->Dock = System::Windows::Forms::DockStyle::Fill;
			this->pictureBox4->Location = System::Drawing::Point(0, 0);
			this->pictureBox4->Name = L"pictureBox4";
			this->pictureBox4->Size = System::Drawing::Size(334, 379);
			this->pictureBox4->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox4->TabIndex = 0;
			this->pictureBox4->TabStop = false;
			// 
			// pictureBox5
			// 
			this->pictureBox5->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->pictureBox5->Dock = System::Windows::Forms::DockStyle::Fill;
			this->pictureBox5->Location = System::Drawing::Point(0, 0);
			this->pictureBox5->Name = L"pictureBox5";
			this->pictureBox5->Size = System::Drawing::Size(343, 379);
			this->pictureBox5->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			this->pictureBox5->TabIndex = 1;
			this->pictureBox5->TabStop = false;
			// 
			// tabPage6
			// 
			this->tabPage6->Controls->Add(this->button2);
			this->tabPage6->Controls->Add(this->groupBox2);
			this->tabPage6->Controls->Add(this->groupBox6);
			this->tabPage6->Location = System::Drawing::Point(4, 22);
			this->tabPage6->Name = L"tabPage6";
			this->tabPage6->Padding = System::Windows::Forms::Padding(3);
			this->tabPage6->Size = System::Drawing::Size(970, 385);
			this->tabPage6->TabIndex = 10;
			this->tabPage6->Text = L"Utils";
			this->tabPage6->UseVisualStyleBackColor = true;
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(643, 326);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(94, 29);
			this->button2->TabIndex = 12;
			this->button2->Text = L"QMG view";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Form1::button2_Click);
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->groupBox1);
			this->groupBox2->Controls->Add(this->groupBox3);
			this->groupBox2->Controls->Add(this->groupBox5);
			this->groupBox2->Location = System::Drawing::Point(8, 6);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(383, 373);
			this->groupBox2->TabIndex = 10;
			this->groupBox2->TabStop = false;
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->button11);
			this->groupBox1->Location = System::Drawing::Point(11, 266);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(360, 98);
			this->groupBox1->TabIndex = 6;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"Sign";
			// 
			// button11
			// 
			this->button11->Location = System::Drawing::Point(20, 54);
			this->button11->Name = L"button11";
			this->button11->Size = System::Drawing::Size(318, 29);
			this->button11->TabIndex = 0;
			this->button11->Text = L"Sign file";
			this->button11->UseVisualStyleBackColor = true;
			this->button11->Click += gcnew System::EventHandler(this, &Form1::button11_Click);
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->button4);
			this->groupBox3->Controls->Add(this->button15);
			this->groupBox3->Location = System::Drawing::Point(11, 113);
			this->groupBox3->Name = L"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(360, 147);
			this->groupBox3->TabIndex = 6;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = L"Decompress";
			// 
			// button4
			// 
			this->button4->Anchor = static_cast<System::Windows::Forms::AnchorStyles>((System::Windows::Forms::AnchorStyles::Bottom | System::Windows::Forms::AnchorStyles::Left));
			this->button4->Location = System::Drawing::Point(20, 84);
			this->button4->Name = L"button4";
			this->button4->Size = System::Drawing::Size(142, 30);
			this->button4->TabIndex = 13;
			this->button4->Text = L"Decrypt and Decompress";
			this->button4->UseVisualStyleBackColor = true;
			this->button4->Click += gcnew System::EventHandler(this, &Form1::button4_Click_1);
			// 
			// button15
			// 
			this->button15->Location = System::Drawing::Point(196, 84);
			this->button15->Name = L"button15";
			this->button15->Size = System::Drawing::Size(142, 30);
			this->button15->TabIndex = 12;
			this->button15->Text = L"Decompress";
			this->button15->UseVisualStyleBackColor = true;
			this->button15->Click += gcnew System::EventHandler(this, &Form1::button15_Click);
			// 
			// groupBox5
			// 
			this->groupBox5->Controls->Add(this->checkBox1);
			this->groupBox5->Controls->Add(this->button10);
			this->groupBox5->Controls->Add(this->button1);
			this->groupBox5->Location = System::Drawing::Point(11, 19);
			this->groupBox5->Name = L"groupBox5";
			this->groupBox5->Size = System::Drawing::Size(360, 88);
			this->groupBox5->TabIndex = 5;
			this->groupBox5->TabStop = false;
			this->groupBox5->Text = L"Crypt";
			// 
			// checkBox1
			// 
			this->checkBox1->AutoSize = true;
			this->checkBox1->Location = System::Drawing::Point(143, 59);
			this->checkBox1->Name = L"checkBox1";
			this->checkBox1->Size = System::Drawing::Size(79, 17);
			this->checkBox1->TabIndex = 4;
			this->checkBox1->Text = L"For Wave3";
			this->checkBox1->UseVisualStyleBackColor = true;
			// 
			// button10
			// 
			this->button10->Location = System::Drawing::Point(196, 19);
			this->button10->Name = L"button10";
			this->button10->Size = System::Drawing::Size(142, 30);
			this->button10->TabIndex = 3;
			this->button10->Text = L"Encrypt";
			this->button10->UseVisualStyleBackColor = true;
			this->button10->Click += gcnew System::EventHandler(this, &Form1::button10_Click);
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(20, 19);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(142, 30);
			this->button1->TabIndex = 0;
			this->button1->Text = L"Decrypt";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Form1::button1_Click);
			// 
			// groupBox6
			// 
			this->groupBox6->Controls->Add(this->button9);
			this->groupBox6->Controls->Add(this->groupBox7);
			this->groupBox6->Controls->Add(this->groupBox4);
			this->groupBox6->Location = System::Drawing::Point(397, 6);
			this->groupBox6->Name = L"groupBox6";
			this->groupBox6->Size = System::Drawing::Size(186, 373);
			this->groupBox6->TabIndex = 11;
			this->groupBox6->TabStop = false;
			// 
			// button9
			// 
			this->button9->Location = System::Drawing::Point(31, 320);
			this->button9->Name = L"button9";
			this->button9->Size = System::Drawing::Size(119, 30);
			this->button9->TabIndex = 14;
			this->button9->Text = L"Play .img";
			this->button9->UseVisualStyleBackColor = true;
			this->button9->Click += gcnew System::EventHandler(this, &Form1::button9_Click);
			// 
			// groupBox7
			// 
			this->groupBox7->Controls->Add(this->radioButton6);
			this->groupBox7->Controls->Add(this->radioButton5);
			this->groupBox7->Controls->Add(this->radioButton4);
			this->groupBox7->Controls->Add(this->button6);
			this->groupBox7->Controls->Add(this->button5);
			this->groupBox7->Location = System::Drawing::Point(16, 165);
			this->groupBox7->Name = L"groupBox7";
			this->groupBox7->Size = System::Drawing::Size(153, 140);
			this->groupBox7->TabIndex = 13;
			this->groupBox7->TabStop = false;
			this->groupBox7->Text = L".img Encode";
			// 
			// radioButton6
			// 
			this->radioButton6->AutoSize = true;
			this->radioButton6->CheckAlign = System::Drawing::ContentAlignment::TopCenter;
			this->radioButton6->Location = System::Drawing::Point(107, 106);
			this->radioButton6->Name = L"radioButton6";
			this->radioButton6->Size = System::Drawing::Size(25, 30);
			this->radioButton6->TabIndex = 15;
			this->radioButton6->TabStop = true;
			this->radioButton6->Text = L"jpg";
			this->radioButton6->UseVisualStyleBackColor = true;
			// 
			// radioButton5
			// 
			this->radioButton5->AutoSize = true;
			this->radioButton5->CheckAlign = System::Drawing::ContentAlignment::TopCenter;
			this->radioButton5->Location = System::Drawing::Point(62, 106);
			this->radioButton5->Name = L"radioButton5";
			this->radioButton5->Size = System::Drawing::Size(29, 30);
			this->radioButton5->TabIndex = 14;
			this->radioButton5->TabStop = true;
			this->radioButton5->Text = L"png";
			this->radioButton5->UseVisualStyleBackColor = true;
			// 
			// radioButton4
			// 
			this->radioButton4->AutoSize = true;
			this->radioButton4->CheckAlign = System::Drawing::ContentAlignment::TopCenter;
			this->radioButton4->Checked = true;
			this->radioButton4->Location = System::Drawing::Point(15, 106);
			this->radioButton4->Name = L"radioButton4";
			this->radioButton4->Size = System::Drawing::Size(31, 30);
			this->radioButton4->TabIndex = 13;
			this->radioButton4->TabStop = true;
			this->radioButton4->Text = L"bmp";
			this->radioButton4->UseVisualStyleBackColor = true;
			// 
			// button6
			// 
			this->button6->Location = System::Drawing::Point(15, 71);
			this->button6->Name = L"button6";
			this->button6->Size = System::Drawing::Size(119, 30);
			this->button6->TabIndex = 12;
			this->button6->Text = L"Folder Encode";
			this->button6->UseVisualStyleBackColor = true;
			this->button6->Click += gcnew System::EventHandler(this, &Form1::button6_Click);
			// 
			// button5
			// 
			this->button5->Location = System::Drawing::Point(15, 32);
			this->button5->Name = L"button5";
			this->button5->Size = System::Drawing::Size(119, 30);
			this->button5->TabIndex = 11;
			this->button5->Text = L"File Encode";
			this->button5->UseVisualStyleBackColor = true;
			this->button5->Click += gcnew System::EventHandler(this, &Form1::button5_Click_1);
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->radioButton3);
			this->groupBox4->Controls->Add(this->radioButton2);
			this->groupBox4->Controls->Add(this->radioButton1);
			this->groupBox4->Controls->Add(this->button8);
			this->groupBox4->Controls->Add(this->button7);
			this->groupBox4->Location = System::Drawing::Point(16, 19);
			this->groupBox4->Name = L"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(153, 140);
			this->groupBox4->TabIndex = 12;
			this->groupBox4->TabStop = false;
			this->groupBox4->Text = L".img Decode";
			// 
			// radioButton3
			// 
			this->radioButton3->AutoSize = true;
			this->radioButton3->CheckAlign = System::Drawing::ContentAlignment::TopCenter;
			this->radioButton3->Location = System::Drawing::Point(107, 104);
			this->radioButton3->Name = L"radioButton3";
			this->radioButton3->Size = System::Drawing::Size(25, 30);
			this->radioButton3->TabIndex = 4;
			this->radioButton3->TabStop = true;
			this->radioButton3->Text = L"jpg";
			this->radioButton3->UseVisualStyleBackColor = true;
			// 
			// radioButton2
			// 
			this->radioButton2->AutoSize = true;
			this->radioButton2->CheckAlign = System::Drawing::ContentAlignment::TopCenter;
			this->radioButton2->Location = System::Drawing::Point(62, 104);
			this->radioButton2->Name = L"radioButton2";
			this->radioButton2->Size = System::Drawing::Size(29, 30);
			this->radioButton2->TabIndex = 3;
			this->radioButton2->TabStop = true;
			this->radioButton2->Text = L"png";
			this->radioButton2->UseVisualStyleBackColor = true;
			// 
			// radioButton1
			// 
			this->radioButton1->AutoSize = true;
			this->radioButton1->CheckAlign = System::Drawing::ContentAlignment::TopCenter;
			this->radioButton1->Checked = true;
			this->radioButton1->Location = System::Drawing::Point(13, 104);
			this->radioButton1->Name = L"radioButton1";
			this->radioButton1->Size = System::Drawing::Size(31, 30);
			this->radioButton1->TabIndex = 2;
			this->radioButton1->TabStop = true;
			this->radioButton1->Text = L"bmp";
			this->radioButton1->UseVisualStyleBackColor = true;
			// 
			// button8
			// 
			this->button8->Location = System::Drawing::Point(15, 69);
			this->button8->Name = L"button8";
			this->button8->Size = System::Drawing::Size(119, 30);
			this->button8->TabIndex = 1;
			this->button8->Text = L"Folder Decode";
			this->button8->UseVisualStyleBackColor = true;
			this->button8->Click += gcnew System::EventHandler(this, &Form1::button8_Click);
			// 
			// button7
			// 
			this->button7->Location = System::Drawing::Point(15, 31);
			this->button7->Name = L"button7";
			this->button7->Size = System::Drawing::Size(119, 30);
			this->button7->TabIndex = 0;
			this->button7->Text = L"File Decode";
			this->button7->UseVisualStyleBackColor = true;
			this->button7->Click += gcnew System::EventHandler(this, &Form1::button7_Click);
			// 
			// contextMenuStrip4
			// 
			this->contextMenuStrip4->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(6) {this->deleteItLanguageToolStripMenuItem, 
				this->deleteItIDSToolStripMenuItem, this->addLanguageToolStripMenuItem, this->addIDSToolStripMenuItem, this->exportLanguageTotxtToolStripMenuItem, 
				this->importLanguageFromtxtToolStripMenuItem});
			this->contextMenuStrip4->Name = L"contextMenuStrip4";
			this->contextMenuStrip4->Size = System::Drawing::Size(214, 136);
			// 
			// deleteItLanguageToolStripMenuItem
			// 
			this->deleteItLanguageToolStripMenuItem->Name = L"deleteItLanguageToolStripMenuItem";
			this->deleteItLanguageToolStripMenuItem->Size = System::Drawing::Size(213, 22);
			this->deleteItLanguageToolStripMenuItem->Text = L"Delete It Language";
			this->deleteItLanguageToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::deleteItLanguageToolStripMenuItem_Click);
			// 
			// deleteItIDSToolStripMenuItem
			// 
			this->deleteItIDSToolStripMenuItem->Name = L"deleteItIDSToolStripMenuItem";
			this->deleteItIDSToolStripMenuItem->Size = System::Drawing::Size(213, 22);
			this->deleteItIDSToolStripMenuItem->Text = L"Delete It IDS";
			this->deleteItIDSToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::deleteItIDSToolStripMenuItem_Click);
			// 
			// addLanguageToolStripMenuItem
			// 
			this->addLanguageToolStripMenuItem->Name = L"addLanguageToolStripMenuItem";
			this->addLanguageToolStripMenuItem->Size = System::Drawing::Size(213, 22);
			this->addLanguageToolStripMenuItem->Text = L"Add Language";
			this->addLanguageToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::addLanguageToolStripMenuItem_Click);
			// 
			// addIDSToolStripMenuItem
			// 
			this->addIDSToolStripMenuItem->Name = L"addIDSToolStripMenuItem";
			this->addIDSToolStripMenuItem->Size = System::Drawing::Size(213, 22);
			this->addIDSToolStripMenuItem->Text = L"Add IDS";
			this->addIDSToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::addIDSToolStripMenuItem_Click);
			// 
			// exportLanguageTotxtToolStripMenuItem
			// 
			this->exportLanguageTotxtToolStripMenuItem->Name = L"exportLanguageTotxtToolStripMenuItem";
			this->exportLanguageTotxtToolStripMenuItem->Size = System::Drawing::Size(213, 22);
			this->exportLanguageTotxtToolStripMenuItem->Text = L"Export Language to .txt";
			this->exportLanguageTotxtToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::exportLanguageTotxtToolStripMenuItem_Click);
			// 
			// importLanguageFromtxtToolStripMenuItem
			// 
			this->importLanguageFromtxtToolStripMenuItem->Name = L"importLanguageFromtxtToolStripMenuItem";
			this->importLanguageFromtxtToolStripMenuItem->Size = System::Drawing::Size(213, 22);
			this->importLanguageFromtxtToolStripMenuItem->Text = L"Import Language from .txt";
			this->importLanguageFromtxtToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::importLanguageFromtxtToolStripMenuItem_Click);
			// 
			// backgroundWorker1
			// 
			this->backgroundWorker1->WorkerReportsProgress = true;
			this->backgroundWorker1->WorkerSupportsCancellation = true;
			this->backgroundWorker1->DoWork += gcnew System::ComponentModel::DoWorkEventHandler(this, &Form1::backgroundWorker1_DoWork);
			this->backgroundWorker1->RunWorkerCompleted += gcnew System::ComponentModel::RunWorkerCompletedEventHandler(this, &Form1::backgroundWorker1_RunWorkerCompleted);
			this->backgroundWorker1->ProgressChanged += gcnew System::ComponentModel::ProgressChangedEventHandler(this, &Form1::backgroundWorker1_ProgressChanged);
			// 
			// backgroundWorker2
			// 
			this->backgroundWorker2->WorkerReportsProgress = true;
			this->backgroundWorker2->WorkerSupportsCancellation = true;
			this->backgroundWorker2->DoWork += gcnew System::ComponentModel::DoWorkEventHandler(this, &Form1::backgroundWorker2_DoWork);
			this->backgroundWorker2->RunWorkerCompleted += gcnew System::ComponentModel::RunWorkerCompletedEventHandler(this, &Form1::backgroundWorker2_RunWorkerCompleted);
			this->backgroundWorker2->ProgressChanged += gcnew System::ComponentModel::ProgressChangedEventHandler(this, &Form1::backgroundWorker2_ProgressChanged);
			// 
			// splitContainer3
			// 
			this->splitContainer3->Dock = System::Windows::Forms::DockStyle::Fill;
			this->splitContainer3->Location = System::Drawing::Point(0, 0);
			this->splitContainer3->Name = L"splitContainer3";
			this->splitContainer3->Size = System::Drawing::Size(523, 402);
			this->splitContainer3->SplitterDistance = 251;
			this->splitContainer3->TabIndex = 0;
			// 
			// splitContainer4
			// 
			this->splitContainer4->Dock = System::Windows::Forms::DockStyle::Fill;
			this->splitContainer4->Location = System::Drawing::Point(0, 0);
			this->splitContainer4->Name = L"splitContainer4";
			this->splitContainer4->Orientation = System::Windows::Forms::Orientation::Horizontal;
			this->splitContainer4->Size = System::Drawing::Size(221, 402);
			this->splitContainer4->SplitterDistance = 235;
			this->splitContainer4->TabIndex = 0;
			// 
			// backgroundWorker3
			// 
			this->backgroundWorker3->WorkerReportsProgress = true;
			this->backgroundWorker3->WorkerSupportsCancellation = true;
			this->backgroundWorker3->DoWork += gcnew System::ComponentModel::DoWorkEventHandler(this, &Form1::backgroundWorker3_DoWork);
			this->backgroundWorker3->RunWorkerCompleted += gcnew System::ComponentModel::RunWorkerCompletedEventHandler(this, &Form1::backgroundWorker3_RunWorkerCompleted);
			this->backgroundWorker3->ProgressChanged += gcnew System::ComponentModel::ProgressChangedEventHandler(this, &Form1::backgroundWorker3_ProgressChanged);
			// 
			// contextMenuStrip1
			// 
			this->contextMenuStrip1->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->deleteToolStripMenuItem});
			this->contextMenuStrip1->Name = L"contextMenuStrip1";
			this->contextMenuStrip1->Size = System::Drawing::Size(117, 26);
			// 
			// deleteToolStripMenuItem
			// 
			this->deleteToolStripMenuItem->Name = L"deleteToolStripMenuItem";
			this->deleteToolStripMenuItem->Size = System::Drawing::Size(116, 22);
			this->deleteToolStripMenuItem->Text = L"Delete";
			this->deleteToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::deleteToolStripMenuItem_Click);
			// 
			// backgroundWorker4
			// 
			this->backgroundWorker4->WorkerReportsProgress = true;
			this->backgroundWorker4->WorkerSupportsCancellation = true;
			this->backgroundWorker4->DoWork += gcnew System::ComponentModel::DoWorkEventHandler(this, &Form1::backgroundWorker4_DoWork);
			this->backgroundWorker4->RunWorkerCompleted += gcnew System::ComponentModel::RunWorkerCompletedEventHandler(this, &Form1::backgroundWorker4_RunWorkerCompleted);
			this->backgroundWorker4->ProgressChanged += gcnew System::ComponentModel::ProgressChangedEventHandler(this, &Form1::backgroundWorker4_ProgressChanged);
			// 
			// splitContainer10
			// 
			this->splitContainer10->Dock = System::Windows::Forms::DockStyle::Fill;
			this->splitContainer10->Location = System::Drawing::Point(3, 3);
			this->splitContainer10->Name = L"splitContainer10";
			this->splitContainer10->Size = System::Drawing::Size(748, 424);
			this->splitContainer10->SplitterDistance = 249;
			this->splitContainer10->TabIndex = 0;
			// 
			// contextMenuStrip2
			// 
			this->contextMenuStrip2->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->deleteToolStripMenuItem1});
			this->contextMenuStrip2->Name = L"contextMenuStrip2";
			this->contextMenuStrip2->Size = System::Drawing::Size(117, 26);
			// 
			// deleteToolStripMenuItem1
			// 
			this->deleteToolStripMenuItem1->Name = L"deleteToolStripMenuItem1";
			this->deleteToolStripMenuItem1->Size = System::Drawing::Size(116, 22);
			this->deleteToolStripMenuItem1->Text = L"Delete";
			this->deleteToolStripMenuItem1->Click += gcnew System::EventHandler(this, &Form1::deleteToolStripMenuItem1_Click);
			// 
			// backgroundWorker5
			// 
			this->backgroundWorker5->WorkerReportsProgress = true;
			this->backgroundWorker5->WorkerSupportsCancellation = true;
			this->backgroundWorker5->DoWork += gcnew System::ComponentModel::DoWorkEventHandler(this, &Form1::backgroundWorker5_DoWork);
			this->backgroundWorker5->RunWorkerCompleted += gcnew System::ComponentModel::RunWorkerCompletedEventHandler(this, &Form1::backgroundWorker5_RunWorkerCompleted);
			this->backgroundWorker5->ProgressChanged += gcnew System::ComponentModel::ProgressChangedEventHandler(this, &Form1::backgroundWorker5_ProgressChanged);
			// 
			// contextMenuStrip5
			// 
			this->contextMenuStrip5->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(5) {this->extractToolStripMenuItem, 
				this->extractAsPNGToolStripMenuItem, this->exstractAllToolStripMenuItem, this->extractAllAsPNGToolStripMenuItem, this->replacePictureToolStripMenuItem});
			this->contextMenuStrip5->Name = L"contextMenuStrip5";
			this->contextMenuStrip5->Size = System::Drawing::Size(172, 136);
			// 
			// extractToolStripMenuItem
			// 
			this->extractToolStripMenuItem->Name = L"extractToolStripMenuItem";
			this->extractToolStripMenuItem->Size = System::Drawing::Size(159, 22);
			this->extractToolStripMenuItem->Text = L"Extract";
			this->extractToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::extractToolStripMenuItem_Click);
			// 
			// exstractAllToolStripMenuItem
			// 
			this->exstractAllToolStripMenuItem->Name = L"exstractAllToolStripMenuItem";
			this->exstractAllToolStripMenuItem->Size = System::Drawing::Size(159, 22);
			this->exstractAllToolStripMenuItem->Text = L"Exstract All";
			this->exstractAllToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::exstractAllToolStripMenuItem_Click);
			// 
			// replacePictureToolStripMenuItem
			// 
			this->replacePictureToolStripMenuItem->Name = L"replacePictureToolStripMenuItem";
			this->replacePictureToolStripMenuItem->Size = System::Drawing::Size(171, 22);
			this->replacePictureToolStripMenuItem->Text = L"Replace picture";
			this->replacePictureToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::replacePictureToolStripMenuItem_Click);
			// 
			// extractAsPNGToolStripMenuItem
			// 
			this->extractAsPNGToolStripMenuItem->Name = L"extractAsPNGToolStripMenuItem";
			this->extractAsPNGToolStripMenuItem->Size = System::Drawing::Size(159, 22);
			this->extractAsPNGToolStripMenuItem->Text = L"Extract as PNG";
			// 
			// extractAllAsPNGToolStripMenuItem
			// 
			this->extractAllAsPNGToolStripMenuItem->Name = L"extractAllAsPNGToolStripMenuItem";
			this->extractAllAsPNGToolStripMenuItem->Size = System::Drawing::Size(171, 22);
			this->extractAllAsPNGToolStripMenuItem->Text = L"Extract All as PNG";
			// 
			// Form1
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(978, 433);
			this->Controls->Add(this->tabControl1);
			this->Controls->Add(this->statusStrip1);
			this->Name = L"Form1";
			this->Text = L"Wave Remaker New by holod   ver. 0.2.9.5.2";
			this->Load += gcnew System::EventHandler(this, &Form1::Form1_Load);
			this->Click += gcnew System::EventHandler(this, &Form1::debugLevel2ToolStripMenuItem_Click);
			this->statusStrip1->ResumeLayout(false);
			this->statusStrip1->PerformLayout();
			this->tabControl1->ResumeLayout(false);
			this->tabPage2->ResumeLayout(false);
			this->splitContainer8->Panel1->ResumeLayout(false);
			this->splitContainer8->Panel1->PerformLayout();
			this->splitContainer8->Panel2->ResumeLayout(false);
			this->splitContainer8->ResumeLayout(false);
			this->menuStrip1->ResumeLayout(false);
			this->menuStrip1->PerformLayout();
			this->splitContainer9->Panel1->ResumeLayout(false);
			this->splitContainer9->Panel1->PerformLayout();
			this->splitContainer9->Panel2->ResumeLayout(false);
			this->splitContainer9->Panel2->PerformLayout();
			this->splitContainer9->ResumeLayout(false);
			this->menuStrip4->ResumeLayout(false);
			this->menuStrip4->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->EndInit();
			this->contextMenuStrip3->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox1))->EndInit();
			this->menuStrip5->ResumeLayout(false);
			this->menuStrip5->PerformLayout();
			this->tabPage1->ResumeLayout(false);
			this->splitContainer2->Panel1->ResumeLayout(false);
			this->splitContainer2->Panel1->PerformLayout();
			this->splitContainer2->Panel2->ResumeLayout(false);
			this->splitContainer2->ResumeLayout(false);
			this->menuStrip2->ResumeLayout(false);
			this->menuStrip2->PerformLayout();
			this->splitContainer5->Panel1->ResumeLayout(false);
			this->splitContainer5->Panel2->ResumeLayout(false);
			this->splitContainer5->ResumeLayout(false);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox4))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->pictureBox5))->EndInit();
			this->tabPage6->ResumeLayout(false);
			this->groupBox2->ResumeLayout(false);
			this->groupBox1->ResumeLayout(false);
			this->groupBox3->ResumeLayout(false);
			this->groupBox5->ResumeLayout(false);
			this->groupBox5->PerformLayout();
			this->groupBox6->ResumeLayout(false);
			this->groupBox7->ResumeLayout(false);
			this->groupBox7->PerformLayout();
			this->groupBox4->ResumeLayout(false);
			this->groupBox4->PerformLayout();
			this->contextMenuStrip4->ResumeLayout(false);
			this->splitContainer3->ResumeLayout(false);
			this->splitContainer4->ResumeLayout(false);
			this->contextMenuStrip1->ResumeLayout(false);
			this->splitContainer10->ResumeLayout(false);
			this->contextMenuStrip2->ResumeLayout(false);
			this->contextMenuStrip5->ResumeLayout(false);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	

			String^ AppPath;
			String^ FileName;
			String^ FileNamerc2;
			String^FileNameRsr;

			ref struct	DumpArgument {
			
			BinaryReader^ br;
			String^ path;
			array<unsigned char>^ buffer;
			bool dumpfs;
			bool dumprc1;
			bool dumporg;
			bool dumpcsc;
			bool dumprc2;
			bool dumpsmt;
			bool wave3;
			//bool decrypt;
			//bool encrypt;
			//bool decrypt_decompress;
			bool decrypt_decompress_rc1;
			bool decrypt_decompress_bada2;
			};


			ref struct DumpArgumentSave{
			String^ path;
			String^ SaveFileName;
			TreeNode^ TopNode;
			String^ ext;
			DataGridView^ data_grid;
			bool saveapp;
			bool saveorg;
			bool savenoncomprcsc;
			bool savenoncomprrc1;
			bool imgCompress;
			bool decompress;
			bool decrypt;
			bool encrypt;
			bool decrypt_decompress;
			bool sign;
			bool save_images;
			bool decode_folder;
			bool encode_folder;
			bool play_folder;
			bool view_rbm;
			bool wave3;
			};

/////////////////




///////////////
void 	StartDump (array<unsigned char>^ bufferffs, String^ FileName, String^ Donor, bool Wave3){
				if(Donor == L""){
				if( backgroundWorker1->IsBusy ){
				backgroundWorker1->CancelAsync();
				}else{
				DumpArgument^ dump_argument = gcnew DumpArgument;
				dump_argument->dumpfs = true;
				dump_argument->buffer = bufferffs;
				dump_argument->wave3 = Wave3;
				dump_argument->path = AppPath + DIR_PROJECT + Donor + FileName;
				backgroundWorker1->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				}
				}else{
				if( backgroundWorker5->IsBusy ){
				backgroundWorker5->CancelAsync();
				}else{
				DumpArgument^ dump_argument = gcnew DumpArgument;
				dump_argument->dumpfs = true;
				dump_argument->buffer = bufferffs;
				dump_argument->wave3 = Wave3;
				dump_argument->path = AppPath + DIR_PROJECT + Donor + FileName;
				backgroundWorker5->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				}

				}
			}


void 	StartDumprc2 (BinaryReader^ br, String^ FileNamerc2){

	
				if( backgroundWorker3->IsBusy ){
				backgroundWorker3->CancelAsync();
				}else{
				DumpArgument^ dump_argument = gcnew DumpArgument;
				dump_argument->dumprc2 = true;
				dump_argument->br = br;
				dump_argument->path = AppPath + DIR_PROJECT + FileNamerc2;
				backgroundWorker3->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				}

			}

void 	StartDumpRc1 (array<unsigned char>^ bufferrc1, String^ FileName, String^ Donor, bool Wave3){
				if(Donor == L""){
				if( backgroundWorker1->IsBusy ){
				backgroundWorker1->CancelAsync();
				}else{
				DumpArgument^ dump_argument = gcnew DumpArgument;
				dump_argument->dumprc1 = true;
				dump_argument->buffer = bufferrc1;
				dump_argument->wave3 = Wave3;
				dump_argument->path = AppPath + DIR_PROJECT +  Donor + FileName/*rc1*/;
				
				backgroundWorker1->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				}
				}else{
				if( backgroundWorker5->IsBusy ){
				backgroundWorker5->CancelAsync();
				}else{
				DumpArgument^ dump_argument = gcnew DumpArgument;
				dump_argument->dumprc1 = true;
				dump_argument->buffer = bufferrc1;
				dump_argument->wave3 = Wave3;
				dump_argument->path = AppPath + DIR_PROJECT + Donor + FileName;
				
				backgroundWorker5->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				}

				}
			}

void 	StartDumpOrg (array<unsigned char>^ bufferrc1, String^ FileNamerc1, String^ Donor){
				if(Donor == L""){
				if( backgroundWorker1->IsBusy ){
				backgroundWorker1->CancelAsync();
				}else{
				DumpArgument^ dump_argument = gcnew DumpArgument;
				dump_argument->dumporg = true;
				dump_argument->buffer = bufferrc1;
				dump_argument->path = AppPath + DIR_PROJECT +   Donor + FileNamerc1;
				
				
				backgroundWorker1->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				}
				}else{
				if( backgroundWorker5->IsBusy ){
				backgroundWorker5->CancelAsync();
				}else{
				DumpArgument^ dump_argument = gcnew DumpArgument;
				dump_argument->dumporg = true;
				dump_argument->buffer = bufferrc1;
				dump_argument->path = AppPath + DIR_PROJECT + Donor + FileNamerc1;
				
				
				backgroundWorker5->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				}

				}
			}


void 	StartDumpCsc (array<unsigned char>^ buffercsc, String^ FileNamecsc, String^ Donor, bool Wave3){
				if(Donor == L""){
				if( backgroundWorker1->IsBusy ){
				backgroundWorker1->CancelAsync();
				}else{
				DumpArgument^ dump_argument = gcnew DumpArgument;
				dump_argument->dumpcsc = true;
				dump_argument->buffer = buffercsc;
				dump_argument->wave3 = Wave3;
				dump_argument->path = AppPath + DIR_PROJECT + Donor + FileNamecsc;
				backgroundWorker1->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				}
				}else{
				if( backgroundWorker5->IsBusy ){
				backgroundWorker5->CancelAsync();
				}else{
				DumpArgument^ dump_argument = gcnew DumpArgument;
				dump_argument->dumpcsc = true;
				dump_argument->buffer = buffercsc;
				dump_argument->wave3 = Wave3;
				dump_argument->path = AppPath + DIR_PROJECT + Donor + FileNamecsc;
				backgroundWorker5->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				}

				}
			}

void 	StartDumpSmt (array<unsigned char>^ buffersmt, String^ FileNamesmt, String^ Donor/*, bool Wave3*/){
				if(Donor == L""){
				if( backgroundWorker1->IsBusy ){
				backgroundWorker1->CancelAsync();
				}else{
				DumpArgument^ dump_argument = gcnew DumpArgument;
				dump_argument->dumpsmt = true;
				dump_argument->buffer = buffersmt;
//				dump_argument->wave3 = Wave3;
				dump_argument->path = AppPath + DIR_PROJECT + Donor + FileNamesmt;
				backgroundWorker1->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				}
				}else{
				if( backgroundWorker5->IsBusy ){
				backgroundWorker5->CancelAsync();
				}else{
				DumpArgument^ dump_argument = gcnew DumpArgument;
				dump_argument->dumpsmt = true;
				dump_argument->buffer = buffersmt;
//				dump_argument->wave3 = Wave3;
				dump_argument->path = AppPath + DIR_PROJECT + Donor + FileNamesmt;
				backgroundWorker5->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				}

				}
			}



void 	StartSaveApp (String^ SaveFileName, TreeView^ treeView ){

				 if( backgroundWorker2->IsBusy )
						{
							backgroundWorker2->CancelAsync();
						}
						else
						{
							DumpArgumentSave^ dump_argument = gcnew DumpArgumentSave;
							dump_argument->SaveFileName = SaveFileName;
							//dump_argument->TopNode = treeView->TopNode;
							dump_argument->TopNode = treeView->Nodes[0];
							dump_argument->saveapp = true;

							backgroundWorker2->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );

				 }
			}


void 	StartSaveOrg (String^ SaveFileName, TreeView^ treeView ){

				 if( backgroundWorker2->IsBusy )
						{
							backgroundWorker2->CancelAsync();
						}
						else
						{
							DumpArgumentSave^ dump_argument = gcnew DumpArgumentSave;
							dump_argument->SaveFileName = SaveFileName;
							dump_argument->TopNode = treeView->Nodes[0];
							dump_argument->saveorg = true;

							backgroundWorker2->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				 }
			}

	void StartSaveNonComprCsc (String^ SaveFileName, TreeView^ treeView ){
				 if( backgroundWorker2->IsBusy )
						{
							backgroundWorker2->CancelAsync();
						}
						else
						{
							DumpArgumentSave^ dump_argument = gcnew DumpArgumentSave;
							dump_argument->SaveFileName = SaveFileName;
							//dump_argument->TopNode = treeView6->TopNode;
							dump_argument->TopNode = treeView->Nodes[0];
							dump_argument->savenoncomprcsc = true;

							backgroundWorker2->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				 }
}

	void StartSaveNonComprRC1 (String^ SaveFileName, TreeView^ treeView ){
				 if( backgroundWorker2->IsBusy )
						{
							backgroundWorker2->CancelAsync();
						}
						else
						{
							DumpArgumentSave^ dump_argument = gcnew DumpArgumentSave;
							dump_argument->SaveFileName = SaveFileName;
							//dump_argument->TopNode = treeView6->TopNode;
							dump_argument->TopNode = treeView->Nodes[0];
							dump_argument->savenoncomprrc1 = true;

							backgroundWorker2->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );

				 }

}

	void Start_IMG_Compress (String^ OpenFileName, String^ SaveFileName ){
				 if( backgroundWorker4->IsBusy )
						{
							backgroundWorker4->CancelAsync();
						}
						else
						{
							DumpArgumentSave^ dump_argument = gcnew DumpArgumentSave;
							dump_argument->SaveFileName = SaveFileName;
							dump_argument->path = OpenFileName;
							dump_argument->imgCompress = true;

							backgroundWorker4->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				 }
}


	void Start_Decrypt (String^ OpenFileName, String^ SaveFileName ){
				 if( backgroundWorker4->IsBusy )
						{
							backgroundWorker4->CancelAsync();
						}
						else
						{
							DumpArgumentSave^ dump_argument = gcnew DumpArgumentSave;
							dump_argument->SaveFileName = SaveFileName;
							dump_argument->path = OpenFileName;
							dump_argument->decrypt = true;
							dump_argument->wave3 = checkBox1->Checked;
							backgroundWorker4->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				 }
}

	void Start_Encrypt (String^ OpenFileName, String^ SaveFileName ){
				 if( backgroundWorker4->IsBusy )
						{
							backgroundWorker4->CancelAsync();
						}
						else
						{
							DumpArgumentSave^ dump_argument = gcnew DumpArgumentSave;
							dump_argument->SaveFileName = SaveFileName;
							dump_argument->path = OpenFileName;
							dump_argument->encrypt = true;
							
							dump_argument->wave3 = checkBox1->Checked;
							backgroundWorker4->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				 }
}
	void Start_Decrypt_Decompress (String^ OpenFileName, String^ SaveFileName ){
				 if( backgroundWorker4->IsBusy )
						{
							backgroundWorker4->CancelAsync();
						}
						else
						{
							DumpArgumentSave^ dump_argument = gcnew DumpArgumentSave;
							dump_argument->SaveFileName = SaveFileName;
							dump_argument->path = OpenFileName;
							dump_argument->decrypt_decompress = true;
							backgroundWorker4->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				 }
}
	void Start_Decompress (String^ OpenFileName, String^ SaveFileName ){
				 if( backgroundWorker4->IsBusy )
						{
							backgroundWorker4->CancelAsync();
						}
						else
						{
							DumpArgumentSave^ dump_argument = gcnew DumpArgumentSave;
							dump_argument->SaveFileName = SaveFileName;
							dump_argument->path = OpenFileName;
							dump_argument->decompress = true;
							backgroundWorker4->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				 }
}

	void Start_Sign (String^ OpenFileName ){
				 if( backgroundWorker4->IsBusy )
						{
							backgroundWorker4->CancelAsync();
						}
						else
						{
							DumpArgumentSave^ dump_argument = gcnew DumpArgumentSave;
							dump_argument->path = OpenFileName;
							dump_argument->sign = true;
							backgroundWorker4->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				 }
}


	void Start_Save_Image(String^ OpenFileName, String^ SaveFileName){

				 if( backgroundWorker4->IsBusy )
						{
							backgroundWorker4->CancelAsync();
						}
						else
						{
							DumpArgumentSave^ dump_argument = gcnew DumpArgumentSave;
							dump_argument->SaveFileName = SaveFileName;
							dump_argument->path = OpenFileName;
							dump_argument->save_images = true;
							backgroundWorker4->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				 }
	}

	void Start_Folder_Decode(String^ OpenFolderName, String^ SaveFolderName){

				 if( backgroundWorker4->IsBusy )
						{
							backgroundWorker4->CancelAsync();
						}
						else
						{
							DumpArgumentSave^ dump_argument = gcnew DumpArgumentSave;
							dump_argument->SaveFileName = SaveFolderName;
							dump_argument->path = OpenFolderName;
							dump_argument->decode_folder = true;
							if(radioButton1->Checked ){
								dump_argument->ext = L".bmp";
							}else if(radioButton2->Checked){
								dump_argument->ext = L".png";
							}else if(radioButton3->Checked){
								dump_argument->ext = L".jpg";
							}
							
							
							backgroundWorker4->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				 }
	}
	void Start_Folder_Encode(String^ OpenFolderName, String^ SaveFolderName){

				 if( backgroundWorker4->IsBusy )
						{
							backgroundWorker4->CancelAsync();
						}
						else
						{
							DumpArgumentSave^ dump_argument = gcnew DumpArgumentSave;
							dump_argument->SaveFileName = SaveFolderName;
							dump_argument->path = OpenFolderName;
							dump_argument->encode_folder = true;
							if(radioButton4->Checked ){
								dump_argument->ext = L".bmp";
							}else if(radioButton5->Checked){
								dump_argument->ext = L".png";
							}else if(radioButton6->Checked){
								dump_argument->ext = L".jpg";
							}
							
							backgroundWorker4->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				 }
	}

	void Start_View_RBM(String^ PathRBM, DataGridView^ dataGridView){

				 if( backgroundWorker4->IsBusy )
						{
							backgroundWorker4->CancelAsync();
						}
						else
						{
							DumpArgumentSave^ dump_argument = gcnew DumpArgumentSave;
							//dump_argument->SaveFileName = SaveFileName;
							dump_argument->path = PathRBM;
							dump_argument->view_rbm = true;
							dump_argument->data_grid = dataGridView;
							backgroundWorker4->RunWorkerAsync( dynamic_cast <System::Object^> (dump_argument) );
				 }



	}

	void SavePicture(PictureBox^ pictureBox){

			SaveFileDialog^ SaveFileDialog1 = gcnew SaveFileDialog;
			SaveFileDialog1->InitialDirectory = Environment::CurrentDirectory;//"c:\\";
			SaveFileDialog1->Filter="BMP files (*.bmp)|*.bmp|PNG files (*.png)|*.png|JPG files (*.jpg)|*.jpg|All files (*.*)|*.*";
			SaveFileDialog1->Title = L"Save picture as .bmp .png .jpg  files";

			if (SaveFileDialog1->ShowDialog()!= System::Windows::Forms::DialogResult::OK){
				Environment::CurrentDirectory = AppPath;
				return;
			}

			Environment::CurrentDirectory = AppPath;
			String^ SaveFileName = SaveFileDialog1->FileName;
			
			String^ ext = Path::GetExtension(SaveFileName)->ToLower();
				if(ext == ".bmp" ){
					Bitmap^ img = gcnew Bitmap(pictureBox->Image);
					img->Save(SaveFileName,Imaging::ImageFormat::Bmp);
				}else if(ext == ".png"){
					Bitmap^ img = gcnew Bitmap(pictureBox->Image);
					img->Save(SaveFileName,Imaging::ImageFormat::Png);
				}else if(ext == ".jpg"){
					Bitmap^ img = gcnew Bitmap(pictureBox->Image);
					img->Save(SaveFileName,Imaging::ImageFormat::Jpeg);
				}else{
					MessageBox::Show("Extension is not correct", "ERROR",  MessageBoxButtons::OK, MessageBoxIcon::Error);
				}
	}

			String^ GetString(array<unsigned char>^ buff, int offset) {
				//Int64 position = br->BaseStream->Position;
				//br->BaseStream->Seek(offset, SeekOrigin::Begin);
				Char b;
				String^ string;
				while((b = buff[offset]) != 0x00) {
					string += b;
					offset++;
				}
				//br->BaseStream->Seek(position, System::IO::SeekOrigin::Begin);
				return string;
			}

void	NodeMouseClick(System::Windows::Forms::TreeNodeMouseClickEventArgs^  e, System::Windows::Forms::TreeView^ treeView, bool donor){
			 
		treeView->SelectedNode = e->Node;

		richTextBox1->Visible = false;
		pictureBox1->Visible = false;
		dataGridView1->Visible = false;
		if( e->Node->Level == 0)
			return;

		if(e->Node->ImageIndex == 2 ){
		
			richTextBox1->Visible = false;
			pictureBox1->Visible = true;
			dataGridView1->Visible = false;
	
			Item^ rbm_item = dynamic_cast<Item^>(e->Node->Tag);
			
			if(rbm_item->item_bit_format == 0x10 && rbm_item->item_compression_metod == 2 && rbm_item->item_height > 1 && rbm_item->item_width >1){

			Rbm_LZ16_View(rbm_item->item_width, rbm_item->item_height, rbm_item->data, pictureBox1);

			}else if(rbm_item->item_bit_format == 0x20 && rbm_item->item_compression_metod == 2 && rbm_item->item_height > 1 && rbm_item->item_width >1){

			Rbm_LZ32_View(rbm_item->item_width, rbm_item->item_height, rbm_item->data, pictureBox1);
			
			}else if(rbm_item->item_bit_format == 0x20 && (rbm_item->item_compression_metod == 3 || rbm_item->item_compression_metod == 5) && rbm_item->item_height > 1 && rbm_item->item_width >1){
			
			ViewQM( rbm_item->data, pictureBox1);
			
			}else if(rbm_item->item_bit_format == 0x10 && (rbm_item->item_compression_metod == 3 || rbm_item->item_compression_metod == 5) && rbm_item->item_height > 1 && rbm_item->item_width >1){
			
			ViewQM16( rbm_item->data, pictureBox1);
			

			}else{
			
			pictureBox1->Image = nullptr;
			pictureBox1->Invalidate();
			
			}
			return;
		}


		String^ ext = Path::GetExtension(static_cast <String^> (e->Node->Tag))->ToLower();
		 if(ext == ".txt" ||  ext == ".profile" ||  ext == ".reg" || ext == ".sig" || ext == ".conf" || ext == ".ini" || ext == ".xml"  || ext == ".js" || ext == ".html" || ext == ".htm" || ext == ".css" || ext == ".cfg" || ext == ".store")
		 {
			richTextBox1->Visible = true;
			pictureBox1->Visible = false;
			dataGridView1->Visible = false;
			
			richTextBox1->LoadFile(static_cast <String^> (e->Node->Tag), RichTextBoxStreamType::PlainText);
			richTextBox1->Tag = e->Node->Tag;
				
			HighlightColors^ hlc = gcnew HighlightColors;
			hlc->HighlightRTF(richTextBox1);
			
		 }else if (ext == ".jpg" || ext == ".png" || ext == ".bmp"){
			
			richTextBox1->Visible = false;
			pictureBox1->Visible = true;
			dataGridView1->Visible = false;
			pictureBox1->Load(static_cast <String^> (e->Node->Tag));
		 }else if (ext == ".rsr" ){
			
			richTextBox1->Visible = false;
			pictureBox1->Visible = false;
			dataGridView1->Visible = true;
			String^ PathRsr = static_cast <String^> (e->Node->Tag);
			dataGridView1->ContextMenuStrip = contextMenuStrip4;
			ViewRSR(PathRsr, dataGridView1);
		 }else if (ext == ".rbm" && !donor){
			
			richTextBox1->Visible = false;
			pictureBox1->Visible = false;
			dataGridView1->Visible = true;
			String^ PathRBM = static_cast <String^> (e->Node->Tag);
			ViewRBM(PathRBM, treeView7, contextMenuStrip5);
		 }else if (ext == ".img" ){
			
			richTextBox1->Visible = false;
			pictureBox1->Visible = true;
			dataGridView1->Visible = false;
			String^ PathIMG = static_cast <String^> (e->Node->Tag);
			ViewIMG(File::ReadAllBytes(PathIMG), pictureBox1);
		 }else if (ext == ".qmg" ){
			
			richTextBox1->Visible = false;
			pictureBox1->Visible = true;
			dataGridView1->Visible = false;
			String^ PathQMG = static_cast <String^> (e->Node->Tag);
			ViewQMG(File::ReadAllBytes(PathQMG), pictureBox1);
		 }
			}
void	KeyUp(System::Windows::Forms::KeyEventArgs^  e, System::Windows::Forms::TreeView^ treeView, bool donor ){

		if (e->KeyCode == Keys::Delete)
		{
		if( System::Windows::Forms::DialogResult::No == MessageBox::Show("Delete?", "Delete", MessageBoxButtons::YesNo,MessageBoxIcon::Question)){return;}

		String^ NodeName = static_cast <String^> (treeView->SelectedNode->Tag);
			if (File::Exists(NodeName)){
				File::Delete(NodeName );
				treeView->Nodes->Remove(treeView->SelectedNode);
			}else if (Directory::Exists (NodeName)){
				Directory::Delete(NodeName, true);
				treeView->Nodes->Remove(treeView->SelectedNode);
			}
		}
		if(e->KeyCode == Keys::Enter)
		{
			if(treeView->SelectedNode->IsExpanded){
				 treeView->SelectedNode->Collapse();
			}else{
				 treeView->SelectedNode->Expand();
		}

//		richTextBox1->Visible = false;
//			pictureBox1->Visible = false;
//				dataGridView1->Visible = false;

//		if(treeView->SelectedNode->Level == 0)return;


		TreeNodeMouseClickEventArgs^  a = gcnew TreeNodeMouseClickEventArgs(treeView->SelectedNode,System::Windows::Forms::MouseButtons::Left ,1 ,treeView->SelectedNode->TreeView->Right ,treeView->SelectedNode->TreeView->Bottom);
			NodeMouseClick(a, treeView, donor);
			
/*		String^ ext = Path::GetExtension(static_cast <String^> (treeView->SelectedNode->Tag))->ToLower();
		 if(ext == ".txt" || ext == ".profile" || ext == ".reg" ||ext == ".sig" || ext == ".conf" || ext == ".ini" || ext == ".xml"  || ext == ".js" || ext == ".html" || ext == ".htm" || ext == ".css" || ext == ".cfg" || ext == ".store")
			 {
				richTextBox1->Visible = true;
				pictureBox1->Visible = false;
				richTextBox1->LoadFile(static_cast <String^> (treeView->SelectedNode->Tag), RichTextBoxStreamType::PlainText);
				richTextBox1->Tag = treeView->SelectedNode->Tag;

				HighlightColors^ hlc = gcnew HighlightColors;
				hlc->HighlightRTF(richTextBox1);
				
				dataGridView1->Visible = false;
			 }else if (ext == ".jpg" || ext == ".png" || ext == ".bmp"){
				
				richTextBox1->Visible = false;
				pictureBox1->Visible = true;
				pictureBox1->Load(static_cast <String^> (treeView->SelectedNode->Tag));
				dataGridView1->Visible = false;
			 }else if (ext == ".rsr" ){
				
				richTextBox1->Visible = false;
				pictureBox1->Visible = false;
				dataGridView1->Visible = true;
				String^ PathRsr = static_cast <String^> (treeView->SelectedNode->Tag);
				dataGridView1->ContextMenuStrip = contextMenuStrip4;
				DumpRSR(PathRsr, dataGridView1);

			 }else if (ext == ".rbm" ){
			
			richTextBox1->Visible = false;
			pictureBox1->Visible = false;
			dataGridView1->Visible = false;
			String^ PathRBM = static_cast <String^> (treeView->SelectedNode->Tag);
			//dataGridView1->ContextMenuStrip = nullptr;//contextMenuStrip4;
			ViewRBM(PathRBM, treeView7 );
			
			 }else if (ext == ".img" ){
			
			richTextBox1->Visible = false;
			pictureBox1->Visible = true;
			dataGridView1->Visible = false;
			String^ PathIMG = static_cast <String^> (treeView->SelectedNode->Tag);
			ViewIMG(File::ReadAllBytes(PathIMG), pictureBox1);
		 }	*/			 
			 }

		}
void	DragDrop(System::Windows::Forms::DragEventArgs^  e, System::Windows::Forms::TreeView^ _treeView, String^ Donor){
			 
				if ( !e->Data->GetDataPresent(DataFormats::FileDrop)){return; }

				TreeNode^ newNode;
				array<String ^> ^aFiles;
				String^ FileDrop;
				String^ FileType = L"";
				String^ NameWave = L"     ";
				String^ FileExt;


				newNode = dynamic_cast<TreeNode^> (e->Data->GetData(DataFormats::FileDrop));


				array<unsigned char>^ myStreamOpen ;
				bool Wave3 = false;

				if(newNode == nullptr){
				aFiles = dynamic_cast<array<String^>^ >(e->Data->GetData(DataFormats::FileDrop)); 				
				FileDrop = aFiles[0];
				FileExt = Path::GetExtension(FileDrop);//fi->Name->Replace(Path::GetExtension(FileDrop), "");

				if ( (myStreamOpen = File::ReadAllBytes(FileDrop)) == nullptr ){ Environment::CurrentDirectory = AppPath; return; }
				
				if(FileExt == L".app" || FileExt == L".pfs" || FileExt == L".ffs" || FileExt == L".rc1" || FileExt == L".csc" || FileExt == L".app"){
				NameWave = GetString(myStreamOpen, myStreamOpen->Length - 1012);
				FileType = GetString(myStreamOpen, myStreamOpen->Length - 980);
				}
				if( NameWave == L"S8600" || NameWave->Substring(0,5) == L"S7230" || NameWave->Substring(0,5) == L"S5750")
				Wave3 = true;
				
				}//else{
				//FileDrop = dynamic_cast<String^>( newNode->FullPath);
				//}


				//_treeView->BeginUpdate();
				//_treeView->Nodes->Clear();
				//_treeView->EndUpdate();


				if((FileType == "ffs"  || FileType == "app" || FileType == "pfs")){

				//FileInfo^ fi = gcnew FileInfo(FileDrop);
				//FileName = fi->Name->Replace(Path::GetExtension(FileDrop), "");

				//array<unsigned char>^ myStreamOpenFfs ;
				//if ( (myStreamOpenFfs = File::ReadAllBytes(FileDrop)) == nullptr ){ Environment::CurrentDirectory = AppPath; return; }
				//
				//if(!Directory::Exists(AppPath + DIR_PROJECT + Donor + FileName)){
				//Directory::CreateDirectory(AppPath + DIR_PROJECT +  Donor + FileName);
				//}else{
				//Directory::Delete(AppPath + DIR_PROJECT +  Donor + FileName, true);
				//Directory::CreateDirectory(AppPath + DIR_PROJECT +  Donor + FileName);
				//}
				//
				//treeView->BeginUpdate();
				//treeView->Nodes->Clear();
				//treeView->EndUpdate();

				//String^ NameWave = GetString(myStreamOpenFfs, myStreamOpenFfs->Length - 1012);
				//String^ FileName = GetString(myStreamOpenFfs, myStreamOpenFfs->Length - 980);
				
				FileName = Path::GetFileNameWithoutExtension(FileDrop);
				
				if(!Directory::Exists(AppPath + DIR_PROJECT + Donor + FileName)){
				Directory::CreateDirectory(AppPath + DIR_PROJECT +  Donor + FileName);
				}else{
				Directory::Delete(AppPath + DIR_PROJECT +  Donor + FileName, true);
				Directory::CreateDirectory(AppPath + DIR_PROJECT +  Donor + FileName);
				}

				StartDump(myStreamOpen, FileName, Donor, Wave3);

			}else if(FileType == "rc1" ){

				//FileInfo^ fi = gcnew FileInfo(FileDrop);
				//FileName/*rc1*/ = fi->Name->Replace(Path::GetExtension(FileDrop), "");
				//array<unsigned char>^ myStreamOpenRc1 ;
				//if ( (myStreamOpenRc1 = File::ReadAllBytes(FileDrop)) == nullptr ){ Environment::CurrentDirectory = AppPath; return; }
				//if(!Directory::Exists(AppPath + DIR_PROJECT +  Donor + FileName/*rc1*/)){
				//	Directory::CreateDirectory(AppPath + DIR_PROJECT +  Donor + FileName/*rc1*/);
				//	}else{
				//	Directory::Delete(AppPath + DIR_PROJECT +  Donor + FileName, true);
				//	Directory::CreateDirectory(AppPath + DIR_PROJECT +  Donor + FileName);
				//	}	
				//	
				//	treeView->BeginUpdate();
				//	treeView->Nodes->Clear();
				//	treeView->EndUpdate();
				FileName = Path::GetFileNameWithoutExtension(FileDrop);
				if(!Directory::Exists(AppPath + DIR_PROJECT + Donor + FileName)){
				Directory::CreateDirectory(AppPath + DIR_PROJECT +  Donor + FileName);
				}else{
				Directory::Delete(AppPath + DIR_PROJECT +  Donor + FileName, true);
				Directory::CreateDirectory(AppPath + DIR_PROJECT +  Donor + FileName);
				}

				StartDumpRc1(myStreamOpen, FileName, Donor, Wave3);
			
			}else if(FileType == "csc" ){

				//FileInfo^ fi = gcnew FileInfo(FileDrop);
				//FileName/*csc*/ = fi->Name->Replace(Path::GetExtension(FileDrop), "");

				//array<unsigned char>^ myStreamOpencsc ;
				//if ( (myStreamOpencsc = File::ReadAllBytes(FileDrop)) == nullptr ){ Environment::CurrentDirectory = AppPath; return; }
				//
				//if(!Directory::Exists(AppPath + DIR_PROJECT +  Donor + FileName/*csc*/)){
				//	Directory::CreateDirectory(AppPath + DIR_PROJECT +  Donor + FileName/*csc*/);
				//}else{
				//	Directory::Delete(AppPath + DIR_PROJECT +  Donor + FileName, true);
				//	Directory::CreateDirectory(AppPath + DIR_PROJECT +  Donor + FileName);
				//}

				//	treeView->BeginUpdate();
				//	treeView->Nodes->Clear();
				//	treeView->EndUpdate();
				FileName = Path::GetFileNameWithoutExtension(FileDrop);
				if(!Directory::Exists(AppPath + DIR_PROJECT + Donor + FileName)){
				Directory::CreateDirectory(AppPath + DIR_PROJECT +  Donor + FileName);
				}else{
				Directory::Delete(AppPath + DIR_PROJECT +  Donor + FileName, true);
				Directory::CreateDirectory(AppPath + DIR_PROJECT +  Donor + FileName);
				}

				StartDumpCsc(myStreamOpen, FileName, Donor, Wave3);
	
			}else if( (Path::GetExtension(FileDrop) == ".org" )){

				//FileInfo^ fi = gcnew FileInfo(FileDrop);
				//FileName/*rc1*/ = fi->Name->Replace(Path::GetExtension(FileDrop), "");
				//array<unsigned char>^ myStreamOpenOrg ;
				//if ( (myStreamOpenOrg = File::ReadAllBytes(FileDrop)) == nullptr ){ Environment::CurrentDirectory = AppPath; return; }
				//if(!Directory::Exists(AppPath + DIR_PROJECT +  Donor + FileName/*rc1*/)){
				//	Directory::CreateDirectory(AppPath + DIR_PROJECT +  Donor + FileName/*rc1*/);
				//	}else{
				//	Directory::Delete(AppPath + DIR_PROJECT +  Donor + FileName, true);
				//	Directory::CreateDirectory(AppPath + DIR_PROJECT +  Donor + FileName);
				//	}
				//	
				//	treeView->BeginUpdate();
				//	treeView->Nodes->Clear();
				//	treeView->EndUpdate();
				FileName = Path::GetFileNameWithoutExtension(FileDrop);
				if(!Directory::Exists(AppPath + DIR_PROJECT + Donor + FileName)){
				Directory::CreateDirectory(AppPath + DIR_PROJECT +  Donor + FileName);
				}else{
				Directory::Delete(AppPath + DIR_PROJECT +  Donor + FileName, true);
				Directory::CreateDirectory(AppPath + DIR_PROJECT +  Donor + FileName);
				}

				StartDumpOrg(myStreamOpen, FileName, Donor);
	

			}else if( (Path::GetExtension(FileDrop) == ".smt" )){

				FileName = Path::GetFileNameWithoutExtension(FileDrop);
				if(!Directory::Exists(AppPath + DIR_PROJECT + Donor + FileName)){
				Directory::CreateDirectory(AppPath + DIR_PROJECT +  Donor + FileName);
				}else{
				Directory::Delete(AppPath + DIR_PROJECT +  Donor + FileName, true);
				Directory::CreateDirectory(AppPath + DIR_PROJECT +  Donor + FileName);
				}

				StartDumpSmt(myStreamOpen, FileName, Donor);			

			
			}else if(FileDrop != nullptr && _treeView->GetNodeCount(true)/* && Path::GetExtension(FileDrop) != ".ffs" && Path::GetExtension(FileDrop) != ".app" && Path::GetExtension(FileDrop) != ".pfs" && Path::GetExtension(FileDrop) != ".org" && Path::GetExtension(FileDrop) != ".rc1" && Path::GetExtension(FileDrop) != ".csc" && Path::GetExtension(FileDrop) != ".smt" */){
					
				if(nullptr == _treeView->SelectedNode){return;}

				String^ FileNameCopy;
				if(Directory::Exists(FileDrop) ){
					DirectoryInfo^ di = gcnew DirectoryInfo(FileDrop);
					//FileName = di->Name;
					FileNameCopy = _treeView->SelectedNode->Tag + "\\" + di->Name;
					DirectoryCopy(FileDrop, FileNameCopy);

				}else{
					FileInfo^ fi = gcnew FileInfo(FileDrop);
					FileNameCopy = _treeView->SelectedNode->Tag + "\\" + fi->Name;
					File::Copy(FileDrop, FileNameCopy, true);
				}
				
				TreeNode^ nodeselect = _treeView->SelectedNode;
				String^ FileNameOpen = _treeView->TopNode->Text;
				
				_treeView->BeginUpdate();
				_treeView->Nodes->Clear();
				
				TreeNode^ rootNode = gcnew TreeNode( FileNameOpen,0,0);
				rootNode->NodeFont = gcnew System::Drawing::Font("Arial",8,System::Drawing::FontStyle::Bold);
				rootNode->Tag = AppPath + DIR_PROJECT +  Donor + FileNameOpen;
				
				_treeView->Nodes->Add( rootNode);
				_treeView->Sorted = true;

				OpenProject(AppPath + DIR_PROJECT + Donor + FileNameOpen, rootNode, contextMenuStrip1);

				_treeView->EndUpdate();
				_treeView->TopNode->Expand();
				if(rootNode->LastNode->Text == L"System")
				rootNode->LastNode->Expand();//////////


				for each (TreeNode^ n in _treeView->Nodes)
				{

					if(Object::Equals(n->Tag, nodeselect->Tag)){
					_treeView->SelectedNode = n;
					break;
					}

					WalkTreeNode(n, 0 , nodeselect, _treeView);
				}
				
				
				_treeView->SelectedNode->Expand();
				
				_treeView->Focus();
				
			}else if(newNode != nullptr && Donor == L"" /*&& (Path::GetExtension(FileDrop) != ".ffs" || Path::GetExtension(FileDrop) != ".app" || Path::GetExtension(FileDrop) != ".pfs" || Path::GetExtension(FileDrop) != ".org" || Path::GetExtension(FileDrop) != ".rc1" || Path::GetExtension(FileDrop) != ".csc" || Path::GetExtension(FileDrop) != ".smt" )*/){
									
				if(nullptr == _treeView->SelectedNode){return;}

				String^ FileNameCopy;
				if(Directory::Exists(dynamic_cast<String^>(newNode->Tag)) ){
					DirectoryInfo^ di = gcnew DirectoryInfo(dynamic_cast<String^>(newNode->Tag));
					//FileName = di->Name;
					FileNameCopy = _treeView->SelectedNode->Tag + "\\" + di->Name;
					DirectoryCopy(dynamic_cast<String^>(newNode->Tag), FileNameCopy);

				}else{
					FileInfo^ fi = gcnew FileInfo(dynamic_cast<String^>(newNode->Tag));
					FileNameCopy = _treeView->SelectedNode->Tag + "\\" + fi->Name;
					File::Copy(dynamic_cast<String^>(newNode->Tag), FileNameCopy, true);
				}
				
				TreeNode^ nodeselect = _treeView->SelectedNode;
				String^ FileNameOpen = _treeView->TopNode->Text;

				
				_treeView->BeginUpdate();
				_treeView->Nodes->Clear();
				
				TreeNode^ rootNode = gcnew TreeNode( FileNameOpen,0,0);
				rootNode->NodeFont = gcnew System::Drawing::Font("Arial",8,System::Drawing::FontStyle::Bold);
				rootNode->Tag = AppPath + DIR_PROJECT +  Donor + FileNameOpen;
				
				_treeView->Nodes->Add( rootNode);
				_treeView->Sorted = true;

				OpenProject(AppPath + DIR_PROJECT +  Donor + FileNameOpen, rootNode, contextMenuStrip1);

				_treeView->EndUpdate();
				_treeView->TopNode->Expand();
				if(rootNode->LastNode->Text == L"System")
				rootNode->LastNode->Expand();//////////

//				WalkTreeNode(_treeView, _treeView->Nodes[0], nodeselect);
//				_treeView->SelectedNode->Expand();

				for each (TreeNode^ n in _treeView->Nodes)
				{

					if(Object::Equals(n->Tag, nodeselect->Tag)){
					_treeView->SelectedNode = n;
					break;
					}

					WalkTreeNode(n, 0 , nodeselect, _treeView);
				}


				_treeView->SelectedNode->Expand();
				_treeView->Focus();
				
			}

		}
private: System::Void dumpFileToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {


			Stream^ myStream;
			OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;
			openFileDialog1->InitialDirectory = /*"c:\\";*/Environment::CurrentDirectory;//"c:\\";
			openFileDialog1->Filter="Firmware files (*.app; *.pfs; *.ffs; *.rc1; *.org; *.csc; *.smt)|*.pfs;*.app; *.ffs; *.rc1; *.org; *.csc; *.smt|All files (*.*)|*.*";//|  *.app; *.pfs";
			openFileDialog1->Title = L"Open .APP, .FFS, .PFS, .RC1, .ORG, .CSC, .SMT files";
			openFileDialog1->FilterIndex = 1;

			if (openFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}
			 
				Name = openFileDialog1->FileName;
				FileInfo^ fi = gcnew FileInfo( Name );
				
				String^ FileExt = Path::GetExtension(fi->Name);
				String^ NameWave = L"     ";
				String^ FileType = L"";


				FileName/*rc1*/ = Path::GetFileNameWithoutExtension(Name);//fi->Name->Replace(Path::GetExtension(ExtName), "");				
				Environment::CurrentDirectory = AppPath;

				 array<unsigned char>^ buffer = gcnew array<unsigned char>(fi->Length);
				 if ( (buffer = File::ReadAllBytes(fi->FullName/*openFileDialog1->FileName*/)) == nullptr ) return; 
			 	

				//if(!Directory::Exists(AppPath + DIR_PROJECT + FileName))
				Directory::CreateDirectory(AppPath + DIR_PROJECT + FileName);
				
				treeView6->BeginUpdate();////////////////
				treeView6->Nodes->Clear();/////////////////////
				treeView6->EndUpdate();////////////////

				bool Wave3 = false;
				
				if(FileExt == L".app" || FileExt == L".pfs" || FileExt == L".ffs" || FileExt == L".rc1" || FileExt == L".csc" || FileExt == L".app"){
				
				NameWave = GetString(buffer, buffer->Length - 1012);
				FileType = GetString(buffer, buffer->Length - 980);
				
				}

				if(NameWave == L"S8600" || NameWave->Substring(0,5) == L"S7230" || NameWave->Substring(0,5) == L"S5750")
				Wave3 = true;


				if(FileType == "app" || FileType == "pfs" || FileType == "ffs"  ){
				
				StartDump(buffer, FileName, L"", Wave3);
			
				}else if(FileType == "rc1" ){

				StartDumpRc1(buffer, FileName, L"", Wave3);
				
				}else if((Path::GetExtension(fi->Name) == ".org" )){
				
				StartDumpOrg(buffer, FileName, L"");
			
				}else if(FileType == "csc"){
				
				StartDumpCsc(buffer, FileName, L"", Wave3);
			
				}else if((Path::GetExtension(fi->Name) == ".smt" )){
				
				StartDumpSmt(buffer, FileName, L"");
				}
		 }

private: System::Void Form1_Load(System::Object^  sender, System::EventArgs^  e) {
			
			AppPath = Environment::CurrentDirectory;
			if(!Directory::Exists(AppPath + DIR_PROJECT))
			Directory::CreateDirectory(AppPath + DIR_PROJECT);
			menuStrip1->Show();
			menuStrip2->Show();
			menuStrip4->Show();
			menuStrip5->Show();
		 }


private: System::Void backgroundWorker1_DoWork(System::Object^  sender, System::ComponentModel::DoWorkEventArgs^  e) {


				BackgroundWorker^ bwAsync = dynamic_cast<BackgroundWorker^>(sender);

		
				DumpArgument^ dump_argument = gcnew DumpArgument;
				dump_argument = dynamic_cast <DumpArgument^>(e->Argument);
				if(dump_argument->dumpfs){
				toolStripStatusLabel1->Text = L"Dump running...";
				dump_fs(dump_argument->buffer, dump_argument->path, dump_argument->wave3, bwAsync );
				}else if(dump_argument->dumprc1){
				toolStripStatusLabel1->Text = L"Dump running...";
				dump_RC1(dump_argument->buffer, dump_argument->path, dump_argument->wave3, bwAsync );
				}else if(dump_argument->dumporg){
				toolStripStatusLabel1->Text = L"Dump running...";
				dump_ORG(dump_argument->buffer, dump_argument->path, bwAsync );
				}else if(dump_argument->dumpcsc){
				toolStripStatusLabel1->Text = L"Dump running...";
				dump_CSC(dump_argument->buffer, dump_argument->path, dump_argument->wave3, bwAsync );
				}else if(dump_argument->dumpsmt){
				toolStripStatusLabel1->Text = L"Dump running...";
				dump_SMT(dump_argument->buffer, dump_argument->path, bwAsync );
				}



				//bwAsync->ReportProgress( 0 );


		 }

private: System::Void backgroundWorker1_ProgressChanged(System::Object^  sender, System::ComponentModel::ProgressChangedEventArgs^  e) {

			toolStripProgressBar2->Value = e->ProgressPercentage;

		 }

private: System::Void backgroundWorker1_RunWorkerCompleted(System::Object^  sender, System::ComponentModel::RunWorkerCompletedEventArgs^  e) {


						treeView6->BeginUpdate();
						treeView6->Nodes->Clear();
						TreeNode^ rootNode = gcnew TreeNode( FileName,0,0);
						rootNode->NodeFont = gcnew System::Drawing::Font("Arial",8,System::Drawing::FontStyle::Bold);
						rootNode->Tag = AppPath + DIR_PROJECT + FileName;
						treeView6->Nodes->Add( rootNode);
						treeView6->Sorted = true;

						OpenProject(AppPath + DIR_PROJECT + FileName, rootNode, contextMenuStrip1 );

						treeView6->EndUpdate();
						rootNode->Expand();
						//if(rootNode->LastNode != nullptr){
						if(rootNode->LastNode->Text == L"System")
						rootNode->LastNode->Expand();
						//}
						treeView6->SelectedNode = rootNode;
						treeView6->Focus();

						toolStripStatusLabel1->Text = L"Dump completed...";

		 }

private: System::Void treeView6_NodeMouseClick(System::Object^  sender, System::Windows::Forms::TreeNodeMouseClickEventArgs^  e) {
		NodeMouseClick(e, treeView6, false);
		 }
private: System::Void saveFileToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			SaveFileDialog^ SaveFileDialog1 = gcnew SaveFileDialog;
			SaveFileDialog1->InitialDirectory = Environment::CurrentDirectory;//"c:\\";
//			SaveFileDialog1->Filter="APP files (*.app)|*.app|PFS files (*.pfs)|*.pfs|FFS files (*.ffs)|*.ffs |All files (*.*)|*.*";//|  *.app; *.pfs";
			SaveFileDialog1->Title = L"Save .APP, .FFS, .PFS, files";

			if (SaveFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}

			 Environment::CurrentDirectory = AppPath;
			 String^ SaveFileName = SaveFileDialog1->FileName;

			StartSaveApp (SaveFileName, treeView6 );

		 }
private: System::Void openDumpToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			FolderBrowserDialog^ FolderBrowserDialog1 = gcnew FolderBrowserDialog;
			FolderBrowserDialog1->ShowNewFolderButton = false;
			FolderBrowserDialog1->SelectedPath = Environment::CurrentDirectory;

			if (FolderBrowserDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}

			Environment::CurrentDirectory = AppPath;
			String^ FolderName = FolderBrowserDialog1->SelectedPath;
			
			
			DirectoryInfo^ di = gcnew DirectoryInfo(FolderName);
			//FileName = di->Name;
						
						treeView6->BeginUpdate();
						treeView6->Nodes->Clear();
						TreeNode^ rootNode = gcnew TreeNode( di->Name ,0,0);
						rootNode->NodeFont = gcnew System::Drawing::Font("Arial",8,System::Drawing::FontStyle::Bold);
						rootNode->Tag = FolderName;
						treeView6->Nodes->Add( rootNode);
						treeView6->Sorted = true;

						OpenProject(FolderName, rootNode, contextMenuStrip1);

						treeView6->EndUpdate();
						rootNode->Expand();
						if(rootNode->LastNode->Text == L"System")
						rootNode->LastNode->Expand();			
						treeView6->SelectedNode = rootNode;
						treeView6->Focus();
						
		 }
private: System::Void closeDumpToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

						treeView6->BeginUpdate();
						treeView6->Nodes->Clear();
						treeView6->EndUpdate();
						richTextBox1->Clear();
						richTextBox1->Visible = true;
						pictureBox1->Visible = false;


		 }
private: System::Void backgroundWorker2_DoWork(System::Object^  sender, System::ComponentModel::DoWorkEventArgs^  e) {
		 
				BackgroundWorker^ bwAsync = dynamic_cast<BackgroundWorker^>(sender);

				DumpArgumentSave^ dump_argument = gcnew DumpArgumentSave;
				dump_argument = dynamic_cast <DumpArgumentSave^>(e->Argument);
				toolStripStatusLabel1->Text = L"Save running...";
				if(dump_argument->saveapp){
				Save_file ( dump_argument->SaveFileName, dump_argument->TopNode, bwAsync );
				}else if(dump_argument->saveorg){
				Save_file_org ( dump_argument->SaveFileName, dump_argument->TopNode, bwAsync );
				}else if(dump_argument->savenoncomprcsc){
				Save_file_csc_uncompress ( dump_argument->SaveFileName, dump_argument->TopNode, bwAsync );
				}else if(dump_argument->savenoncomprrc1){
				Save_file_rc1_uncompress ( dump_argument->SaveFileName, dump_argument->TopNode, bwAsync );
				}
				//bwAsync->ReportProgress( 0 );
		 
		 }
private: System::Void backgroundWorker2_ProgressChanged(System::Object^  sender, System::ComponentModel::ProgressChangedEventArgs^  e) {
			toolStripProgressBar2->Value = e->ProgressPercentage;
		 }
private: System::Void backgroundWorker2_RunWorkerCompleted(System::Object^  sender, System::ComponentModel::RunWorkerCompletedEventArgs^  e) {
				
			 toolStripProgressBar2->Value = 0;
			 toolStripStatusLabel1->Text = L"Save completed...";
		 }

private: System::Void treeView6_KeyUp(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {
				KeyUp(e, treeView6, false );
		 }
private: System::Void treeView6_NodeMouseHover(System::Object^  sender, System::Windows::Forms::TreeNodeMouseHoverEventArgs^  e) {
				
			 treeView6->SelectedNode = e->Node;
		 }
private: System::Void backgroundWorker3_DoWork(System::Object^  sender, System::ComponentModel::DoWorkEventArgs^  e) {
						
				BackgroundWorker^ bwAsync1 = dynamic_cast<BackgroundWorker^>(sender);
		
				DumpArgument^ dump_argument = gcnew DumpArgument;
				dump_argument = dynamic_cast <DumpArgument^>(e->Argument);
				toolStripStatusLabel1->Text = L"Dump running...";
				
				dump_rc2(dump_argument->br, dump_argument->path, bwAsync1 );
				
//				bwAsync1->ReportProgress( 0 );

		 }
private: System::Void backgroundWorker3_ProgressChanged(System::Object^  sender, System::ComponentModel::ProgressChangedEventArgs^  e) {

			toolStripProgressBar2->Value = e->ProgressPercentage;
		 }



private: System::Void backgroundWorker3_RunWorkerCompleted(System::Object^  sender, System::ComponentModel::RunWorkerCompletedEventArgs^  e) {
						
						treeView2->BeginUpdate();
						treeView2->Nodes->Clear();
						TreeNode^ rootNode = gcnew TreeNode( ROOT_NAME ,0,0);
						rootNode->Tag = AppPath + DIR_PROJECT + FileNamerc2;
						treeView2->Nodes->Add( rootNode);
						treeView2->Sorted = true;

						OpenProject_rc2(AppPath + DIR_PROJECT + FileNamerc2, rootNode );

						treeView2->EndUpdate();
						rootNode->Expand();
			
						toolStripProgressBar2->Value = 0;
						toolStripStatusLabel1->Text = L"Dump completed...";
		 }

private: System::Void dumpFileRc2ToolStripMenuItem1_Click(System::Object^  sender, System::EventArgs^  e) {
			
			 Stream^ myStream;
			OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;
			openFileDialog1->InitialDirectory = Environment::CurrentDirectory;//"c:\\";
			openFileDialog1->Filter="Firmware files(*.rc2)|*.rc2|All files(*.*)|*.*";//|  *.app; *.pfs";
			openFileDialog1->Title = L"Open .rc2 files";
			//openFileDialog1->FilterIndex = 0;
			//openFileDialog1->RestoreDirectory = true;

			if (openFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}

				 /*String^*/ FileNamerc2 = openFileDialog1->FileName;
				 
				 FileInfo^ fi = gcnew FileInfo( FileNamerc2 );
				 FileNamerc2 = fi->Name;
				 FileNamerc2 = FileNamerc2->Remove(FileNamerc2->Length - 4, 4);
				 Environment::CurrentDirectory = AppPath;
				 
				if ( (myStream = openFileDialog1->OpenFile()) == nullptr ){myStream->Close(); return; }
			 	BinaryReader^ br = gcnew BinaryReader( myStream );

				if(!Directory::Exists(AppPath + DIR_PROJECT + FileNamerc2))
				Directory::CreateDirectory(AppPath + DIR_PROJECT + FileNamerc2);

				StartDumprc2(br, FileNamerc2);
		 }

/*private: System::Void tabControl1_MouseClick(System::Object^  sender, System::Windows::Forms::MouseEventArgs^  e) {

			Point PtClick = Point(e->X, e->Y);
				if (tabControl1->GetTabRect(0).Contains(PtClick))
				{
				//this->menuStrip1->Show();//PointToScreen(PtClick));
//				this->menuStrip3->Show();				
				//this->menuStrip4->Show();				
				//this->menuStrip5->Show();				
				}
				if (tabControl1->GetTabRect(1).Contains(PtClick))
				{
				this->menuStrip1->Show();//PointToScreen(PtClick));
				//this->menuStrip3->Show();				
				this->menuStrip4->Show();				
				this->menuStrip5->Show();				
				}

				if (tabControl1->GetTabRect(2).Contains(PtClick))
				{
				this->menuStrip2->Show();//PointToScreen(PtClick));
				}
//
//				if (tabControl1->GetTabRect(2).Contains(PtClick))
//				{
//				this->menuStrip3->Show();//PointToScreen(PtClick));
//				}

//				if (tabControl1->GetTabRect(3).Contains(PtClick))
//				{
//				this->menuStrip2->Show();//PointToScreen(PtClick));
//				}

		 }
*/
private: System::Void treeView2_DragDrop(System::Object^  sender, System::Windows::Forms::DragEventArgs^  e) {

			 if ( !e->Data->GetDataPresent(DataFormats::FileDrop)){	return; }
			 
			array<String ^> ^aFiles = dynamic_cast<array<String^>^ >(e->Data->GetData(DataFormats::FileDrop)); 				
			String^ FileDrop = aFiles[0];

			if(!treeView2->GetNodeCount(true) && Path::GetExtension(FileDrop) == ".rc2" ){

				FileInfo^ fi = gcnew FileInfo(FileDrop);
				FileNamerc2 = fi->Name->Replace(Path::GetExtension(FileDrop), "");

				BinaryReader^ br = gcnew BinaryReader( File::Open(FileDrop, FileMode::Open));
				if(!Directory::Exists(AppPath + DIR_PROJECT + FileNamerc2))
				Directory::CreateDirectory(AppPath + DIR_PROJECT + FileNamerc2);

				StartDumprc2(br, FileNamerc2);

			}

		 }
private: System::Void treeView2_DragOver(System::Object^  sender, System::Windows::Forms::DragEventArgs^  e) {
			
			 treeView2->Focus();
			 e->Effect = e->Data->GetDataPresent(DataFormats::FileDrop) ? DragDropEffects::Copy : DragDropEffects::None;

		 }
private: System::Void treeView2_NodeMouseClick(System::Object^  sender, System::Windows::Forms::TreeNodeMouseClickEventArgs^  e) {

		if(e->Node->FullPath == L"FW"){return;}
		treeView2->SelectedNode = e->Node;
		String^ path_rc2 = static_cast <String^> (e->Node->Tag);
		FileInfo^ fi = gcnew FileInfo(path_rc2);
		//String^ name = fi->Name;
		array<String^>^ delim = gcnew array<String^>(2){" ","x"};
		array<String^>^ split = fi->Name->Split(delim, StringSplitOptions::RemoveEmptyEntries);
		
		int width = Convert::ToInt32(split[1]);
		int height = Convert::ToInt32(split[2]);

		Bitmap^ bmp = LoadBitmap(width, height, path_rc2);

			pictureBox4->Image = dynamic_cast<Image^>(bmp);
			pictureBox4->Tag = path_rc2;
		 }

private: System::Void openDumpRc2ToolStripMenuItem1_Click(System::Object^  sender, System::EventArgs^  e) {

			FolderBrowserDialog^ FolderBrowserDialog1 = gcnew FolderBrowserDialog;
			FolderBrowserDialog1->ShowNewFolderButton = false;
			FolderBrowserDialog1->SelectedPath = Environment::CurrentDirectory;

			if (FolderBrowserDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}

			 Environment::CurrentDirectory = AppPath;
			 String^ FolderName = FolderBrowserDialog1->SelectedPath;


						treeView2->BeginUpdate();
						treeView2->Nodes->Clear();
						TreeNode^ rootNode = gcnew TreeNode( ROOT_NAME ,0,0);
						rootNode->Tag = FolderName;
						treeView2->Nodes->Add( rootNode);
						treeView2->Sorted = true;

						OpenProject_rc2(FolderName, rootNode/*, contextMenuStrip1*/);

						treeView2->EndUpdate();
						rootNode->Expand();
						treeView2->SelectedNode = rootNode;
						treeView2->Focus();

		 }

private: System::Void openImageToolStripMenuItem_Click_1(System::Object^  sender, System::EventArgs^  e) {

						 
			OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;
			openFileDialog1->InitialDirectory = Environment::CurrentDirectory;
			openFileDialog1->Filter="Bmp files(*.bmp)|*.bmp";//|  *.app; *.pfs";
			openFileDialog1->Title = L"Open image files";

			if (openFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}

				 String^ FileNameimg = openFileDialog1->FileName;
				 Environment::CurrentDirectory = AppPath;
				 
				pictureBox5->Load(FileNameimg);
				pictureBox5->Tag = FileNameimg;
		 }

private: System::Void changeImageToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			if(pictureBox4->Tag == nullptr || pictureBox5->Tag == nullptr){return;}
			
			if(	treeView2->SelectedNode == nullptr){return;}
			
			String^ FileNameChange/*FileNamerc2*/ = dynamic_cast <String^>(treeView2->SelectedNode->Tag);

			FileInfo^ fi = gcnew FileInfo(FileNameChange);
			array<String^>^ delim = gcnew array<String^>(2){" ","x"};
			array<String^>^ split = fi->Name->Split(delim, StringSplitOptions::RemoveEmptyEntries);
			


			int width = Convert::ToInt32(split[1]);
			int height = Convert::ToInt32(split[2]);

			Bitmap^ bmp = gcnew Bitmap( dynamic_cast <String^>(pictureBox5->Tag) );

			if(width != bmp->Width || height != bmp->Height){return;}

		   // Lock the bitmap's bits.  
		   Rectangle rect = Rectangle(0,0,bmp->Width,bmp->Height);
		   System::Drawing::Imaging::BitmapData^ bmpData = bmp->LockBits( rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, bmp->PixelFormat );

		   // Get the address of the first line.
		   IntPtr ptr = bmpData->Scan0;

		   // Declare an array to hold the bytes of the bitmap.
		   // This code is specific to a bitmap with 24 bits per pixels.
			int bytes = Math::Abs(bmpData->Stride) * bmp->Height;
			array<Byte>^rgbValues = gcnew array<Byte>(bytes);

		   // Copy the RGB values into the array.
		   System::Runtime::InteropServices::Marshal::Copy( ptr, rgbValues, 0, bytes );

//////////////////////////////////////
			//int counter = 0;
            array<unsigned char>^destinationData = gcnew array<unsigned char>(2);
			BinaryWriter^ bw = gcnew BinaryWriter(File::Create(FileNameChange));
            for (int x = 0; x < rgbValues->Length; x = x + 3)
            {
                Byte red = rgbValues[x];
                Byte green = rgbValues[x + 1];
                Byte blue = rgbValues[x + 2];

                short rgb16_val = RGB16(blue/*red*/, green, red/*blue*/);
                destinationData =BitConverter::GetBytes( rgb16_val);
                bw->BaseStream->Write(destinationData, 0, destinationData->Length);
				//counter++;
            }
				bw->Close();
//////////////////////////////////////
			
			Bitmap^ bmp1 = LoadBitmap(width, height, FileNameChange);

			pictureBox4->Image = dynamic_cast<Image^>(bmp1);
			pictureBox4->Tag = FileNameChange;
		 
		 }

private: System::Void debugLToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {


			 if(!treeView2->GetNodeCount(true)){return;}
			SaveFileDialog^ SaveFileDialog1 = gcnew SaveFileDialog;
			SaveFileDialog1->InitialDirectory = Environment::CurrentDirectory;//"c:\\";
			SaveFileDialog1->Filter="Firmware files (*.rc2)|*.rc2|All files (*.*)|*.*";//|  *.app; *.pfs";
			SaveFileDialog1->Title = L"Save .RC2 files";
			SaveFileDialog1->FilterIndex = 1;
			//openFileDialog1->RestoreDirectory = true;

			if (SaveFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}

			 Environment::CurrentDirectory = AppPath;
			 String^ SaveFileName = SaveFileDialog1->FileName;

			WriteRC2(/*dump_argument*/SaveFileName, static_cast<String^>(treeView2->TopNode->Tag), AppPath + DIR_PROJECT + FileNamerc2, 0);

		 }

private: System::Void debugLevel1ToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			 if(!treeView2->GetNodeCount(true)){return;}
			SaveFileDialog^ SaveFileDialog1 = gcnew SaveFileDialog;
			SaveFileDialog1->InitialDirectory = Environment::CurrentDirectory;//"c:\\";
			SaveFileDialog1->Filter="Firmware files (*.rc2)|*.rc2|All files (*.*)|*.*";//|  *.app; *.pfs";
			SaveFileDialog1->Title = L"Save .RC2 files";
			SaveFileDialog1->FilterIndex = 1;
			//openFileDialog1->RestoreDirectory = true;

			if (SaveFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}

			 Environment::CurrentDirectory = AppPath;
			 String^ SaveFileName = SaveFileDialog1->FileName;

			WriteRC2(/*dump_argument*/SaveFileName, static_cast<String^>(treeView2->TopNode->Tag), AppPath + DIR_PROJECT + FileNamerc2,1);

		 }
private: System::Void debugLevel2ToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			 if(!treeView2->GetNodeCount(true)){return;}
			SaveFileDialog^ SaveFileDialog1 = gcnew SaveFileDialog;
			SaveFileDialog1->InitialDirectory = Environment::CurrentDirectory;
			SaveFileDialog1->Filter="Firmware files (*.rc2)|*.rc2|All files (*.*)|*.*";
			SaveFileDialog1->Title = L"Save .RC2 files";
			SaveFileDialog1->FilterIndex = 1;
			//openFileDialog1->RestoreDirectory = true;

			if (SaveFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}

			 Environment::CurrentDirectory = AppPath;
			 String^ SaveFileName = SaveFileDialog1->FileName;

			WriteRC2(/*dump_argument*/SaveFileName, static_cast<String^>(treeView2->TopNode->Tag), AppPath + DIR_PROJECT + FileNamerc2, 2);

		 }
private: System::Void backgroundWorker4_ProgressChanged(System::Object^  sender, System::ComponentModel::ProgressChangedEventArgs^  e) {

			toolStripProgressBar2->Value = e->ProgressPercentage;

		 }
private: System::Void backgroundWorker4_RunWorkerCompleted(System::Object^  sender, System::ComponentModel::RunWorkerCompletedEventArgs^  e) {
		 
			 toolStripProgressBar2->Value = 0;
			 toolStripStatusLabel1->Text = L"Completed...";

		 }
private: System::Void backgroundWorker4_DoWork(System::Object^  sender, System::ComponentModel::DoWorkEventArgs^  e) {

				BackgroundWorker^ bwAsync = dynamic_cast<BackgroundWorker^>(sender);
		
				DumpArgumentSave^ dump_argument = gcnew DumpArgumentSave;
				dump_argument = dynamic_cast <DumpArgumentSave^>(e->Argument);
				
				if(dump_argument->decrypt){
				toolStripStatusLabel1->Text = L"Decrypt running...";
				DecryptSeed(dump_argument->path, dump_argument->SaveFileName, dump_argument->wave3, bwAsync);
				}
				else if(dump_argument->imgCompress){
				toolStripStatusLabel1->Text = L"Img convert running...";
				IMG_Compress(dump_argument->path, dump_argument->SaveFileName, bwAsync);
				}
				else if(dump_argument->encrypt){
				toolStripStatusLabel1->Text = L"Encrypt running...";
				EncryptSeed(dump_argument->path, dump_argument->SaveFileName, dump_argument->wave3, bwAsync);
				}
				else if(dump_argument->decrypt_decompress){
				toolStripStatusLabel1->Text = L"Decrypt and Decompress running...";
				Decrypt_Decompress(dump_argument->path, dump_argument->SaveFileName, bwAsync);
				}
				else if(dump_argument->decompress){
				toolStripStatusLabel1->Text = L"Decompress running...";
				Decompression(dump_argument->path, dump_argument->SaveFileName, bwAsync);
				}
				else if(dump_argument->sign){
				toolStripStatusLabel1->Text = L"Sign running...";
				autosign_file(dump_argument->path);
				}
				else if(dump_argument->save_images){
				toolStripStatusLabel1->Text = L"Save image running...";
				Save_Image(dump_argument->path, dump_argument->SaveFileName, bwAsync);
				}
				else if(dump_argument->decode_folder){
				toolStripStatusLabel1->Text = L"Decode folder running...";
				Decode_Folder(dump_argument->path, dump_argument->SaveFileName, dump_argument->ext, bwAsync);
				}
				else if(dump_argument->encode_folder){
				toolStripStatusLabel1->Text = L"Encode folder running...";
				Encode_Folder(dump_argument->path, dump_argument->SaveFileName, dump_argument->ext, bwAsync);
				}
				//else if(dump_argument->view_rbm){
				//toolStripStatusLabel1->Text = L"View .rbm running...";
				//ViewRBM(dump_argument->path, dump_argument->data_grid );
				//}

		 }
private: System::Void deleteToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

				if( System::Windows::Forms::DialogResult::No == MessageBox::Show("Delete?", "Delete", MessageBoxButtons::YesNo,MessageBoxIcon::Question)){return;}
				
				String^ NodeName = static_cast <String^> (treeView6->SelectedNode->Tag);

				if (File::Exists(NodeName)){
				File::Delete(NodeName );
				treeView6->Nodes->Remove(treeView6->SelectedNode);
				
				}else if (Directory::Exists (NodeName)){
				Directory::Delete(NodeName, true);
				treeView6->Nodes->Remove(treeView6->SelectedNode);
				}
		 }
private: System::Void closeDumpRc2ToolStripMenuItem2_Click(System::Object^  sender, System::EventArgs^  e) {

						treeView2->BeginUpdate();
						treeView2->Nodes->Clear();
						treeView2->EndUpdate();

		 }
private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {

				OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;
				openFileDialog1->InitialDirectory = Environment::CurrentDirectory;

				if (openFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){Environment::CurrentDirectory = AppPath;return;}
				Environment::CurrentDirectory = AppPath;

				SaveFileDialog^ SaveFileDialog1 = gcnew SaveFileDialog;
				SaveFileDialog1->InitialDirectory = Environment::CurrentDirectory;

				if (SaveFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){Environment::CurrentDirectory = AppPath; return;}
				Environment::CurrentDirectory = AppPath;
				
				Start_Decrypt(openFileDialog1->FileName, SaveFileDialog1->FileName);
				
		 }

private: System::Void saveAsORGToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			SaveFileDialog^ SaveFileDialog1 = gcnew SaveFileDialog;
			SaveFileDialog1->InitialDirectory = Environment::CurrentDirectory;//"c:\\";
			SaveFileDialog1->Title = L"Save .org files";

			if (SaveFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}

			 Environment::CurrentDirectory = AppPath;
			 String^ SaveFileName = SaveFileDialog1->FileName;

			StartSaveOrg (SaveFileName, treeView6 );

		 }
private: System::Void deleteToolStripMenuItem1_Click(System::Object^  sender, System::EventArgs^  e) {

				if( System::Windows::Forms::DialogResult::No == MessageBox::Show("Delete?", "Delete", MessageBoxButtons::YesNo,MessageBoxIcon::Question)){return;}

				String^ NodeName = static_cast <String^> (treeView6->SelectedNode->Tag);
				if (File::Exists(NodeName)){
				File::Delete(NodeName );
				treeView6->Nodes->Remove(treeView6->SelectedNode);
				
				}else if (Directory::Exists (NodeName)){
				Directory::Delete(NodeName, true);
				treeView6->Nodes->Remove(treeView6->SelectedNode);

				}

		 }
private: System::Void button4_Click_1(System::Object^  sender, System::EventArgs^  e) {

				 OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;
				openFileDialog1->InitialDirectory = Environment::CurrentDirectory;

				if (openFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){Environment::CurrentDirectory = AppPath;return;}
				Environment::CurrentDirectory = AppPath;
				
				SaveFileDialog^ SaveFileDialog1 = gcnew SaveFileDialog;
				SaveFileDialog1->InitialDirectory = Environment::CurrentDirectory;

				if (SaveFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){Environment::CurrentDirectory = AppPath; return;}
				Environment::CurrentDirectory = AppPath;

				Start_Decrypt_Decompress(openFileDialog1->FileName, SaveFileDialog1->FileName);

		 }
private: System::Void button10_Click(System::Object^  sender, System::EventArgs^  e) {
				 
				OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;
				openFileDialog1->InitialDirectory = Environment::CurrentDirectory;

				if (openFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){Environment::CurrentDirectory = AppPath;return;}
				Environment::CurrentDirectory = AppPath;
				
				SaveFileDialog^ SaveFileDialog1 = gcnew SaveFileDialog;
				SaveFileDialog1->InitialDirectory = Environment::CurrentDirectory;

				if (SaveFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){Environment::CurrentDirectory = AppPath;return;}
				Environment::CurrentDirectory = AppPath;
				
				Start_Encrypt(openFileDialog1->FileName, SaveFileDialog1->FileName);
		 }
private: System::Void button11_Click(System::Object^  sender, System::EventArgs^  e) {
		
				OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;
				openFileDialog1->InitialDirectory = Environment::CurrentDirectory;

				if (openFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){Environment::CurrentDirectory = AppPath;return;}
				Environment::CurrentDirectory = AppPath;
				Start_Sign(openFileDialog1->FileName);

		 }
private: System::Void treeView6_DragDrop(System::Object^  sender, System::Windows::Forms::DragEventArgs^  e) {
						
//			 int g = treeView6->GetNodeCount(false);
//			int h = 0;

			 
			 DragDrop(e, treeView6, L"");
		 }
private: System::Void treeView6_DragOver(System::Object^  sender, System::Windows::Forms::DragEventArgs^  e) {
		
		treeView6->Focus();
		if(e->Data->GetDataPresent(DataFormats::FileDrop)){
		e->Effect = e->Data->GetDataPresent(DataFormats::FileDrop) ? DragDropEffects::Copy : DragDropEffects::None;
		}else if(e->Data->GetDataPresent(DataFormats::StringFormat)){
		e->Effect = e->Data->GetDataPresent(DataFormats::StringFormat) ? DragDropEffects::Copy : DragDropEffects::None;
		}
		
		Point pt = Point(e->X, e->Y);
        pt = treeView6->PointToClient(pt);
        TreeNode^ nodeTarget = treeView6->GetNodeAt(pt);
        if (nodeTarget != nullptr && 0 == nodeTarget->ImageIndex)
        {
          treeView6->SelectedNode = nodeTarget;
		}else{
		  treeView6->SelectedNode = nullptr;

		}

		 }

private: System::Void treeView7_DragDrop(System::Object^  sender, System::Windows::Forms::DragEventArgs^  e) {
			
			 DragDrop(e, treeView7, DONOR);
		 }		 
private: System::Void treeView7_DragOver(System::Object^  sender, System::Windows::Forms::DragEventArgs^  e) {
		
		treeView7->Focus();
		e->Effect = e->Data->GetDataPresent(DataFormats::FileDrop) ? DragDropEffects::Copy : DragDropEffects::None;
		 

		Point pt = Point(e->X, e->Y);
        pt = treeView7->PointToClient(pt);
        TreeNode^ nodeTarget = treeView7->GetNodeAt(pt);
        if (nodeTarget != nullptr && 0 == nodeTarget->ImageIndex)
        {
          treeView7->SelectedNode = nodeTarget;
        }


		 }
private: System::Void backgroundWorker5_DoWork(System::Object^  sender, System::ComponentModel::DoWorkEventArgs^  e) {
		 
				BackgroundWorker^ bwAsync = dynamic_cast<BackgroundWorker^>(sender);
				DumpArgument^ dump_argument = gcnew DumpArgument;
				dump_argument = dynamic_cast <DumpArgument^>(e->Argument);
				if(dump_argument->dumpfs){
				toolStripStatusLabel1->Text = L"Dump running...";
				dump_fs(dump_argument->buffer, dump_argument->path, dump_argument->wave3, bwAsync );
				}else if(dump_argument->dumprc1){
				toolStripStatusLabel1->Text = L"Dump running...";
				dump_RC1(dump_argument->buffer, dump_argument->path, dump_argument->wave3, bwAsync );
				}else if(dump_argument->dumporg){
				toolStripStatusLabel1->Text = L"Dump running...";
				dump_ORG(dump_argument->buffer, dump_argument->path, bwAsync );
				}else if(dump_argument->dumpcsc){
				toolStripStatusLabel1->Text = L"Dump running...";
				dump_CSC(dump_argument->buffer, dump_argument->path, dump_argument->wave3, bwAsync );
				}else if(dump_argument->dumpsmt){
				toolStripStatusLabel1->Text = L"Dump running...";
				dump_SMT(dump_argument->buffer, dump_argument->path, bwAsync );
				}



				//bwAsync->ReportProgress( 0 );		 
		 
		 }
private: System::Void backgroundWorker5_ProgressChanged(System::Object^  sender, System::ComponentModel::ProgressChangedEventArgs^  e) {
			toolStripProgressBar2->Value = e->ProgressPercentage;
		
		 }
private: System::Void backgroundWorker5_RunWorkerCompleted(System::Object^  sender, System::ComponentModel::RunWorkerCompletedEventArgs^  e) {
						
						treeView7->BeginUpdate();
						treeView7->Nodes->Clear();
						TreeNode^ rootNode = gcnew TreeNode( FileName,0,0);
						rootNode->NodeFont = gcnew System::Drawing::Font("Arial",8,System::Drawing::FontStyle::Bold);
						rootNode->Tag = AppPath + DIR_PROJECT + DONOR + FileName;
						treeView7->Nodes->Add( rootNode);
						treeView7->Sorted = true;

						OpenProject(AppPath + DIR_PROJECT + DONOR + FileName, rootNode, contextMenuStrip3 );

						treeView7->EndUpdate();
						rootNode->Expand();
						if(rootNode->LastNode->Text == L"System")
						rootNode->LastNode->Expand();

						treeView7->SelectedNode = rootNode;
						treeView7->Focus();

						toolStripStatusLabel1->Text = L"Dump completed...";
		 
		 }
private: System::Void treeView7_KeyUp(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {
			KeyUp(e, treeView7, true );		
		 }
private: System::Void treeView7_NodeMouseClick(System::Object^  sender, System::Windows::Forms::TreeNodeMouseClickEventArgs^  e) {
			NodeMouseClick(e, treeView7, true);
		 }
private: System::Void treeView7_NodeMouseHover(System::Object^  sender, System::Windows::Forms::TreeNodeMouseHoverEventArgs^  e) {
			
			 treeView7->SelectedNode = e->Node;
		 }


private: System::Void deleteItLanguageToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			int selcolumn = dataGridView1->CurrentCell->ColumnIndex;
			for(int i =0; i<dataGridView1->RowCount; i++)
			dataGridView1->Rows[i]->Cells[selcolumn]->Selected = true;

			if(Windows::Forms::DialogResult::OK != MessageBox::Show("Are you sure?", "Delete language",  MessageBoxButtons::OKCancel, MessageBoxIcon::Question, MessageBoxDefaultButton::Button2)){return;}
			dataGridView1->Columns->RemoveAt(selcolumn);				
			
		 }
private: System::Void dataGridView1_CellMouseDown(System::Object^  sender, System::Windows::Forms::DataGridViewCellMouseEventArgs^  e) {
			
			 if(e->RowIndex < 0 | e->ColumnIndex < 0){return;}
			dataGridView1->CurrentCell->Selected = false;
			dataGridView1->Rows[e->RowIndex]->Cells[e->ColumnIndex]->Selected = true;
			dataGridView1->CurrentCell = dataGridView1->SelectedCells[0]; 
		 }
private: System::Void saveChangesToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			 if(dataGridView1->Visible == true){
				if(Windows::Forms::DialogResult::OK != MessageBox::Show("Are you sure?", "Save changes",  MessageBoxButtons::OKCancel, MessageBoxIcon::Question, MessageBoxDefaultButton::Button2)){return;}
					SaveRSR(dataGridView1);
			 }else if(richTextBox1->Visible == true){
				if(Windows::Forms::DialogResult::OK != MessageBox::Show("Are you sure?", "Save changes",  MessageBoxButtons::OKCancel, MessageBoxIcon::Question, MessageBoxDefaultButton::Button2)){return;}
				richTextBox1->SaveFile(static_cast <String^>( richTextBox1->Tag),RichTextBoxStreamType::PlainText);
			 }if(pictureBox1->Visible == true){
					SavePicture(pictureBox1);
			 }
		 }
private: System::Void sToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			SaveFileDialog^ SaveFileDialog1 = gcnew SaveFileDialog;
			SaveFileDialog1->InitialDirectory = Environment::CurrentDirectory;//"c:\\";
//			SaveFileDialog1->Filter="APP files (*.app)|*.app|PFS files (*.pfs)|*.pfs|FFS files (*.ffs)|*.ffs |All files (*.*)|*.*";//|  *.app; *.pfs";
			SaveFileDialog1->Title = L"Save .csc files";
//			SaveFileDialog1->FilterIndex = 1;

			if (SaveFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}
			 Environment::CurrentDirectory = AppPath;
			 String^ SaveFileName = SaveFileDialog1->FileName;

			StartSaveNonComprCsc (SaveFileName, treeView6 );


		 }
private: System::Void treeView7_ItemDrag(System::Object^  sender, System::Windows::Forms::ItemDragEventArgs^  e) {
			 
			TreeNode^ treenode =  static_cast<TreeNode^>(e->Item);
			this->treeView7->DoDragDrop(gcnew DataObject(DataFormats::FileDrop, treenode/*e->Item*/), DragDropEffects::Copy );
		
		 }
private: System::Void treeView7_QueryContinueDrag(System::Object^  sender, System::Windows::Forms::QueryContinueDragEventArgs^  e) {
         
		TreeView^ tw = static_cast<TreeView^>(sender);
         if ( tw != nullptr )
         {
            Form^ f = tw->FindForm();
			if ( ((Control::MousePosition.X - screenOffset.X) < f->DesktopBounds.Left)
				|| ((Control::MousePosition.X - screenOffset.X) > f->DesktopBounds.Left + this->splitContainer8->SplitterDistance + this->splitContainer9->SplitterDistance)
				|| ((Control::MousePosition.Y - screenOffset.Y) < f->DesktopBounds.Top)
				|| ((Control::MousePosition.Y - screenOffset.Y) > f->DesktopBounds.Bottom)
				|| treeView6->Nodes->Count == false
				|| treeView7->SelectedNode->Parent == nullptr
)
            {
               e->Action = DragAction::Cancel;
            }
         }


		 }
private: System::Void button15_Click(System::Object^  sender, System::EventArgs^  e) {

				OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;
				openFileDialog1->InitialDirectory = Environment::CurrentDirectory;

				if (openFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){Environment::CurrentDirectory = AppPath;return;}
				Environment::CurrentDirectory = AppPath;
				
				SaveFileDialog^ SaveFileDialog1 = gcnew SaveFileDialog;
				SaveFileDialog1->InitialDirectory = Environment::CurrentDirectory;

				if (SaveFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){Environment::CurrentDirectory = AppPath; return;}
				Environment::CurrentDirectory = AppPath;

				Start_Decompress (openFileDialog1->FileName, SaveFileDialog1->FileName);

		 }


private: System::Void deleteItIDSToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			int selrow = dataGridView1->CurrentCell->RowIndex;
			for(int i =0; i<dataGridView1->ColumnCount; i++)
			dataGridView1->Rows[selrow]->Cells[i]->Selected = true;

			if(Windows::Forms::DialogResult::OK != MessageBox::Show("Are you sure?", "Delete language",  MessageBoxButtons::OKCancel, MessageBoxIcon::Question, MessageBoxDefaultButton::Button2)){return;}
			dataGridView1->Rows->RemoveAt(selrow);	


		 }

private: System::Void addIDSToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			dataGridView1->Rows->Add();
			dataGridView1->Rows[dataGridView1->RowCount - 1]->HeaderCell->Value = Convert::ToString(dataGridView1->RowCount - 1);
						
			for(unsigned int l=0; l<dataGridView1->ColumnCount; l++){
					dataGridView1[l, dataGridView1->RowCount-1]->Value = L"0";//RSR->ArrayStringHeaders[x]->strings[l];
				}

		 }

private: System::Void addLanguageToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
		 
				LanguageID^ IDform = gcnew LanguageID();
				if(IDform->ShowDialog()!= System::Windows::Forms::DialogResult::OK){return;}
				String^ LID = IDform->TBX1;
			 
					for(int i =0; i<dataGridView1->ColumnCount; i++)
						if(dataGridView1->Columns[i]->Name == LID){MessageBox::Show("This ID is already", "ERROR",  MessageBoxButtons::OK, MessageBoxIcon::Error, MessageBoxDefaultButton::Button1); return;}
			 
				dataGridView1->Columns->Add(LID,LID);
					
				for(unsigned int l=0; l<dataGridView1->RowCount; l++){
					dataGridView1[dataGridView1->ColumnCount-1,l]->Value = L"0";//RSR->ArrayStringHeaders[x]->strings[l];
				}


		 }

private: System::Void dataGridView1_CellDoubleClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
			
				dataGridView1->BeginEdit(true);
				//int f = 0;
		 }


private: System::Void exportLanguageTotxtToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			SaveFileDialog^ SaveFileDialog1 = gcnew SaveFileDialog;
			SaveFileDialog1->InitialDirectory = Environment::CurrentDirectory;//"c:\\";
//			SaveFileDialog1->Filter="APP files (*.app)|*.app|PFS files (*.pfs)|*.pfs|FFS files (*.ffs)|*.ffs |All files (*.*)|*.*";//|  *.app; *.pfs";
			SaveFileDialog1->Title = L"Export .language";

			if (SaveFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}

			 Environment::CurrentDirectory = AppPath;
			 String^ SaveFileLanguage = SaveFileDialog1->FileName;
			 
			 int selcolumn = dataGridView1->CurrentCell->ColumnIndex;
			
			String^ LanguageID = dataGridView1->Columns[ selcolumn ]->Name;
			
			TextWriter^ tw = gcnew StreamWriter (File::Create (SaveFileLanguage));
			tw->WriteLine(L"[Language ID]");
			tw->WriteLine(LanguageID);
			tw->WriteLine();

			tw->WriteLine(L"[Count Strings]");
			tw->WriteLine(dataGridView1->RowCount);
			tw->WriteLine();

				for(int i =0; i<dataGridView1->RowCount; i++){
				
				String^ readIDS = dynamic_cast< String^>(dataGridView1->Rows[i]->Cells[0]->Value);
				tw->WriteLine(readIDS);
				String^ readstring = dynamic_cast< String^>(dataGridView1->Rows[i]->Cells[selcolumn]->Value);
				tw->WriteLine(L"~<" + readstring + L">~");
				tw->WriteLine();
			
			}
				
				tw->Close();


		 }
private: System::Void importLanguageFromtxtToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			//Environment::CurrentDirectory = AppPath;			
			OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;
			openFileDialog1->InitialDirectory = Environment::CurrentDirectory;
			openFileDialog1->Filter="Txt files(*.txt)|*.txt";//|  *.app; *.pfs";
			openFileDialog1->Title = L"Open .txt files";

			if (openFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}

			String^ FileNametxt = openFileDialog1->FileName;
			Environment::CurrentDirectory = AppPath;
			 
			 
			TextReader^ tr = gcnew StreamReader(File::OpenRead(FileNametxt));
			tr->ReadLine();
			String^ LanguageID = tr->ReadLine();
			
			tr->ReadLine();
			tr->ReadLine();
			unsigned int count = UInt32::Parse(tr->ReadLine(), System::Globalization::NumberStyles::Integer);
			int selcolumn = dataGridView1->CurrentCell->ColumnIndex;
			tr->ReadLine();

			dataGridView1->Columns[ selcolumn ]->Name =LanguageID ;

				
					String^ AllTxt = tr->ReadToEnd();
					array<String^>^ delim = gcnew array<String^>(2){L"~<",L">~"};
					array<String^>^ split = AllTxt->Split(delim, StringSplitOptions::None);
				
					if(split->Length/2 != dataGridView1->Rows->Count){
					System::Windows::Forms::MessageBox::Show("Error rows count.","ERROR",MessageBoxButtons::OK, MessageBoxIcon::Error);
					return ;
					}


				for(int i =0; i<count; i++){
					
					//tr->ReadLine();
					dataGridView1->Rows[i]->Cells[selcolumn]->Value = split[(i<<1)+1];//tr->ReadLine();
					//tr->ReadLine();
			
			}
			tr->Close();
		 }
private: System::Void saveAsNonCompressedrc1ToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

//			Environment::CurrentDirectory = AppPath;			
			SaveFileDialog^ SaveFileDialog1 = gcnew SaveFileDialog;
			SaveFileDialog1->InitialDirectory = Environment::CurrentDirectory;//"c:\\";
//			SaveFileDialog1->Filter="APP files (*.app)|*.app|PFS files (*.pfs)|*.pfs|FFS files (*.ffs)|*.ffs |All files (*.*)|*.*";//|  *.app; *.pfs";
			SaveFileDialog1->Title = L"Save .rc1 files";
//			SaveFileDialog1->FilterIndex = 1;

			if (SaveFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}
			 Environment::CurrentDirectory = AppPath;
			 String^ SaveFileName = SaveFileDialog1->FileName;

			StartSaveNonComprRC1 (SaveFileName, treeView6 );


		 }
private: System::Void copyToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {
				 
			 Clipboard::SetText( richTextBox1->SelectedText );
		 }
private: System::Void deleteToolStripMenuItem2_Click(System::Object^  sender, System::EventArgs^  e) {
	
			 richTextBox1->SelectedText = "";		 
		 }
private: System::Void pasteToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			 richTextBox1->SelectedText = Clipboard::GetText(TextDataFormat::Text);
		 }
private: System::Void cutToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			 Clipboard::SetText( richTextBox1->SelectedText );
			 richTextBox1->SelectedText = "";		 
		 }

private: System::Void contextMenuStrip3_Opening(System::Object^  sender, System::ComponentModel::CancelEventArgs^  e) {
			
			copyToolStripMenuItem->Enabled = false;
			pasteToolStripMenuItem->Enabled = false;
			deleteToolStripMenuItem2->Enabled = false;
			cutToolStripMenuItem->Enabled = false;

			if (Clipboard::ContainsText(TextDataFormat::Text))
					pasteToolStripMenuItem->Enabled = true;

			if (richTextBox1->SelectionLength > 0 ){
					copyToolStripMenuItem->Enabled = true;
					pasteToolStripMenuItem->Enabled = true;
					deleteToolStripMenuItem2->Enabled = true;
					cutToolStripMenuItem->Enabled = true;
			}
		 }
private: System::Void dataGridView1_VisibleChanged(System::Object^  sender, System::EventArgs^  e) {
			 if(dataGridView1->Visible == true){
//			this->fileToolStripMenuItem4->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->saveChangesToolStripMenuItem});
			this->saveChangesToolStripMenuItem->Name = L"saveChangesToolStripMenuItem";
			this->saveChangesToolStripMenuItem->Size = System::Drawing::Size(152, 22);
			this->saveChangesToolStripMenuItem->Text = L"Save changes";
//			this->saveChangesToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::saveChangesToolStripMenuItem_Click);

			 }


		 }
private: System::Void pictureBox1_VisibleChanged(System::Object^  sender, System::EventArgs^  e) {
			 if(pictureBox1->Visible == true){
//			this->fileToolStripMenuItem4->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->saveChangesToolStripMenuItem});
			this->saveChangesToolStripMenuItem->Name = L"saveChangesToolStripMenuItem";
			this->saveChangesToolStripMenuItem->Size = System::Drawing::Size(152, 22);
			this->saveChangesToolStripMenuItem->Text = L"Save image as (.bmp, .png, .jpeg)";
//			this->saveChangesToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::saveChangesToolStripMenuItem_Click);

			 }

		 }
private: System::Void richTextBox1_VisibleChanged(System::Object^  sender, System::EventArgs^  e) {
			 if(richTextBox1->Visible == true){
//			this->fileToolStripMenuItem4->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) {this->saveChangesToolStripMenuItem});
			this->saveChangesToolStripMenuItem->Name = L"saveChangesToolStripMenuItem";
			this->saveChangesToolStripMenuItem->Size = System::Drawing::Size(152, 22);
			this->saveChangesToolStripMenuItem->Text = L"Save changes";
//			this->saveChangesToolStripMenuItem->Click += gcnew System::EventHandler(this, &Form1::saveChangesToolStripMenuItem_Click);

			 }
		
		 }
private: System::Void button5_Click_1(System::Object^  sender, System::EventArgs^  e) {

			OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;
			openFileDialog1->InitialDirectory = Environment::CurrentDirectory;
			openFileDialog1->Filter="BMP files (*.bmp)|*.bmp|PNG files (*.png)|*.png|JPG files (*.jpg)|*.jpg|All files (*.*)|*.*";


			if (openFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){Environment::CurrentDirectory = AppPath;return;}
			Environment::CurrentDirectory = AppPath;
				
			SaveFileDialog^ SaveFileDialog1 = gcnew SaveFileDialog;
			SaveFileDialog1->InitialDirectory = Environment::CurrentDirectory;//"c:\\";
			SaveFileDialog1->Filter="IMG files (*.img)|*.img|All files (*.*)|*.*";
			SaveFileDialog1->Title = L"Save as .img";

			if (SaveFileDialog1->ShowDialog()!= System::Windows::Forms::DialogResult::OK){Environment::CurrentDirectory = AppPath;	return;	}
			Environment::CurrentDirectory = AppPath;

			String^ SavePath;
			if(Path::GetExtension(SaveFileDialog1->FileName) == nullptr){
				SavePath = SaveFileDialog1->FileName + L".img";
			}else{
				SavePath = SaveFileDialog1->FileName;
			}
			Start_IMG_Compress(openFileDialog1->FileName, SavePath);
		 }
private: System::Void button7_Click(System::Object^  sender, System::EventArgs^  e) {


			OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;
			openFileDialog1->InitialDirectory = Environment::CurrentDirectory;
			openFileDialog1->Filter="IMG files (*.img)|*.img|All files (*.*)|*.*";

			if (openFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){Environment::CurrentDirectory = AppPath;return;}
			Environment::CurrentDirectory = AppPath;

			SaveFileDialog^ SaveFileDialog1 = gcnew SaveFileDialog;
			SaveFileDialog1->InitialDirectory = Environment::CurrentDirectory;//"c:\\";
			SaveFileDialog1->Filter="BMP files (*.bmp)|*.bmp|PNG files (*.png)|*.png|JPG files (*.jpg)|*.jpg|All files (*.*)|*.*";

			if (SaveFileDialog1->ShowDialog()!= System::Windows::Forms::DialogResult::OK){Environment::CurrentDirectory = AppPath;	return;	}
			Environment::CurrentDirectory = AppPath;

			Start_Save_Image(openFileDialog1->FileName, SaveFileDialog1->FileName);

		 }
private: System::Void button8_Click(System::Object^  sender, System::EventArgs^  e) {//Folder Decode

			FolderBrowserDialog^ FolderBrowserDialog1 = gcnew FolderBrowserDialog;
			FolderBrowserDialog1->ShowNewFolderButton = false;
			if (FolderBrowserDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}
			Environment::CurrentDirectory = AppPath;

			FolderBrowserDialog^ FolderBrowserDialog2 = gcnew FolderBrowserDialog;
			FolderBrowserDialog2->ShowNewFolderButton = true;
			if (FolderBrowserDialog2->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}
			Environment::CurrentDirectory = AppPath;

			Start_Folder_Decode(FolderBrowserDialog1->SelectedPath, FolderBrowserDialog2->SelectedPath);
		 }
private: System::Void button6_Click(System::Object^  sender, System::EventArgs^  e) {//Folder Encode

			FolderBrowserDialog^ FolderBrowserDialog1 = gcnew FolderBrowserDialog;
			FolderBrowserDialog1->ShowNewFolderButton = false;
			if (FolderBrowserDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}
			Environment::CurrentDirectory = AppPath;

			FolderBrowserDialog^ FolderBrowserDialog2 = gcnew FolderBrowserDialog;
			FolderBrowserDialog2->ShowNewFolderButton = true;
			if (FolderBrowserDialog2->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}
			Environment::CurrentDirectory = AppPath;

			Start_Folder_Encode(FolderBrowserDialog1->SelectedPath, FolderBrowserDialog2->SelectedPath);

		 }
private: System::Void button9_Click(System::Object^  sender, System::EventArgs^  e) {

			//FolderBrowserDialog^ FolderBrowserDialog1 = gcnew FolderBrowserDialog;
			//FolderBrowserDialog1->ShowNewFolderButton = false;
			//if (FolderBrowserDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}
			//Environment::CurrentDirectory = AppPath;

			PLAY^ playform = gcnew PLAY();
			if(playform->ShowDialog()!= System::Windows::Forms::DialogResult::OK){return;}


		 }



private: System::Void button2_Click(System::Object^  sender, System::EventArgs^  e) {


				OpenFileDialog^ openFileDialog1 = gcnew OpenFileDialog;
				openFileDialog1->InitialDirectory = Environment::CurrentDirectory;

				if (openFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){Environment::CurrentDirectory = AppPath;return;}
				Environment::CurrentDirectory = AppPath;
				
				array<unsigned char>^ myStreamOpen ;
				if ( (myStreamOpen = File::ReadAllBytes(openFileDialog1->FileName)) == nullptr ){ Environment::CurrentDirectory = AppPath; return; }
				

				ViewQMG(myStreamOpen, pictureBox1);
				
			
				richTextBox1->Visible = false;
				pictureBox1->Visible = true;
				dataGridView1->Visible = false;


		 }
//private: System::Void button12_Click(System::Object^  sender, System::EventArgs^  e) {
//
//			 
//			 OpenFileDialog ^openFileDialog = gcnew OpenFileDialog();
//			openFileDialog->Title = "Select a ZIP archive to extract";
//			openFileDialog->Filter = "ZIP files (*.zip)|*.zip|All files (*.*)|*.*";
//			openFileDialog->FilterIndex = 1;
//			if (openFileDialog->ShowDialog() == System::Windows::Forms::DialogResult::OK)
//			{
//				FolderBrowserDialog ^folderBrowseDialog = gcnew FolderBrowserDialog();
//				folderBrowseDialog->ShowNewFolderButton = true;
//				folderBrowseDialog->Description = "Select a folder to put extracted files";
//				if (folderBrowseDialog->ShowDialog() == System::Windows::Forms::DialogResult::OK)
//				{
//					Stream ^zipStream = gcnew FileStream(openFileDialog->FileName, FileMode::Open);
//					TinySharpZip::ZipArchive::Extract(zipStream, folderBrowseDialog->SelectedPath);
//					zipStream->Close();
//					MessageBox::Show("ZIP archive has been extracted successfully!");
//				}
//			}
//
//		 }
private: System::Void extractToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

				SaveFileDialog^ SaveFileDialog1 = gcnew SaveFileDialog;

				if (SaveFileDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){Environment::CurrentDirectory = AppPath; return;}
				Environment::CurrentDirectory = AppPath;
				
				String^ SaveFileName = SaveFileDialog1->FileName;
				
				Item^ item = gcnew Item();
				item = static_cast<Item^> (treeView7->SelectedNode->Tag);

				BinaryWriter^ bw = gcnew BinaryWriter(File::Create(SaveFileName));
				bw->BaseStream->Write(item->data, 0, item->data->Length);
				bw->Close();
		 }


private: System::Void exstractAllToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {

			FolderBrowserDialog^ FolderBrowserDialog1 = gcnew FolderBrowserDialog;
			FolderBrowserDialog1->ShowNewFolderButton = true;
			if (FolderBrowserDialog1->ShowDialog()!=System::Windows::Forms::DialogResult::OK){return;}
			Environment::CurrentDirectory = AppPath;


			String^ FolderName = FolderBrowserDialog1->SelectedPath;
				if (Directory::Exists(FolderName + "\\" + treeView7->Nodes[0]->Text) != true)
                {
					Directory::CreateDirectory(FolderName + "\\" + treeView7->Nodes[0]->Text);
                }


				for each (TreeNode^ n in treeView7->Nodes[0]->Nodes)
				{
				
				Item^ item = gcnew Item();
				item = static_cast<Item^> (n->Tag);

				BinaryWriter^ bw = gcnew BinaryWriter(File::Create(FolderName + "\\" + treeView7->Nodes[0]->Text + "\\" + n->Text + ".bin"));
				bw->BaseStream->Write(item->data, 0, item->data->Length);
				bw->Close();


				}




		 }
private: System::Void replacePictureToolStripMenuItem_Click(System::Object^  sender, System::EventArgs^  e) {



		 }
};
}

