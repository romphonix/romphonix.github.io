#pragma once

#include <stdlib.h>
#include <memory.h>
#include "QMG.h"





namespace ImageUtils
{
	

signed int QmageDecCommon_SetImageInfo(unsigned char *a1, unsigned int a2)
{
	signed int result; 
	memset(a1, 0, 0x18);
	result = 0; 
	switch ( a2 ) { 
case 7: 
	*((unsigned int *)a1 + 4) = 7; 
	goto LABEL_3; 
case 0: 
	*((unsigned int *)a1 + 4) = 0;
	*((unsigned int *)a1 + 2) = 16;
	goto LABEL_7; 
case 1: 
	*((unsigned int *)a1 + 4) = 1;
	goto LABEL_9; 
case 2: 
	*((unsigned int *)a1 + 4) = 2; 
LABEL_9:
	*((unsigned int *)a1 + 2) = 24;
LABEL_7:
	*((unsigned int *)a1 + 3) = 0;
	return 1;
case 3:
	*((unsigned int *)a1 + 4) = 3;
	goto LABEL_12;
case 4:
	*((unsigned int *)a1 + 4) = 4;
LABEL_12: 
	*((unsigned int *)a1 + 2) = 24;
	goto LABEL_4;
case 5:
	*((unsigned int *)a1 + 4) = 5;
	goto LABEL_3; 
case 6:
	*((unsigned int *)a1 + 4) = 6;
LABEL_3:
	*((unsigned int *)a1 + 2) = 32;
LABEL_4:
	*((unsigned int *)a1 + 3) = 1;
	result = 1;
	break;
default:
	return result;
	} 
	return result;
}


signed int QmageDecCommon_GetVDecoder_CommonVersionInfo(unsigned char* a1, int a2, signed int a3, unsigned char *a4)
{
	int v4; // eax@3 
	unsigned int v6; // eax@15 
	char v7; // al@17 
	unsigned __int8 v8; // al@17 
	signed int v9; // eax@18 
	char v10; // al@28 
	
	memset(a4, 0, 0x30); 
	
	if ( a3 > 1 ) 
		*((unsigned int *)a4 + 2) = 1;
	*((unsigned int *)a4 + 1) = a2;
	v4 = *(unsigned char *)(a1 + 10);
	*((unsigned int *)a4 + 4) = 0; 
	if ( !a2 )
	{ 
		*((unsigned int *)a4 + 6) = v4;
		*((unsigned int *)a4 + 8) = 2;
		*((unsigned int *)a4 + 7) = 0;
		if ( *(unsigned char *)(a1 + 9) > 0xFu )
			*((unsigned int *)a4 + 2) = 1;
		*(unsigned int *)a4 = 21;
		*((unsigned int *)a4 + 8) = 3;
		*((unsigned int *)a4 + 4) = 2;
		return 1;
	} 
	if ( a2 == 1 )
	{
		v7 = *(unsigned char *)(a1 + 4);
		*(unsigned int *)a4 = 8;
		*((unsigned int *)a4 + 3) = 0;
		*((unsigned int *)a4 + 8) = 3;
		*((unsigned char *)a4 + 40) = v7;
		v8 = *(unsigned char *)(a1 + 4);
		*((unsigned int *)a4 + 7) = 1;
		*((unsigned int *)a4 + 6) = v8 >> 4;
		return 1; 
	}
	*((unsigned int *)a4 + 6) = v4;
	*((unsigned int *)a4 + 8) = 2;
	*((unsigned int *)a4 + 7) = 0;
	if ( a2 == 2 )
	{
		v9 = *((unsigned int *)a4 + 2) < 1u ? 8 : 24; 
		goto LABEL_19;
	} 
	if ( a2 == 3 ) 
	{
		v9 = *((unsigned int *)a4 + 2) < 1u ? 8 : 16;
LABEL_19:
		*(unsigned int *)a4 = v9;
		*((unsigned int *)a4 + 3) = 2;
		goto LABEL_20;
	}
	if ( a2 != 4 )
	{
		if ( a2 == 7 ) 
		{
			*(unsigned int *)a4 = 12;
			
			if ( *(unsigned char *)(a1 + 3) > 2u )
				*(unsigned int *)a4 = 16;
			
			if ( *((unsigned int *)a4 + 2) == 1 )
				*(unsigned int *)a4 = 24;
			
			*((unsigned int *)a4 + 5) = (*(unsigned char *)(a1 + 5) & 0x80) != 0;
			v10 = *(unsigned char *)(a1 + 4);
			*((unsigned int *)a4 + 3) = 0;
			*((unsigned int *)a4 + 6) = v10 & 0x1F; 
			return 1;
		}
		*(unsigned int *)a4 = 9;

		if ( *(unsigned char *)(a1 + 8) & 0x40 )
			*(unsigned int *)a4 = 13;
		
		if ( *((unsigned int *)a4 + 2) == 1 )
			*(unsigned int *)a4 = 17;
		
		if ( a2 == 5 ) *((unsigned int *)a4 + 3) = 2;
		v6 = ((unsigned int)*(unsigned char *)(a1 + 6) >> 5) & 1;
		goto LABEL_21; 
	}
	*(unsigned int *)a4 = 8; 
LABEL_20:
	v6 = (*(unsigned char *)(a1 + 6) & 0x20) != 0;
LABEL_21:
	*((unsigned int *)a4 + 5) = v6;
	*((unsigned int *)a4 + 6) = *(unsigned char *)(a1 + 6) & 0x1F;
	return 1;
}



signed int QmageDecCommon_QGetDecoderInfo(unsigned char* a1,  unsigned char *a3)
{
	signed int v3; 
	int v5;  
	unsigned int v6; 
	char v7;  
	int v8; 
	int v9; 
	int v10; 
	
	memset(a3, 0, 0x90);
	v3 = 0;
	if ( (*(unsigned char *)a1 | (*(unsigned char *)(a1 + 1) << 8)) == 19793 )
	{
		v5 = QmageDecCommon_SetImageInfo(a3, *(unsigned char *)(a1 + 3)); 
		v3 = 0; 
		if ( v5 )
		{
			v6 = (unsigned int)*(unsigned char *)(a1 + 4) >> 7;
			*((unsigned int *)a3 + 11) = v6;
			if ( v6 )
			{
				*((unsigned int *)a3 + 8) = 1;
				*((unsigned int *)a3 + 15) = *(unsigned char *)(a1 + 16) | (*(unsigned char *)(a1 + 17) << 8);
				*((unsigned int *)a3 + 16) = *(unsigned char *)(a1 + 18) | (*(unsigned char *)(a1 + 19) << 8);
				*((unsigned int *)a3 + 17) = *(unsigned char *)(a1 + 20) | (*(unsigned char *)(a1 + 21) << 8);
				*((unsigned int *)a3 + 18) = *(unsigned char *)(a1 + 22);
			} else {
				*((unsigned int *)a3 + 15) = 1;
				*((unsigned int *)a3 + 16) = 1;
			}
			*((unsigned int *)a3 + 10) = (*(unsigned char *)(a1 + 4) & 0x40) != 0;
			*((unsigned int *)a3 + 9) = (*(unsigned char *)(a1 + 4) & 0x20) >> 5;
			*((unsigned int *)a3 + 12) = *(unsigned char *)(a1 + 4) & 0x1F;
			*((unsigned int *)a3 + 25) = (*(unsigned char *)(a1 + 5) & 0x80) != 0;
			*((unsigned int *)a3 + 32) = 1;
			*((unsigned int *)a3 + 33) = 1; 
			v7 = *(unsigned char *)(a1 + 5); 
			
			if ( v7 & 0x40 )//7 bit  
			{
				*((unsigned int *)a3 + 32) = 2;
				v7 = *(unsigned char *)(a1 + 5);
			}
			if ( v7 & 0x20 )//6 bit
				*((unsigned int *)a3 + 33) = 2;

				v9 = *(unsigned char *)(a1 + 6) | (*(unsigned char *)(a1 + 7) << 8);
				*(unsigned int *)a3 = v9;
				v8 = *(unsigned char *)(a1 + 8) | (*(unsigned char *)(a1 + 9) << 8);
				*((unsigned int *)a3 + 1) = v8;
			
			if ( v9 <= 0 || v8 <= 0 )
				return 0;

			//v10 = *(unsigned char *)(a1 + 5) & 7;
			*((unsigned int *)a3 + 19) = *(unsigned char *)(a1 + 5) & 7; //111 bits
			
			if ( v6 == 1 ){
				*((unsigned int *)a3 + 6) = 24;//offset from header
			}else{ 
				*((unsigned int *)a3 + 6) = *((unsigned int *)a3 + 3) < 1 ? 12 : 16;//offset from header
			}

			*((unsigned int *)a3 + 7) = *(unsigned char *)(a1 + 12) | (*(unsigned char *)(a1 + 13) << 8) | (*(unsigned char *)(a1 + 14) << 16) | (*(unsigned char *)(a1 + 15) << 24);
			
			if ( *(unsigned char *)(a1 + 5) & 7 == 4 ){
					
				*((unsigned int *)a3 + 6) = 12;//offset from header
			
					if ( *(unsigned char *)(a1 + 3) > 2 )
						*((unsigned int *)a3 + 6) = 16;//offset from header
				
				v3 = 1;
				*((unsigned int *)a3 + 34) = 1;
			
			}else {
				QmageDecCommon_GetVDecoder_CommonVersionInfo(a1, 7, *((unsigned int *)a3 + 15), (unsigned char *)a3 + 80);
				v3 = 1;
			}
		}
	}
	return v3;
}

//int QmageDecCommon_SetHeaderFromDecoderInfo(unsigned char* a1, unsigned char* a2) 
//{
//	int result;
//
//	*(unsigned int *)a1 = *(unsigned int *)(a2 + 44);
//	*(unsigned int *)(a1 + 4) = *(unsigned int *)a2;
//	*(unsigned int *)(a1 + 8) = *(unsigned int *)(a2 + 4); 
//	*(unsigned int *)(a1 + 12) = *(unsigned int *)(a2 + 16);
//	*(unsigned int *)(a1 + 16) = *(unsigned int *)(a2 + 12); 
//	*(unsigned int *)(a1 + 20) = *(unsigned int *)(a2 + 52);
//	*(unsigned int *)(a1 + 24) = *(unsigned int *)(a2 + 60);
//	*(unsigned int *)(a1 + 28) = *(unsigned int *)(a2 + 64);
//	*(unsigned int *)(a1 + 32) = *(unsigned int *)(a2 + 68);
//	result = *(unsigned int *)(a2 + 72);
//	*(unsigned int *)(a1 + 36) = result;
//	return result; 
//}

//int QmageDecCommon_ParseHeader(unsigned char *pSrc, unsigned char *pOut) 
//{
//	int result;
//	//unsigned char v21;
//	unsigned char *v21 = ( unsigned char *)malloc ( 0x90);
//
//
//		if ( *(unsigned short*)pSrc == 19793 )
//		{ 
//		
//			result = QmageDecCommon_QGetDecoderInfo(pSrc, v21);
//
//			if ( result )
//			{
//				QmageDecCommon_SetHeaderFromDecoderInfo(pOut, v21);
//				result = 1;
//
//			} else {
////			  debug_QmageDecError = -3;
//			} 
//
//			free(v21);
//			return result;
//		}
//} 


int  QM_WCodec_decode(unsigned char* src, unsigned char* dst, int H, int W, int _2or4, int a6)
{ 
	int result; // eax@2 
	unsigned char *v7; // esi@3 
	void *v8; // eax@3 
	char v9; // zf@3 
	int v10; // ebx@4 
	
	if ( a6 == 1 )
	{
		result = QM_WCodec_1st_decode(src, dst, W * H, _2or4);
	} else {
		result = -1; 
		if ( a6 == 2 )
		{ 
			v8 = malloc(*(unsigned int *)src);
			v7 = (unsigned char*)v8;
			v9 = v8 == 0; 
			result = -1; 
			if ( !v9 )
			{ 
				int g = QM_WCodec_2nd_decode(src, v7);
				v10 = QM_WCodec_1st_decode(v7, dst, W * H, _2or4);
				free(v7);
				result = v10;
			}
		}
	}
	return result;
}




int  Qmage_WDecodeFrame_Low(unsigned char* src, unsigned char *dst, unsigned char* info)
{
	int v3; // eax@1 
	signed int v4; // edx@1 
	int v5; // ecx@1 
	int W; // ebx@1 
	int H; // esi@1 
	signed int v8; // edx@1 
	char v9; // sf@1 
	size_t v10; // edx@2 
	int v11; // eax@3 
	int result; // eax@7 
	int v13; // esi@14 
	void *v14; // eax@14 
	unsigned char *v15; // ecx@14 
	unsigned char* v16; // ebx@17 
	int v17; // ecx@18 
	int v18; // eax@20 
	unsigned char *v19; // eax@24 
	unsigned char *v20; // edx@27 
	unsigned char* v21; // ebx@27 
	unsigned char * v22; // esi@27 
	int v23; // ecx@28 
	char v24; // al@30 
	unsigned char v25; // al@30 
	unsigned char *v26; // edx@35 
	unsigned char *v27; // ebx@35 
	unsigned char *v28; // esi@35 
	int v29; // ecx@36 
	int v30; // al@38 
	void * v31; // al@38 
	unsigned char * v32; // [sp+0h] [bp-58h]@25 
	int v33; // [sp+20h] [bp-38h]@18 
	int v34; // [sp+20h] [bp-38h]@27 
	int v35; // [sp+20h] [bp-38h]@35 
	int v36; // [sp+24h] [bp-34h]@37 
	int v37; // [sp+28h] [bp-30h]@35 
	int v38; // [sp+2Ch] [bp-2Ch]@29 
	int v39; // [sp+30h] [bp-28h]@27 
	void* v40; // [sp+34h] [bp-24h]@15 
	unsigned char* v41; // [sp+38h] [bp-20h]@14 
	int v42; // [sp+3Ch] [bp-1Ch]@19 
	signed int v43; // [sp+40h] [bp-18h]@1 
	int v44; // [sp+44h] [bp-14h]@6 
	int v45; // [sp+44h] [bp-14h]@17 
	int v46; // [sp+48h] [bp-10h]@1 
	
	H = *(unsigned int *)info; //H
	W = *(unsigned int *)(info + 4);//W
	v8 = *(unsigned int *)(info + 8);// bpp 
	v5 = W * H;
	v43 = v8; 
	v46 = *(unsigned int *)(info + 24); //header len
	v3 = v5 * v8;
	v9 = v5 * v8 < 0; 
	v4 = v5 * v8;
	if ( v9 )
		v4 = v3 + 7;
	
	v10 = v4 >> 3; // file len
	if ( (signed int)v10 <= 47 )
		goto LABEL_11;
	v11 = *(unsigned int *)(info + 16);
	if ( !v11 ) 
	{
		if ( *(unsigned int *)(info + 36) )
		{
			memcpy(dst, (void *)(src + v46), 2 * v5);
			v44 = *(unsigned int *)(info + 24) + 2 * *(unsigned int *)info * *(unsigned int *)(info + 4);
		} else { 
			v44 = QM_WCodec_decode(v46 + src, dst, H, W, 2, *(unsigned int *)(info + 128));
		int a = 0;
		}
		return v44;
	}
	if ( (unsigned int)(v11 - 3) > 1 )
	{
		if ( !*(unsigned int *)(info + 36) )

			
			int b = *(unsigned int *)(info + 128);
			int b11 = *(unsigned int *)(info + 12);
			int b12 = *(unsigned int *)(info + 16);
			int b13 = *(unsigned int *)(info + 20);
			int b16 = *(unsigned int *)(info);
			int b14 = *(unsigned int *)(info + 4);
			int b15 = *(unsigned int *)(info + 8);
			
		
		
			int b1 = *(unsigned int *)(info + 20);
			int b2 = *(unsigned int *)(info + 24);
			int b3 = *(unsigned int *)(info + 28);
			int b4 = *(unsigned int *)(info + 32);
			int b5 = *(unsigned int *)(info + 36);


			int b21 = *(unsigned int *)(info + 40);
			int b22 = *(unsigned int *)(info + 44);
			int b23 = *(unsigned int *)(info + 48);
			int b24 = *(unsigned int *)(info + 52);
			int b25 = *(unsigned int *)(info + 56);



			return QM_WCodec_decode(v46 + src, dst, H, W, v43 / 8, *(unsigned int *)(info + 128));

LABEL_11:
		
		memcpy(dst, (void *)(src + v46), v10);
		return *(unsigned int *)(info + 24) + *(unsigned int *)(info + 8) * *(unsigned int *)info * *(unsigned int *)(info + 4) / 8;
	}
	v13 = *(unsigned int *)(info + 28); 
	v14 = malloc(2 * v5);
	v41 = (unsigned char*)v14;
	v15 = (unsigned char*)v14;
	result = 0;
	if ( v15 )
	{
		v40 = malloc(2 * *(unsigned int *)info * *(unsigned int *)(info + 4));
		if ( v40 )
		{
			if ( *(unsigned int *)(info + 36) ) 
			{
				memcpy((void *)v41, (void *)(*(unsigned int *)(info + 24) + src), 2 * *(unsigned int *)info * *(unsigned int *)(info + 4));
				v17 = *(unsigned int *)info;
				v33 = *(unsigned int *)(info + 4);
				v45 = *(unsigned int *)(info + 24) + 2 * *(unsigned int *)info * v33;
				v16 = v46 + src;
			} else {
				v16 = v46 + src;

				v45 = QM_WCodec_decode(v46 + src, v41, *(unsigned int *)info, *(unsigned int *)(info + 4), 2, *(unsigned int *)(info + 128));

				if ( !v45 )
				{
					free(v41);
					v32 = (unsigned char*)v40; 
					goto LABEL_26;
				}
				v17 = *(unsigned int *)info;
				v33 = *(unsigned int *)(info + 4);
			}
			v42 = QM_WCodec_decode(v16 + v13, (unsigned char*)v40, (v17 + 1) >> 1, v33, 2, *(unsigned int *)(info + 132));

			if ( v42 )
			{ v18 = *(unsigned int *)(info + 16);
			if ( v18 == 3 ) 
			{
				v39 = 0;
				v21 = v41;
				v20 = dst;
				v22 = (unsigned char*)v40; 
				v34 = *(unsigned int *)(info + 4); 
				if ( *(unsigned int *)(info + 4) > 0 )
				{
					v23 = *(unsigned int *)info;
					do {
						v38 = 0;
						if ( v23 > 0 ) 
						{
							do {
								*(unsigned char *)v20 = *(unsigned char *)v21;
								//v24 = *(unsigned char *)(v21 + 1);
								v21 += 2;
								*((unsigned char *)v20 + 1) = *(unsigned char *)(v21 + 1);
								//v25 = *(unsigned char *)v22++;
								*((unsigned char *)v20 + 2) = *(unsigned char *)v22++;
								v23 = *(unsigned int *)info;
								v20+= 3;// v20 + 3;
								++v38;
							}while (*(unsigned int *)info > v38 );

							v34 = *(unsigned int *)(info + 4);
						}
						v22 -= ((v23 & 1) < 1) - 1;
						++v39;
					}
					while ( v34 > v39 );
				}
			} else {
				if ( v18 == 4 )
				{
					v37 = 0; 
					v27 = v41;
					v26 = dst; 
					v28 = (unsigned char*)v40; 
					v35 = *(unsigned int *)(info + 4);
					if ( *(unsigned int *)(info + 4) > 0 )
					{
						v29 = *(unsigned int *)info;
						do {
							v36 = 0;
							if ( v29 > 0 )
							{
								do { 
									//v30 = *(unsigned char *)v28++;
									*(unsigned char *)v26 = *(unsigned char *)v28++;
									*((unsigned char *)v26 + 1) = *(unsigned char *)v27;
									//v31 = *(unsigned char *)(v27 + 1);
									v27 += 2;
									*((unsigned char *)v26 + 2) = *(unsigned char *)(v27 + 1);
									v29 = *(unsigned int *)info;
									v26 += 3;//(char *)v26 + 3;
									++v36; 
								}
								while ( *(unsigned int *)info > v36 );
								v35 = *(unsigned int *)(info + 4);
							}
							v28 -= ((v29 & 1) < 1) - 1;
							++v37; 
						}
						while ( v35 > v37 );
					}
				}
			}
			free(v40);
			free(v41);
			return v42 + v45;
			}
			free(v41);
			v19 = (unsigned char*)v40;
		} else {
			v19 = v41;
		} 
		v32 = v19;
LABEL_26: 
		free(v32);
		result = 0;
 }
 return result;
 }




int  QmageDecodeFrame(unsigned char* src, unsigned char *dst) 
{
	int Len;  

	unsigned char *pInfo = ( unsigned char *)malloc ( 0x90);
	
	unsigned int Err = QmageDecCommon_QGetDecoderInfo(src, pInfo);
		Len = 0; 
		
		if ( Err ) 
		{
					Len = Qmage_WDecodeFrame_Low(src, dst, pInfo);
		}
		free(pInfo);
	return Len; 
}






//void  WmDecodeQMAGEBitmapEx(unsigned char* pDecodeBuffer) {

//void* pHeaderInfo = malloc (0x90);

//QmageDecCommon_ParseHeader(pDecodeBuffer, (unsigned char*) pHeaderInfo);
//
//int a = *((unsigned int *)pHeaderInfo);
//int b = *((unsigned int *)pHeaderInfo + 1); //W
//int c = *((unsigned int *)pHeaderInfo + 2); // H
//int d = *((unsigned int *)pHeaderInfo + 3); // 7 -> 32 bpp   5 -> 32 bpp  0 -> 16 bpp
//int e = *((unsigned int *)pHeaderInfo + 4); //1
//int f = *((unsigned int *)pHeaderInfo + 5); //0
//int a1 = *((unsigned int *)pHeaderInfo + 6); //1
//int b1 = *((unsigned int *)pHeaderInfo + 7); //1
//int c1 = *((unsigned int *)pHeaderInfo + 8); //0
//int d1 = *((unsigned int *)pHeaderInfo + 9); //0
//
//int FileSize = b*c*4;
//	
//
//void* Dst = malloc(FileSize);
//
//QmageDecodeFrame(pDecodeBuffer,  (unsigned char*)Dst);
//int g = 0;
//
//free(pHeaderInfo);
//
//}




	void ViewQMG ( array<unsigned char>^ buffer, PictureBox^ pictureBox1)
	{
		
	
		unsigned int length = buffer->Length;
		
		unsigned char *src = ( unsigned char *)malloc ( length );
		
		Marshal::Copy(buffer, 0, IntPtr(src), buffer->Length);

		unsigned short W = *(unsigned short*)(src + 0x6);
		unsigned short H = *(unsigned short*)(src + 0x8);
		unsigned int _2or4 = 4;
		unsigned int dst_len = H*W*_2or4;
		
		unsigned char *dst = ( unsigned char *)malloc ( dst_len + 0x1000);////////////////
		int len = QmageDecodeFrame(src,  dst);		
		
		Bitmap^ bmp = gcnew Bitmap(W, H, Imaging::PixelFormat::Format32bppArgb);
				Rectangle rect = Rectangle(0,0,W,H);
					System::Drawing::Imaging::BitmapData^ bmpData = bmp->LockBits( rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, bmp->PixelFormat );
						IntPtr ptr = bmpData->Scan0;
							int bytes = Math::Abs(bmpData->Stride) * H;
								memcpy( (void*)(ptr), dst, bytes);
					
						bmp->UnlockBits( bmpData );
						pictureBox1->SizeMode = PictureBoxSizeMode::CenterImage;
					pictureBox1->Image = dynamic_cast<Image^>(bmp);


		free( src );
		free ( dst );
	}

	void QmageDecode(unsigned char *src,  unsigned char *dst, unsigned int W, unsigned int H, unsigned int _2or4){

	unsigned char switch1 = *(unsigned short*)(src + 0x2);
	unsigned char switch2 = *(unsigned short*)(src + 0x5);
	
	void* v8;
	
	switch(switch2)
	{
			
				case 0x0:
				case 0x2:
				case 0x4:
				case 0x6:

				break;
				
				
				case 0x11:
				case 0x1:
				
				src+=0x10;
				v8 = malloc(*(unsigned int *)src);
				 
					QM_WCodec_2nd_decode(src, (unsigned char*)v8);
					QM_WCodec_1st_decode((unsigned char*)v8, dst, W * H, _2or4);
					free(v8);
					
				
				
				break;
			case 0x3:
			case 0x5:
				
					src += 0x10;
					QM_WCodec_1st_decode(src, dst, W * H, _2or4);

				break;
			case 0x7:

				src += 0x10;
				QM_WCodec_2nd_decode(src, dst);
		
				break;
			
			case 0x8:
			
				break;

			case 0x9:
			case 0x19:

				src += 0x10;
				QM_WCodec_1st_decode_old(src, dst, W * H, _2or4);

				break;
			case 0x10:

			//int h = 0;

				break;

				break;			
			default:
			return;
	}

	}


	void QmageDecode16(unsigned char *src,  unsigned char *dst, unsigned int W, unsigned int H, unsigned int _2or4){

	unsigned char switch1 = *(unsigned short*)(src + 0x2);
	unsigned char switch2 = *(unsigned short*)(src + 0x5);
	
	void* v8;
	
	switch(switch2)
	{
			
				case 0x0:
				case 0x2:
				case 0x4:
				case 0x6:

				break;
				
				
				case 0x11:
				case 0x1:
				
				src+=0xC;
				v8 = malloc(*(unsigned int *)src);
				 
					QM_WCodec_2nd_decode(src, (unsigned char*)v8);
					QM_WCodec_1st_decode((unsigned char*)v8, dst, W * H, _2or4);
					free(v8);
					
				
				
				break;
			case 0x3:
			case 0x5:
				
					src += 0xC;
					QM_WCodec_1st_decode(src, dst, W * H, _2or4);

				break;
			case 0x7:

				src += 0xC;
				QM_WCodec_2nd_decode(src, dst);
		
				break;
			
			case 0x8:
			
				break;

			case 0x9:
			case 0x19:

				src += 0xC;
				QM_WCodec_1st_decode_old(src, dst, W * H, _2or4);

				break;
			case 0x10:

			//int h = 0;

				break;

				break;			
			default:
			return;
	}

	}


	void ViewQM ( array<unsigned char>^ buffer, PictureBox^ pictureBox1)
	{
		
	
		unsigned int length = buffer->Length;
		
		unsigned char *src = ( unsigned char *)malloc ( length );
		
		Marshal::Copy(buffer, 0, IntPtr(src), buffer->Length);

		unsigned short W = *(unsigned short*)(src + 0x6);
		unsigned short H = *(unsigned short*)(src + 0x8);
		unsigned int _2or4 = 4;
		unsigned int dst_len = H*W*_2or4;
		
		unsigned char *dst = ( unsigned char *)malloc ( dst_len + 0x1000);////////////////
		memset(dst, 0, dst_len + 0x1000);

		QmageDecode(src,  dst, W, H, _2or4);		
		
		Bitmap^ bmp = gcnew Bitmap(W, H, Imaging::PixelFormat::Format32bppArgb);
				Rectangle rect = Rectangle(0,0,W,H);
					System::Drawing::Imaging::BitmapData^ bmpData = bmp->LockBits( rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, bmp->PixelFormat );
						IntPtr ptr = bmpData->Scan0;
							int bytes = Math::Abs(bmpData->Stride) * H;
								memcpy( (void*)(ptr), dst, bytes);
					
						bmp->UnlockBits( bmpData );
						pictureBox1->SizeMode = PictureBoxSizeMode::CenterImage;
					pictureBox1->Image = dynamic_cast<Image^>(bmp);


		free( src );
		free ( dst );
//		free ( dst2 );

//		return decompress;
	}

	void ViewQM16 ( array<unsigned char>^ buffer, PictureBox^ pictureBox1)
	{
		
	
		unsigned int length = buffer->Length;
		
		unsigned char *src = ( unsigned char *)malloc ( length );
		
		Marshal::Copy(buffer, 0, IntPtr(src), buffer->Length);

		unsigned short W = *(unsigned short*)(src + 0x6);
		unsigned short H = *(unsigned short*)(src + 0x8);
		unsigned int _2or4 = 2;
		unsigned int dst_len = H*W*_2or4;
		
		unsigned char *dst = ( unsigned char *)malloc ( dst_len + 0x1000);////////////////
		memset(dst, 0, dst_len + 0x1000);

		QmageDecode16(src,  dst, W, H, _2or4);		
		
		Bitmap^ bmp = gcnew Bitmap(W, H, Imaging::PixelFormat::Format16bppRgb565);
				Rectangle rect = Rectangle(0,0,W,H);
					System::Drawing::Imaging::BitmapData^ bmpData = bmp->LockBits( rect, System::Drawing::Imaging::ImageLockMode::ReadWrite, bmp->PixelFormat );
						IntPtr ptr = bmpData->Scan0;
							int bytes = Math::Abs(bmpData->Stride) * H;
								memcpy( (void*)(ptr), dst, bytes);
					
						bmp->UnlockBits( bmpData );
						pictureBox1->SizeMode = PictureBoxSizeMode::CenterImage;
					pictureBox1->Image = dynamic_cast<Image^>(bmp);


		free( src );
		free ( dst );
//		free ( dst2 );

//		return decompress;
	}


}