#pragma once




#include <stdlib.h>
#include <memory.h>

//#include "stdafx.h"
//#include "windows.h"
//#include "iostream.h"
//#include "process.h"	

typedef unsigned long       DWORD;
typedef int                 BOOL;
typedef unsigned char       BYTE;
typedef unsigned short      WORD;








namespace ImageUtils
{
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	using namespace System::Runtime::InteropServices;





void * sub_4DCD30(void *a1, const void *a2, unsigned int a3)
{ 
	void *result; // eax@1 
	memcpy(a1, a2, 4 * (a3 >> 2)); 
	result = a1; 
	memcpy((char *)a1 + 4 * (a3 >> 2), (char *)a2 + 4 * (a3 >> 2), a3 & 3); 
	return result;
} 

void * sub_4DCCF0(size_t Size) { return malloc(Size); }

void * sub_4DCD10(size_t NumOfElements, size_t SizeOfElements) { return calloc(NumOfElements, SizeOfElements); } 

int  ONE_STAGE(int a1/*in bitmap pointer*/, int a2, int a3, int a4, int a5/*out pointer*/, int a6/*width * height*/, int a7/* 4 */)
{
	unsigned int v7; // ebx@1 
	void *v8; // ebp@1 
	unsigned int v9; // edi@1 
	signed int v10; // esi@1 
	size_t v11; // ST08_4@1 
	int v13; // eax@3 
	int v14; // ebp@6 
	signed int v15; // eax@7 
	void *v16; // ecx@8 
	signed int v17; // edx@18 
	void *v18; // ecx@18 
	void *v19; // ecx@23 
	signed int v20; // ebx@23 
	void *v21; // eax@25 
	int v22; // ebp@25 
	int v23; // edx@27 
	int v24; // esi@27 
	void *v25; // eax@30 
	signed int v26; // edx@30 
	void *v27; // ecx@30 
	signed int v28; // eax@35 
	int v29; // ebp@35 
	int v30; // esi@35 
	void *v31; // ecx@36 
	unsigned int v32; // ecx@40 
	unsigned int v33; // edx@41 
	int i; // ecx@41 
	int v35; // edi@41 
	void *v36; // edi@41 
	unsigned int v37; // ecx@41 
	int v38; // edi@49 
	unsigned int v39; // edx@54 
	unsigned int j; // ecx@54 
	unsigned int v41; // edi@54 
	signed int v42; // eax@59 
	void *v43; // ecx@60 
	unsigned int v44; // ebx@64 
	unsigned int k; // ecx@65 
	unsigned int v46; // edi@65 
	void *v47; // edi@65 
	char v48; // zf@72 
	unsigned int v49; // edx@75 
	unsigned int l; // ecx@75 
	unsigned int v51; // edi@75 
	int v52; // edi@79 
	int v53; // ecx@81 
	int v54; // eax@82 
	signed int v55; // [sp+10h] [bp-2Ch]@1 
	void *v56; // [sp+14h] [bp-28h]@3 
	signed int v57; // [sp+18h] [bp-24h]@1 
	void *v58; // [sp+1Ch] [bp-20h]@1 
	signed int v59; // [sp+20h] [bp-1Ch]@1 
	unsigned int v60; // [sp+24h] [bp-18h]@1 
	int v61; // [sp+24h] [bp-18h]@49 
	signed int v62; // [sp+28h] [bp-14h]@1 
	int v63; // [sp+28h] [bp-14h]@49 
	int v64; // [sp+2Ch] [bp-10h]@49 
	int v65; // [sp+30h] [bp-Ch]@1 
	int v66; // [sp+34h] [bp-8h]@1 
	signed int v67; // [sp+4Ch] [bp+10h]@64 
	int v68; // [sp+54h] [bp+18h]@1 
	unsigned int v69; // [sp+58h] [bp+1Ch]@1 



	v9 = (unsigned int)(a7 * a6) >> 2; 
	v10 = 0; 
	v7 = 0; 
	v55 = 0; 
	v60 = (unsigned int)(a7 * a6) >> 2; 
	v65 = a7 * a6 - 4 * v9; 
	v11 = 4 * ((signed int)((unsigned int)(a7 * a6) >> 2) >> 1); 
	v66 = 4 * v9; 
	v62 = 0; 
	v69 = 0; 
	v68 = 0; 
	v59 = 0; 
	v57 = 0; 
	v8 = (void *)sub_4DCCF0(v11); 
	v58 = v8; 
	if ( !v8 ) {  return -1; } 
	v13 = (int)sub_4DCD10(8u, v9); 
	v56 = (void *)v13;
	if ( !v13 ) {  return -1; } 

	if ( (signed int)v9 > 0 ) {
		v14 = a1; 
	do {
		v15 = 0;
			if ( v10 > 0 ) { 
				v16 = v56;
				while ( *( DWORD *)v14 != *(DWORD *)v16 ) {//////////////////////////////////////
					++v15; 
					v16 = (char *)v16 + 8; 
						if ( v15 >= v10 )
						goto LABEL_13;
				}
				++*((DWORD *)v56 + 2 * v15 + 1);
			} 
LABEL_13: 
			if ( v15 == v10 ) { 
				++v10; 
				*((DWORD *)v56 + 2 * v15) = *(DWORD *)v14;
			} 
		v14 += 4;
		--v9;
	} while ( v9 );

	v9 = v60;
	v13 = (int)v56; 
	v62 = v10;
	} 



	if ( v10 > 0 ) { 
		v18 = v58;
		v17 = v10;
		do {
			if ( *(DWORD *)(v13 + 4) > 1u ) { 
				*(DWORD *)v18 = *(DWORD *)v13; 
				v18 = (char *)v18 + 4; ++v55;
			} 
			v13 += 8;
			--v17; 
		}while ( v17 );

		if ( v55 > 508 ) {
			v19 = v56; 
			v20 = 0; 
		do {
			if ( v20 < v10 ) {
				v21 = v19; 
				v22 = v10 - v20; 
				do { 
					if ( *((DWORD *)v19 + 1) < *((DWORD *)v21 + 1) ) { 
						v23 = *(DWORD *)v19; 
						v24 = *((DWORD *)v19 + 1);
						*(DWORD *)v19 = *(DWORD *)v21;
						*((DWORD *)v19 + 1) = *((DWORD *)v21 + 1); 
						v9 = v60; 
						*(DWORD *)v21 = v23;
						*((DWORD *)v21 + 1) = v24; v10 = v62;
					}
					v21 = (char *)v21 + 8;
					--v22; 
				} while ( v22 );
			} ++v20;
			v19 = (char *)v19 + 8;
		} while ( v20 < 508 );
		v27 = v58; 
		v25 = v56;
		v55 = 0;
		v26 = 508; 
		do {
			if ( *((DWORD *)v25 + 1) > 1u ) {
				*(DWORD *)v27 = *(DWORD *)v25;
				++v55;
				v27 = (char *)v27 + 4;
			} 
			v25 = (char *)v25 + 8;
			--v26;
		} while ( v26 ); 
		v7 = v69;
		} 
	} 
	v29 = a2;
	v30 = 4 * v55; 
	sub_4DCD30((void*)a2, v58, 4 * v55); 
	v28 = 0;
	if ( v55 > 0 ) { 
		v31 = v58;
			while ( *(DWORD *)a1 != *(DWORD *)v31 ) {
				++v28;
				v31 = (char *)v31 + 4; 
				if ( v28 >= v55 ) 
					goto LABEL_46;
			} 
	v32 = v28 + 1; 
	if ( v28 + 1 >= 255 ) { 
		v36 = (void *)(v30 + a2); 
		v33 = v32 / 0xFF;
		v30 += v32 / 0xFF; 
		v37 = v32 / 0x3FC; 
		memset(v36, -1, 4 * v37);
		v35 = (int)((char *)v36 + 4 * v37); 
		v7 = v69; 
		for ( i = v33 & 3; i; --i ) 
			*(BYTE *)v35++ = -1; 
		v9 = v60; 
		v32 = -255 * v33 + v28 + 1;
	} *(BYTE *)(v30++ + a2) = v32; 
	v57 = 0;
	}
LABEL_46: 
	if ( v28 == v55 ) { 
		*(BYTE *)(v30++ + a2) = 0; 
		*(DWORD *)a4 = *(DWORD *)a1; 
		v59 = 1; 
		v57 = 1;
	} 
	if ( (signed int)v9 > 1 ) {
		v64 = a4 + 4 * v59; 
		v38 = a1 + 4; 
		v63 = a1 + 4; 
		v61 = v60 - 1; 
		do { 
			if ( v57 ) 
				goto LABEL_59; 
			if ( *(DWORD *)v38 != *(DWORD *)(v38 - 4) ) { 
				if ( (signed int)v7 >= 255 ) { 
					v39 = v7 / 0xFF; 
					memset((void *)(v68 + a3), -1, 4 * v7 / 0x3FC); 
					v41 = v68 + a3 + 4 * v7 / 0x3FC; 
					for ( j = v7 / 0xFF & 3; j; --j )
						*(BYTE *)v41++ = -1;
					v38 = v63;
					v7 = -255 * v39 + v69; 
					v68 += v39;
				} 
				v69 = 0; 
				*(BYTE *)(v68 + a3) = v7; 
				v7 = 0; 
				++v68; 
LABEL_59: 
				v42 = 0; 
				if ( v55 > 0 ) { 
					v43 = v58; 
					while ( *(DWORD *)v38 != *(DWORD *)v43 ) {
						++v42; 
						v43 = (char *)v43 + 4;
						if ( v42 >= v55 ) 
							goto LABEL_70; 
					}
					v44 = v42 + 1; 
					v67 = v42; 
					if ( v42 + 1 >= 255 ) { 
						v47 = (void *)(v30 + v29); 
						v30 += v44 / 0xFF; 
						memset(v47, -1, 4 * v44 / 0x3FC); 
						v46 = (unsigned int)((char *)v47 + 4 * v44 / 0x3FC);
						v29 = a2;
						for ( k = v44 / 0xFF & 3; k; --k ) 
							*(BYTE *)v46++ = -1; 
						v38 = v63; 
						v44 %= 0xFFu; 
						v42 = v67;
					} 
					*(BYTE *)(v30 + v29) = v44;
					v7 = v69;
					++v30; v57 = 0;
				} 
LABEL_70: 
				if ( v42 == v55 ) {
					*(BYTE *)(v30++ + v29) = 0;
					*(DWORD *)v64 = *(DWORD *)v38;
					++v59; 
					v64 += 4; 
					v57 = 1; 
				} goto LABEL_72;
			} 
			++v7; 
			v69 = v7; 
LABEL_72: 
			v38 += 4; 
			v48 = v61 == 1; 
			v63 = v38; 
			--v61;
		}
		while ( !v48 );
	} 
	if ( v57 ) { 
		v52 = v68; 
	} else { if ( (signed int)v7 >= 255 ) {
		v49 = v7 / 0xFF; 
		memset((void *)(v68 + a3), -1, 4 * v7 / 0x3FC); 
		v51 = v68 + a3 + 4 * v7 / 0x3FC; 
		for ( l = v7 / 0xFF & 3; l; --l ) 
			*(BYTE *)v51++ = -1; 
		v7 = -255 * v49 + v69; v68 += v49;
	} 
	*(BYTE *)(v68 + a3) = v7; 
	v52 = v68 + 1; 
	}
	v53 = v65; 
	if ( v65 ) { 
		v54 = a1 + v66; 
		do { 
			*(BYTE *)(v30++ + v29) = *(BYTE *)v54++;
			--v53;
		}
		while ( v53 );
	} 
	if ( v30 & 3 )
		v30 += 4 - (v30 & 3);
	if ( v52 & 3 ) 
		v52 += 4 - (v52 & 3);
	*(DWORD *)a5 = v55;
	*(DWORD *)(a5 + 4) = v30 - 4 * v55;
	*(DWORD *)(a5 + 8) = v52; 
	*(DWORD *)(a5 + 12) = v59;
//	sub_4DCD00(v58);
//	sub_4DCD00(v56);
	return v30 + v52 + 4 * v59 + 16; 
} 
























}