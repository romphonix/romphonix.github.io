#pragma once

//#include "Decompress_Bada2_RC1.h"
#include "QMD.h"


namespace ImageUtils {


	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	using namespace System::Collections::Generic;
	using namespace System::Runtime::InteropServices;

	#define ALIGN(x,a) (((x)+(a)-1)&~((a)-1))

	
	unsigned int RootEntryLen = 0x40;
	unsigned int EntryLen = 0xC;
	unsigned int DirEntryLen = 0x30 ;
	unsigned int FileEntryLen = 0x34 ;

	unsigned int file_offset;
	unsigned int NextEntryOffset;


[StructLayout(LayoutKind::Sequential, Size=0xC)]
ref struct CountEntry{

		unsigned int countentry;
		unsigned int countdirentry;
		unsigned int countfilesentry;


		

static CountEntry^  GetNumberEntry (String^ FolderPath, CountEntry^ CE){  // ����� ����������� ��� ��������� ���������� ������
				
				DirectoryInfo^ di = gcnew DirectoryInfo( FolderPath );
				array<DirectoryInfo^>^dAll = di->GetDirectories();
				array<FileInfo^>^ fAll = di->GetFiles();

				//count_entry++;

				if(0 != fAll->Length && 0 == dAll->Length){
					CE->countentry++;
					CE->countfilesentry /*= f_entry */+= fAll->Length;
				
				} else if(0 == fAll->Length && 0 == dAll->Length){
					CE->countentry++;

				} else if (0 != dAll->Length){
				
					CE->countentry++;
					CE->countfilesentry/* = f_entry */+= fAll->Length;

						for(int i = 0; i<dAll->Length; i++){
							CE->countdirentry ++;
								GetNumberEntry (dAll[i]->FullName, CE);
						} 
				}
				return CE;
		}



static CountEntry^ GetCountEntry(String^ Path){
		
//			for each(String^ PathFolder in Directory::GetDirectories(Path)) {
			CountEntry^ CE = gcnew CountEntry;
//			count_entry = 0;
//			d_entry = 0;
//			f_entry = 0;
//			CE = GetNumberEntry (Path, CE);/////////////////////////
//			CE->countentry = count_entry;
//			CE->countdirentry = d_entry;
//			CE->countfilesentry = f_entry;
//			count_entry = 0;///////
//			d_entry = 0;//////
//			f_entry = 0;//////
//		}
		return GetNumberEntry (Path, CE);
		}

};
[StructLayout(LayoutKind::Sequential, Size=0x40)]
ref struct RootEntry {

		unsigned int Count1;               // 
		unsigned int Count2;               // 
		[MarshalAs(UnmanagedType::ByValArray, SizeConst=0x2C)]
		array<Byte>^ Rootname;
		unsigned int pNextOffset;     //
		unsigned int Alllen;     //
		unsigned int Futter;     //


static	RootEntry^ GetRoot (BinaryReader^ br, int offset){

		RootEntry^ rootEntry = gcnew RootEntry;
		br->BaseStream->Seek(offset, System::IO::SeekOrigin::Begin);
		
		rootEntry->Count1 = br->ReadInt32();     //
		rootEntry->Count2 = br->ReadInt32(); 

		rootEntry->Rootname = gcnew array<Byte>(0x2C);
		for(int i=0;i<0x2C; i++){
		rootEntry->Rootname[i] = br->ReadByte();
		}
		rootEntry->pNextOffset = br->ReadInt32();     //
		rootEntry->Alllen = br->ReadInt32();     //
		rootEntry->Futter = br->ReadInt32();     //
		
		return rootEntry;

		}

static void/*BinaryWriter^*/ WriteRootEntry(BinaryWriter^ bw, String^ RootName/*, int pPrevEntry, int DirectorysCount, int FilesCount*/){
		
			bw->Write(0x1);     //
			bw->Write(0x1); 

		array<Byte>^ name = gcnew array<Byte>(0x2c);
		array<wchar_t>^ name1 = gcnew array<wchar_t>(0x2c);
		name1 = RootName->ToCharArray();
		for(int i=0;i<name1->Length; i++){
		name[i] = name1[i];
		}

			bw->Write(name, 0, 0x2C  );

			bw->Write(0x40);     //
			bw->Write(0x0);     //
			bw->Write(0x0);     //		
		
			//return bw;

		}

//static void /*MemoryStream^*/CreateRootEntryStream(MemoryStream^ stream, String^ RootName/*, int pPrevEntry, int DirectorysCount, int FilesCount*/){
//		
//			stream->Write(0x1);     //
//			stream->Write(0x1); 
//
//		array<Byte>^ name = gcnew array<Byte>(0x2c);
//		array<wchar_t>^ name1 = gcnew array<wchar_t>(0x2c);
//		name1 = RootName->ToCharArray();
//		for(int i=0;i<name1->Length; i++){
//		name[i] = name1[i];
//		}
//
//			stream->Write(name, 0, 0x2C  );
//
//			stream->Write(0x40);     //
//			stream->Write(0x0);     //
//			stream->Write(0x0);     //		
//		
//			//return bw;
//
//		}
};
[StructLayout(LayoutKind::Sequential, Size=12)]
ref struct Entry {
		unsigned int pPrevEntry;               // 
		unsigned int DirectorysCount;     //
		unsigned int FilesCount;          //
	
static Entry^ GetEntry(BinaryReader^ br, int offset){
		Entry^ entry = gcnew Entry;
		br->BaseStream->Seek(offset, System::IO::SeekOrigin::Begin);
		
		entry->pPrevEntry = br->ReadInt32();     //
		entry->DirectorysCount = br->ReadInt32();     //
		entry->FilesCount = br->ReadInt32();     //
		return entry;

		}

static Entry^ CreateEntry(int dircount, int filescount, int pPrevEntry){
		
		Entry^ entry = gcnew Entry;
		//br->BaseStream->Seek(offset, System::IO::SeekOrigin::Begin);
		
		entry->pPrevEntry = pPrevEntry;//br->ReadInt32();     //
		entry->DirectorysCount = dircount;//br->ReadInt32();     //
		entry->FilesCount = filescount;//br->ReadInt32();     //
		return entry;

		}


/*
static BinaryWriter^ WriteEntry(BinaryWriter^ bw, int pPrevEntry, int DirectorysCount, int FilesCount){
		
		bw->Write(pPrevEntry);     //
		bw->Write(DirectorysCount);     //
		bw->Write(FilesCount);     //
		return bw;

		}
	*/
static /*BinaryWriter^*/void WriteEntry(BinaryWriter^ bw, Entry^ entry){

		bw->Write(entry->pPrevEntry);     //
		bw->Write(entry->DirectorysCount);     //
		bw->Write(entry->FilesCount);     //
		//return /*entry*/bw;

		}
//static void/*BinaryWriter^*/ CreateEntryStream(MemoryStream^ stream, Entry^ entry){

//		stream->Write(entry->pPrevEntry);     //
//		stream->Write(entry->DirectorysCount);     //
//		stream->Write(entry->FilesCount);     //
		//return /*entry*/bw;

//		}
};
[StructLayout(LayoutKind::Sequential, Size=0x30)]
ref struct DirectoryEntry {
		[MarshalAs(UnmanagedType::ByValArray, SizeConst=0x2C)]
		array<Byte>^ Directoryname;
		unsigned int pNextOffset;     //
		unsigned int ChildLen;
		CountEntry^ count;
		String^ FullPath;


static	DirectoryEntry^ GetDirectory (BinaryReader^ br, int offset){

		DirectoryEntry^ directoryEntry = gcnew DirectoryEntry;
		br->BaseStream->Seek(offset, System::IO::SeekOrigin::Begin);
		
		directoryEntry->Directoryname = gcnew array<Byte>(0x2C);
		for(int i=0;i<0x2C; i++){
		directoryEntry->Directoryname[i] = br->ReadByte();
		}
		directoryEntry->pNextOffset = br->ReadInt32();     //
		return directoryEntry;

		}

static	DirectoryEntry^ CreateDirectoryEntry (DirectoryInfo^ di){

			DirectoryEntry^ directoryEntry = gcnew DirectoryEntry;
			directoryEntry->FullPath = di->FullName;
			array<Byte>^ name = gcnew array<Byte>(0x2c);
			array<wchar_t>^ name1 = gcnew array<wchar_t>(0x2c);
			name1 = di->Name->ToCharArray();
			for(int i=0;i<name1->Length; i++){
			name[i] = name1[i];
			}
			directoryEntry->Directoryname = name;
			
			CountEntry^ ce = gcnew CountEntry;
			ce = CountEntry::GetCountEntry(di->FullName);
			
			directoryEntry->count = ce;
			directoryEntry->ChildLen = (ce->countentry * EntryLen) + (ce->countdirentry * DirEntryLen) + (ce->countfilesentry * FileEntryLen);
			directoryEntry->pNextOffset = 0x0;     //
			return directoryEntry;

		}

static	void WriteDirectoryEntry (BinaryWriter^ bw, String^ DirectoryName, array<DirectoryInfo^>^dAll, array<FileInfo^>^ fAll, int count){

			array<Byte>^ name = gcnew array<Byte>(0x2c);
			array<wchar_t>^ name1 = gcnew array<wchar_t>(0x2c);
			name1 = DirectoryName->ToCharArray();
			for(int i=0;i<name1->Length; i++){
			name[i] = name1[i];
			}
		
			if(count==0){
				
				NextEntryOffset = bw->BaseStream->Position + dAll->Length * DirEntryLen + fAll->Length * FileEntryLen;
				bw->Write(name, 0, 0x2C  );
				bw->Write(NextEntryOffset);

			}else{
							
				CountEntry^ CoEn = gcnew CountEntry;
				CoEn = CountEntry::GetCountEntry(dAll[count-1]->FullName);
				
				//if(count==0)
				//NextEntryOffset = bw->BaseStream->Position + dAll->Length * DirEntryLen + fAll->Length * FileEntryLen;
				
//				NextEntryOffset = NextEntryOffset + CoEn->countdirentry * DirEntryLen + CoEn->countfilesentry * FileEntryLen + CoEn->countentry * EntryLen;/////////////
				bw->Write(name, 0, 0x2C  );
				NextEntryOffset = NextEntryOffset + CoEn->countdirentry * DirEntryLen + CoEn->countfilesentry * FileEntryLen + CoEn->countentry * EntryLen;/////////////
				bw->Write(NextEntryOffset);
			}

		}
//static	/*BinaryWriter^*/void CreateDirectoryEntryStream (MemoryStream^ stream, String^ DirectoryName, array<DirectoryInfo^>^dAll, array<FileInfo^>^ fAll, int count){
//
//			array<Byte>^ name = gcnew array<Byte>(0x2c);
//			array<wchar_t>^ name1 = gcnew array<wchar_t>(0x2c);
//			name1 = DirectoryName->ToCharArray();
//			for(int i=0;i<name1->Length; i++){
//			name[i] = name1[i];
//			}
//		
//			if(count==0){
//				
//				NextEntryOffset/*offset*/ = stream->Position + dAll->Length * DirEntryLen + fAll->Length * FileEntryLen;
//				stream->Write(name, 0, 0x2C  );
//				stream->Write(/*offset*/NextEntryOffset);
//
//			}else{
//							
//				CountEntry^ CoEn = gcnew CountEntry;
//				CoEn = CountEntry::GetCountEntry(dAll[count-1]->FullName);
//				stream->Write(name, 0, 0x2C  );
//				NextEntryOffset = /*offset*/NextEntryOffset + CoEn->countdirentry * DirEntryLen + CoEn->countfilesentry * FileEntryLen + CoEn->countentry * EntryLen;/////////////
//				stream->Write(NextEntryOffset);
//			}
//
//		}
};
[StructLayout(LayoutKind::Sequential, Size=0x34)]
ref struct FileEntry {
		//unsigned int pPrevEntry;               // 
		[MarshalAs(UnmanagedType::ByValArray, SizeConst=0x2C)]
		array<Byte>^ Filename;
		unsigned int DataOffset;     //
		unsigned int DataLen;          //
		String^ FullPath;
		


static	FileEntry^ GetFile (BinaryReader^ br, int offset){

		FileEntry^ fileEntry = gcnew FileEntry;
		br->BaseStream->Seek(offset, System::IO::SeekOrigin::Begin);
		
		fileEntry->Filename = gcnew array<Byte>(0x2C);
		for(int i=0;i<0x2C; i++){
		fileEntry->Filename[i] = br->ReadByte();
		}
		fileEntry->DataOffset = br->ReadInt32();     //
		fileEntry->DataLen = br->ReadInt32();          //
		return fileEntry;

		}

static	FileEntry^ CreateFileEntry (/*String^ FileName*/FileInfo^ fi){

			FileEntry^ fileEntry = gcnew FileEntry;
			fileEntry->FullPath = fi->FullName;
			array<Byte>^ name = gcnew array<Byte>(0x2c);
			array<wchar_t>^ name1 = gcnew array<wchar_t>(0x2c);
			name1 = fi->Name->ToCharArray();
			for(int i=0;i<name1->Length; i++){
			name[i] = name1[i];
			}
			fileEntry->Filename = name;
			
			fileEntry->DataOffset = file_offset;     //
			
			file_offset = file_offset + ALIGN(fi->Length,4);
			
			fileEntry->DataLen = fi->Length;
			return fileEntry;

		}

static /*BinaryWriter^*/void WriteFileEntry(BinaryWriter^ bw, FileEntry^ fe){

			bw->Write(fe->Filename, 0, /*0x2C*/fe->Filename->Length  );
			bw->Write(fe->DataOffset); //NextOffset
			bw->Write(fe->DataLen);
			int this_offset = bw->BaseStream->Position;
			bw->BaseStream->Seek(fe->DataOffset,SeekOrigin::Begin);
			//array <unsigned char>^ buff = File::ReadAllBytes(fe->FullPath);
			bw->Write(/*buff*/File::ReadAllBytes(fe->FullPath),0, /*buff->Length*/fe->DataLen);
			bw->BaseStream->Seek(this_offset,SeekOrigin::Begin);
			//return bw;

		}
//static /*BinaryWriter^*/void CreateFileEntryStream(MemoryStream^ stream, FileEntry^ fe){
//
//			stream->Write(fe->Filename, 0, /*0x2C*/fe->Filename->Length  );
//			stream->Write(fe->DataOffset); //NextOffset
//			stream->Write(fe->DataLen);
//			int this_offset = stream->Position;
//			stream->Seek(fe->DataOffset,SeekOrigin::Begin);
//			//array <unsigned char>^ buff = File::ReadAllBytes(fe->FullPath);
//			stream->Write(/*buff*/File::ReadAllBytes(fe->FullPath),0, /*buff->Length*/fe->DataLen);
//			stream->Seek(this_offset,SeekOrigin::Begin);
//			//return bw;
//
//		}
};
ref struct MainEntry {
		
		Entry^ Entr;
		array<DirectoryEntry^>^ DirEnt;
		array<FileEntry^>^ FilesEnt;





static MainEntry^ CreateMainEntry (String^ FolderPath, int pPrevEntry){  // ����� ����������� ��� ��������� ���������� ������
				
				DirectoryInfo^ di = gcnew DirectoryInfo( FolderPath );
				array<DirectoryInfo^>^diAll = di->GetDirectories();
				array<FileInfo^>^ fiAll = di->GetFiles();

				MainEntry^ ME = gcnew MainEntry;////
				ME->Entr = Entry::CreateEntry(diAll->Length, fiAll->Length, pPrevEntry);
				ME->DirEnt = gcnew array<DirectoryEntry^>(diAll->Length);
				ME->FilesEnt = gcnew array<FileEntry^>(fiAll->Length);
				
				if(0 != diAll->Length){
					for(int i = 0; i<diAll->Length; i++){
					//DirectoryEntry::WriteDirectoryEntry (bw, diAll[i]->Name);
					ME->DirEnt[i] =	DirectoryEntry::CreateDirectoryEntry (diAll[i]);
							
					int len = 0;
							for(int n=0; n<i; n++){
							len = len + ME->DirEnt[n]->ChildLen;
							}
					ME->DirEnt[i]->pNextOffset = RootEntryLen + EntryLen + diAll->Length * DirEntryLen + fiAll->Length * FileEntryLen + len;
					}
				} 
				if(0 != fiAll->Length){
					for(int i = 0; i<fiAll->Length; i++){
					//FileEntry::WriteDirectoryEntry (bw, diAll[i]->Name);
					ME->FilesEnt[i] =	FileEntry::CreateFileEntry (fiAll[i]);
					
					}
				} 


				return ME;
		}


static void/*BinaryWriter^*/ WriteMainEntry(BinaryWriter^ bw, MainEntry^ me){
		
			bw->Write(me->Entr->pPrevEntry);
			bw->Write(me->Entr->DirectorysCount);
			bw->Write(me->Entr->FilesCount);
			for(int i=0; i<me->DirEnt->Length; i++){
				bw->Write(me->DirEnt[i]->Directoryname,0,/*0x2C*/ me->DirEnt[i]->Directoryname->Length);
				bw->Write(me->DirEnt[i]->pNextOffset);
			}
//			
			for(int i=0; i<me->FilesEnt->Length; i++){
				bw->Write(me->FilesEnt[i]->Filename,0,/*0x2C*/ me->FilesEnt[i]->Filename->Length);
				bw->Write(me->FilesEnt[i]->DataOffset);
				bw->Write(me->FilesEnt[i]->DataLen);
			}

//

			//return bw;

		}

//static void/*BinaryWriter^*/ CreateMainEntryStream(MemoryStream^ stream, MainEntry^ me){
//		
//			stream->Write(me->Entr->pPrevEntry);
//			stream->Write(me->Entr->DirectorysCount);
//			stream->Write(me->Entr->FilesCount);
//			for(int i=0; i<me->DirEnt->Length; i++){
//				stream->Write(me->DirEnt[i]->Directoryname,0, me->DirEnt[i]->Directoryname->Length);
//				stream->Write(me->DirEnt[i]->pNextOffset);
//			}
//			//return bw;
//
//		}
};
void WriteNextEntry (String^ FolderPath, BinaryWriter^ bw, int pPrefOffset){  // 
				
				DirectoryInfo^ di = gcnew DirectoryInfo( FolderPath );
				array<DirectoryInfo^>^dAll = di->GetDirectories();
				array<FileInfo^>^ fAll = di->GetFiles();


				if(0 != fAll->Length && 0 == dAll->Length){
					
					//count_entry++;
					int entry_offset0 = bw->BaseStream->Position;
					
					Entry^ en = Entry::CreateEntry(dAll->Length,fAll->Length, pPrefOffset);
					Entry::WriteEntry(bw,en);
					
					pPrefOffset = entry_offset0;
					
					//f_entry = f_entry + fAll->Length;
					for(int i = 0; i<fAll->Length; i++){
						FileEntry^ fe = FileEntry::CreateFileEntry(fAll[i]);
						FileEntry::WriteFileEntry(bw,fe);
					}
				
				} else if (0 != dAll->Length){
				
					int entry_offset1 = bw->BaseStream->Position;

					Entry^ en = Entry::CreateEntry(dAll->Length,fAll->Length,pPrefOffset);
					Entry::WriteEntry(bw,en);

					pPrefOffset = entry_offset1;
							for(int n = 0; n<dAll->Length; n++){
								DirectoryEntry::WriteDirectoryEntry (bw, dAll[n]->Name, dAll, fAll, n/*, offset*/);
							}

							for(int i = 0; i<fAll->Length; i++){
								FileEntry^ fe = FileEntry::CreateFileEntry(fAll[i]);
								FileEntry::WriteFileEntry(bw,fe);
							}


				}else if(0 == fAll->Length && 0 == dAll->Length){

					int entry_offset2 = bw->BaseStream->Position;

					Entry^ en = Entry::CreateEntry(dAll->Length,fAll->Length,pPrefOffset);
					Entry::WriteEntry(bw,en);

					pPrefOffset = entry_offset2;


				}
				
							for(int i = 0; i<dAll->Length; i++){
								WriteNextEntry (dAll[i]->FullName, bw, pPrefOffset);
							} 

				//return;
		}

		// void CreateNextEntryStream (String^ FolderPath, MemoryStream^ stream, int pPrefOffset){  // 
		//		
		//		DirectoryInfo^ di = gcnew DirectoryInfo( FolderPath );
		//		array<DirectoryInfo^>^dAll = di->GetDirectories();
		//		array<FileInfo^>^ fAll = di->GetFiles();


		//		if(0 != fAll->Length && 0 == dAll->Length){
		//			
		//			//count_entry++;
		//			int entry_offset0 = stream->Position;
		//			
		//			Entry^ en = Entry::CreateEntry(dAll->Length,fAll->Length, pPrefOffset);
		//			Entry::CreateEntryStream(stream,en);//////Write
		//			
		//			pPrefOffset = entry_offset0;
		//			
		//			for(int i = 0; i<fAll->Length; i++){
		//				FileEntry^ fe = FileEntry::CreateFileEntry(fAll[i]);
		//				FileEntry::CreateFileEntryStream(stream,fe);////Write
		//			}
		//		
		//		} else if (0 != dAll->Length){
		//		
		//			int entry_offset1 = stream->Position;

		//			Entry^ en = Entry::CreateEntry(dAll->Length,fAll->Length,pPrefOffset);
		//			Entry::CreateEntryStream(stream,en);/////Write

		//			pPrefOffset = entry_offset1;
		//					for(int n = 0; n<dAll->Length; n++){
		//						DirectoryEntry::/*Write*/CreateDirectoryEntryStream (stream, dAll[n]->Name, dAll, fAll, n/*, offset*/);
		//					}

		//					for(int i = 0; i<fAll->Length; i++){
		//						FileEntry^ fe = FileEntry::CreateFileEntry(fAll[i]);
		//						FileEntry::/*Write*/CreateFileEntryStream(stream,fe);//Write
		//					}


		//		}else if(0 == fAll->Length && 0 == dAll->Length){

		//			int entry_offset2 = stream->Position;

		//			Entry^ en = Entry::CreateEntry(dAll->Length,fAll->Length,pPrefOffset);
		//			Entry::/*Write*/CreateEntryStream(stream,en);

		//			pPrefOffset = entry_offset2;


		//		}
		//		
		//					for(int i = 0; i<dAll->Length; i++){
		//						/*Write*/CreateNextEntryStream (dAll[i]->FullName, stream, pPrefOffset);
		//					} 

		//		//return;
		//}


//	array<unsigned char>^ Decompress_RC1( array<unsigned char>^ decrypt, BackgroundWorker^ bwAsync){
//			
//	
//			MemoryStream^ stream = gcnew MemoryStream(decrypt);
//			BinaryReader^ br = gcnew BinaryReader( stream );
//
//			array<unsigned short>^ tab = gcnew array<unsigned short>(256){
//
//
//				
//					  1,     2,     3, 0x800, 0x100,     4,  0x20,     8,
//					  7, 0x400, 0x300,     6,  0x10,  0x40, 0x200,   0xC,
//					0xE,0x1000, 0x801,     5, 0x101, 0x600, 0x700,   0xF,
//				 0x1800,   0xA, 0xC00,  0x1C,  0x11,  0x80,  0x18,  0xC0,
//				  0x500,0xFFFF,   0xD,   0xB,     9,0xFF00,  0x14,0x4000,
//				   0x1F,  0x1D,  0x1E,  0x16, 0xE00,  0x12,  0x17, 0xA00,
//				   0x30, 0xF00,  0x1A, 0x202,0x2000,  0x60,  0x15,  0x41,
//				   0x19,  0x21,  0x1B,0x1C00,0x1100, 0x303, 0xD00,  0x13,
//				  0x900, 0x404,0x1400,  0xC1,0x3000, 0x103,0x2020, 0x106,
//				  0x102, 0xB00,  0x38,0x1A00,0x1E00,  0x50,  0x3C,0x1F00,
//				  0x840,0x1200,0x1600, 0x301, 0x820,  0x44,0x1D00,  0x23,
//				 0x3800, 0x606,  0x28, 0x841,  0xFF,0x5000,  0x22, 0x110,
//				   0x2A, 0x707,  0x3F,  0x34,  0x70,  0x24,  0x3E,0x1001,
//				 0x1500, 0x107,0x1300,0x1700, 0x104,0x1900, 0x802,0x1010,
//				   0x43, 0x302,  0x32, 0x201,  0x3A,  0x36, 0x701,0x1B00,
//				  0x8C0,0x4400, 0x505,  0x3B,  0x26,  0xE3,  0x31,  0xFA,
//				   0x3D,  0x39,  0x37, 0x803,  0x35,  0x2E,  0x27,  0xE0,
//				   0xA0,  0x61,  0x78,  0x2C,  0x58,  0x33,0x7000, 0x203,
//				   0x2F,0x2800,  0x25,  0x52,  0x4F, 0x808, 0x1C0,  0x42,
//				 0x1840,  0x2B,0xF81E,0x1111,  0x4E,  0xD0,  0x29, 0x105,
//				  0x111, 0xC0C, 0x8C1,  0x45,  0x47, 0x402, 0x10E, 0x602,
//				   0x68,0x1801,0x1101,0x6000, 0xE0E,  0x2D,  0x88, 0x601,
//				  0x401,0x7800,0x2600,  0x54, 0x108,0x1D1D,0x1820, 0x206,
//				  0x1F0,  0xE2,  0x48, 0x10F, 0xE02,  0x49,0x2E00,  0x82,
//				   0xB0, 0x706, 0x880,  0xF8,0x3400, 0x20C,0x1040,  0xD8,
//				  0x504, 0x204, 0x7C0,  0x63, 0x821,  0x90,0x2400, 0x410,
//				  0x607,  0x64, 0x405,  0xFE, 0x860, 0xF0F,0x1803,0x2200,
//				   0x74,0x5400, 0x8E3,0x2A00, 0xA0A,0x3C00,0x1110, 0xD0D,
//				  0xB0B, 0x703, 0xC02,  0x5B,0x5200, 0x861, 0x604,  0x62,
//				 0x3200,  0x7F,  0x7A,  0xF0,0x2C00,  0x4C,0x4E00, 0x406,
//				 0x5B00,0x5B5B,  0xC8,0x4100, 0x10A,  0x46,0x3A00,  0x7C,
//				   0x4D, 0xA96,0xFFFE, 0x304,0x3600, 0x501, 0xF01,0x3F00
//				
//				};                            
//
//				int first = br->ReadInt32();
//				int len_1 = br->ReadInt32();
//				int len_2 = br->ReadInt32();
//
//				array<unsigned char>^ block_1 = gcnew array<unsigned char>(len_1 + 0x100);
//				array<unsigned char>^ block_2 = gcnew array<unsigned char>(len_2 + 0x100);
//				array<unsigned char>^ block_3 = gcnew array<unsigned char>((br->BaseStream->Length -(len_1 + len_2 + 0xC)) + 0x100);
//
//				br->Read(block_1, 0, len_1);
//				MemoryStream^ StreamBlock1 = gcnew MemoryStream( block_1->Length );
//				StreamBlock1->Write(block_1, 0, block_1->Length);
//				StreamBlock1->Seek(0, SeekOrigin::Begin);
//
//				br->Read(block_2, 0, len_2);
//				MemoryStream^ StreamBlock2 = gcnew MemoryStream( block_2->Length );
//				StreamBlock2->Write(block_2, 0, block_2->Length);
//				StreamBlock2->Seek(0, SeekOrigin::Begin);
//
//				br->Read(block_3, 0, block_3->Length);
//
//				MemoryStream^ StreamBlock3 = gcnew MemoryStream( (first >> 4 << 2)  /*0x4000*/ ); ///������ ����� ��������.
//				StreamBlock3->Seek(0, SeekOrigin::Begin);
//					
//				br->Close();
//
//				unsigned int R8 = 0;
//				int R9 = 0;
//
//				unsigned int offset = 0;
//				/////���������� �� 3 ����� 16 ���� � �����
//				StreamBlock3->Write(block_3, offset, 0x10);
//				offset += 0x10;
//
//
//				int var30 = first >> 4 << 2;//0x400;
//				//int R10 = 4;
//				/*long*/unsigned short R6 = 1;
//				
//				for(int R10 = 4; R10 < var30; R10 += 4){
////������ ���������
//				while(R8 <= 2){	////////////
//				R9 = ((StreamBlock1->ReadByte() << (0x18 - R8)) | R9);
//				R8 += 8;
//				}
//				
//				R8 -= 1;
//
//				if(R9 >= 0){//BGE ������ ��� �����, �������� ��������� ///�������� �������� �� ������������
//					
//				R9 = R9 << 1;
//						
//						if( R9 >= 0){ //BPL ������������� ��������, ������ ��� ����� ����
//							StreamBlock3->Write(block_3, offset, 0x10);
//								offset +=0x10;
//						}else{
//
//
//							for(int i = 0; i < 0x10; i ++){
//								int off = R6;
//								StreamBlock3->Seek(- off, SeekOrigin::Current);
//								unsigned char a;
//								a = StreamBlock3->ReadByte();//(temp, 0, 0x2);
//								StreamBlock3->Seek(0, SeekOrigin::End);
//								StreamBlock3->WriteByte(a);//Write(temp, 0, 0x2);
//							}
//						} //if(s >= 0){ //BPL ������������� ��������, ������ ��� ����� ����
//				
//				R8 -= 1;
//				R9 = R9 << 1;
////������ ���������
//
//				}else{
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//					/*unsigned*/ int/*char*/ b2 = StreamBlock2->ReadByte();
//					R9 = R9 << 1;
//
//						while(R8 < 0x10){	
//						R9 = (( StreamBlock1->ReadByte() << (0x18 - R8)) | R9);
//						R8 += 8;
//						}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////						
//							if(R9 >= 0){ //BLT (���������� ���� ��������� ��� ��������)
//								R9 = R9 << 1;
//								R8 -= 1;
//										if(R9 >= 0){ //BPL
//										//��������� 2 ����� �� 3 �����
//											unsigned char a = block_3[offset + 1];
//											unsigned char b = block_3[offset];
//											R6 = a << 8;
//											R6 = R6 | b;
//											offset += 2;
//										}else{
//										//��������� 1 ���� �� 2 �����
//											R6 = (StreamBlock2->ReadByte());
//										}
//							}
//									
//										R9 = R9 << 1;
//										R8 -= 1;
///////////////////////////////////////////////////////////////////////////////////////////////////////////									
//									if(R6 > R10<<2/*1*/){ return nullptr; }///// ��������� !!!!!!!!!!!!!!!!!//R6
//									
//									//if((int)(b2<<0x18)>= 0){
//									if((b2 << 0x18) >= 0 ){  //R0
//										if(R9 >= 0){
//
//											//int pos = StreamBlock3->Position;
//											int off = R6;
//										StreamBlock3->Seek(- off, SeekOrigin::Current);
//										unsigned char g = StreamBlock2->ReadByte();
//										unsigned char h = StreamBlock3->ReadByte();
//										unsigned short f  = tab[ g];
//										unsigned short a = h ^ f ;
//										StreamBlock3->Seek(0, SeekOrigin::End);
//										StreamBlock3->WriteByte(a);
//
//										StreamBlock3->Seek(- off, SeekOrigin::Current);
//										//g = StreamBlock2->ReadByte();
//										h = StreamBlock3->ReadByte();
//										//f  = tab[ g];
//										a = h ^ (f>>8);
//										StreamBlock3->Seek(0, SeekOrigin::End);
//										StreamBlock3->WriteByte(a);
//
//										}else{
//											StreamBlock3->WriteByte(block_3[offset]);
//											StreamBlock3->WriteByte(block_3[offset + 1]);
//											offset += 2;
//										}
//									
//											R9 = R9 << 1;
//											R8 -= 1;
//
//									}else{
//
//									int off = R6;
//									StreamBlock3->Seek(- off, SeekOrigin::Current);
//									unsigned char a = StreamBlock3->ReadByte();;
//									StreamBlock3->Seek(0, SeekOrigin::End);
//									StreamBlock3->WriteByte(a);
//									StreamBlock3->Seek(- off, SeekOrigin::Current);
//									a = StreamBlock3->ReadByte();;
//									StreamBlock3->Seek(0, SeekOrigin::End);
//									StreamBlock3->WriteByte(a);
//
//									} //R0
///////////////////////////////////////////////////////////////////////////////////////////////////////////
//									
//									if((b2 << 0x19) >= 0 ){
//										
//										if(R9 >= 0){
//											
//										int off = R6;
//										StreamBlock3->Seek(- off, SeekOrigin::Current);
//										unsigned char g = StreamBlock2->ReadByte();
//										unsigned char h = StreamBlock3->ReadByte();
//										unsigned short f  = tab[ g];
//										unsigned short a = h ^ f ;
//										StreamBlock3->Seek(0, SeekOrigin::End);
//										StreamBlock3->WriteByte(a);
//
//										StreamBlock3->Seek(- off, SeekOrigin::Current);
//										h = StreamBlock3->ReadByte();
//										a = h ^ (f>>8);
//										StreamBlock3->Seek(0, SeekOrigin::End);
//										StreamBlock3->WriteByte(a);
//
//										}else{
//											
//											StreamBlock3->WriteByte(block_3[offset]);
//											StreamBlock3->WriteByte(block_3[offset + 1]);
//											offset += 2;
//										}
//											R9 = R9 << 1;
//											R8 -= 1;
//
//									}else{//////
//									
//									int off = R6;
//									StreamBlock3->Seek(- off, SeekOrigin::Current);
//									unsigned char a = StreamBlock3->ReadByte();;
//									StreamBlock3->Seek(0, SeekOrigin::End);
//									StreamBlock3->WriteByte(a);
//									StreamBlock3->Seek(- off, SeekOrigin::Current);
//									a = StreamBlock3->ReadByte();;
//									StreamBlock3->Seek(0, SeekOrigin::End);
//									StreamBlock3->WriteByte(a);
//
//									}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////���������   
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//								if(R9 >= 0){ //BLT (���������� ���� ��������� ��� ��������)
//								R9 = R9 << 1;
//								R8 -= 1;
//									
//										if(R9 >= 0){
//										//��������� 2 ����� �� 3 �����
//											unsigned char a = block_3[offset + 1];
//											unsigned char b = block_3[offset];
//											R6 = a << 8;
//											R6 = R6 | b;
//											offset += 2;
//										}else{
//										//��������� 1 ���� �� 2 �����
//											R6 = (StreamBlock2->ReadByte());
//										}
//								}
//									
//										R9 = R9 << 1;
//										R8 -= 1;
///////////////////////////////////////////////////////////////////////////////////////////////////////////									
//									if(R6 > R10<<3){return nullptr; }///// ��������� !!!!!!!!!!!!!!!!!//R6
//									
//									if((b2<<0x1A) >= 0){
//										if(R9 >= 0){
//
//										int off = R6;
//										StreamBlock3->Seek(- off, SeekOrigin::Current);
//										unsigned char g = StreamBlock2->ReadByte();
//										unsigned char h = StreamBlock3->ReadByte();
//										unsigned short f  = tab[ g];
//										unsigned short a = h ^ f ;
//										StreamBlock3->Seek(0, SeekOrigin::End);
//										StreamBlock3->WriteByte(a);
//
//										StreamBlock3->Seek(- off, SeekOrigin::Current);
//										h = StreamBlock3->ReadByte();
//										a = h ^ (f>>8);
//										StreamBlock3->Seek(0, SeekOrigin::End);
//										StreamBlock3->WriteByte(a);
//
//
//										}else{
//											StreamBlock3->WriteByte(block_3[offset]);
//											StreamBlock3->WriteByte(block_3[offset + 1]);
//											offset += 2;
//
//										}
//									
//											R9 = R9 << 1;
//											R8 -= 1;
//
//									}else{
//
//									int off = R6;
//									StreamBlock3->Seek(- off, SeekOrigin::Current);
//									unsigned char a = StreamBlock3->ReadByte();;
//									StreamBlock3->Seek(0, SeekOrigin::End);
//									StreamBlock3->WriteByte(a);
//									StreamBlock3->Seek(- off, SeekOrigin::Current);
//									a = StreamBlock3->ReadByte();;
//									StreamBlock3->Seek(0, SeekOrigin::End);
//									StreamBlock3->WriteByte(a);
//
//									} //R0
///////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//									if((b2 << 0x1B) >= 0 ){
//										
//										if(R9 >= 0){
//											
//										int off = R6;
//										StreamBlock3->Seek(- off, SeekOrigin::Current);
//										unsigned char g = StreamBlock2->ReadByte();
//										unsigned char h = StreamBlock3->ReadByte();
//										unsigned short f  = tab[ g];
//										unsigned short a = h ^ f ;
//										StreamBlock3->Seek(0, SeekOrigin::End);
//										StreamBlock3->WriteByte(a);
//
//										StreamBlock3->Seek(- off, SeekOrigin::Current);
//										h = StreamBlock3->ReadByte();
//										a = h ^ (f>>8);
//										StreamBlock3->Seek(0, SeekOrigin::End);
//										StreamBlock3->WriteByte(a);
//
//										}else{
//											
//											StreamBlock3->WriteByte(block_3[offset]);
//											StreamBlock3->WriteByte(block_3[offset + 1]);
//											offset += 2;
//
//										}
//
//											R9 = R9 << 1;
//											R8 -= 1;
//
//									}else{
//									
//									int off = R6;
//									StreamBlock3->Seek(- off, SeekOrigin::Current);
//									unsigned char a = StreamBlock3->ReadByte();;
//									StreamBlock3->Seek(0, SeekOrigin::End);
//									StreamBlock3->WriteByte(a);
//									StreamBlock3->Seek(- off, SeekOrigin::Current);
//									a = StreamBlock3->ReadByte();;
//									StreamBlock3->Seek(0, SeekOrigin::End);
//									StreamBlock3->WriteByte(a);
//
//									}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////��������� 2 8 ����
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//								if(R9 >= 0){ //BLT (���������� ���� ��������� ��� ��������)
//								R9 = R9 << 1;
//								R8 -= 1;
//
//										if(R9 >= 0){ //BPL
//										//��������� 2 ����� �� 3 �����
//											unsigned char a = block_3[offset + 1];
//											unsigned char b = block_3[offset];
//											R6 = a << 8;
//											R6 = R6 | b;//////////////////////////////////////
//											offset += 2;
//										}else{
//										//��������� 1 ���� �� 2 �����
//											R6 = (StreamBlock2->ReadByte());
//										}
//								}
//									
//										R9 = R9 << 1;
//										R8 -= 1;
///////////////////////////////////////////////////////////////////////////////////////////////////////////									
//									if(R6 > R10 << 4){return nullptr; }///// ��������� !!!!!!!!!!!!!!!!!//R6
//									
//									if((b2 << 0x1C) >= 0 ){  //R0
//										if(R9 >= 0){
//
//											int off = R6;
//										StreamBlock3->Seek(- off, SeekOrigin::Current);
//										unsigned char g = StreamBlock2->ReadByte();
//										unsigned char h = StreamBlock3->ReadByte();
//										unsigned short f  = tab[ g];
//										unsigned short a = h ^ f ;
//										StreamBlock3->Seek(0, SeekOrigin::End);
//										StreamBlock3->WriteByte(a);
//
//										StreamBlock3->Seek(- off, SeekOrigin::Current);
//										h = StreamBlock3->ReadByte();
//										a = h ^ (f>>8);
//										StreamBlock3->Seek(0, SeekOrigin::End);
//										StreamBlock3->WriteByte(a);
//
//
//										}else{
//											StreamBlock3->WriteByte(block_3[offset]);
//											StreamBlock3->WriteByte(block_3[offset + 1]);
//											offset += 2;
//
//										}
//									
//											R9 = R9 << 1;
//											R8 -= 1;
//
//									}else{
//
//									int off = R6;
//									StreamBlock3->Seek(- off, SeekOrigin::Current);
//									unsigned char a = StreamBlock3->ReadByte();;
//									StreamBlock3->Seek(0, SeekOrigin::End);
//									StreamBlock3->WriteByte(a);
//									StreamBlock3->Seek(- off, SeekOrigin::Current);
//									a = StreamBlock3->ReadByte();;
//									StreamBlock3->Seek(0, SeekOrigin::End);
//									StreamBlock3->WriteByte(a);
//
//									} //R0
///////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//									if((b2 << 0x1D) >= 0 ){
//										
//										if(R9 >= 0){
//											
//											int off = R6;
//										StreamBlock3->Seek(- off, SeekOrigin::Current);
//										unsigned char g = StreamBlock2->ReadByte();
//										unsigned char h = StreamBlock3->ReadByte();
//										unsigned short f  = tab[ g];
//										unsigned short a = h ^ f ;
//										StreamBlock3->Seek(0, SeekOrigin::End);
//										StreamBlock3->WriteByte(a);
//
//										StreamBlock3->Seek(- off, SeekOrigin::Current);
//										h = StreamBlock3->ReadByte();
//										a = h ^ (f>>8);
//										StreamBlock3->Seek(0, SeekOrigin::End);
//										StreamBlock3->WriteByte(a);
//
//
//										}else{
//											
//											StreamBlock3->WriteByte(block_3[offset]);
//											StreamBlock3->WriteByte(block_3[offset + 1]);
//											offset += 2;
//
//										}
//
//											R9 = R9 << 1;
//											R8 -= 1;
//
//									}else{
//									
//									int off = R6;
//									StreamBlock3->Seek(- off, SeekOrigin::Current);
//									unsigned char a = StreamBlock3->ReadByte();;
//									StreamBlock3->Seek(0, SeekOrigin::End);
//									StreamBlock3->WriteByte(a);
//									StreamBlock3->Seek(- off, SeekOrigin::Current);
//									a = StreamBlock3->ReadByte();;
//									StreamBlock3->Seek(0, SeekOrigin::End);
//									StreamBlock3->WriteByte(a);
//
//									}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////��������� 3  12   -    4 ����
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//									if(R9 >= 0){ //BLT (���������� ���� ��������� ��� ��������)
//									R9 = R9 << 1;
//									R8 -= 1;
//											if(R9 >= 0){ //BPL
//											//��������� 2 ����� �� 3 �����
//												unsigned char a = block_3[offset + 1];
//												unsigned char b = block_3[offset];
//												R6 = a << 8;
//												R6 = R6 | b;
//												offset += 2;
//											}else{
//										//��������� 1 ���� �� 2 �����
//												R6 = (StreamBlock2->ReadByte());
//											}
//									}
//									
//											R9 = R9 << 1;
//											R8 -= 1;
///////////////////////////////////////////////////////////////////////////////////////////////////////////									
//									if(R6 >= R10<<5){ return nullptr; }///// ��������� !!!!!!!!!!!!!!!!!//R6
//
//									if((b2 << 0x1E) >= 0 ){  //R0
//										
//										if(R9 >= 0){
//											
//											int off = R6;
//										StreamBlock3->Seek(- off, SeekOrigin::Current);
//										unsigned char g = StreamBlock2->ReadByte();
//										unsigned char h = StreamBlock3->ReadByte();
//										unsigned short f  = tab[ g];
//										unsigned short a = h ^ f ;
//										StreamBlock3->Seek(0, SeekOrigin::End);
//										StreamBlock3->WriteByte(a);
//
//										StreamBlock3->Seek(- off, SeekOrigin::Current);
//										h = StreamBlock3->ReadByte();
//										a = h ^ (f>>8);
//										StreamBlock3->Seek(0, SeekOrigin::End);
//										StreamBlock3->WriteByte(a);
//
//										}else{
//											StreamBlock3->WriteByte(block_3[offset]);
//											StreamBlock3->WriteByte(block_3[offset + 1]);
//											offset += 2;
//
//										}
//									
//											R9 = R9 << 1;
//											R8 -= 1;
//
//									}else{
//
////////////++++++++//////									//int pos = StreamBlock3->Position;
//									int off = R6;
//									StreamBlock3->Seek(- off, SeekOrigin::Current);
//									unsigned char a = StreamBlock3->ReadByte();;
//									StreamBlock3->Seek(0, SeekOrigin::End);
//									StreamBlock3->WriteByte(a);
//									StreamBlock3->Seek(- off, SeekOrigin::Current);
//									a = StreamBlock3->ReadByte();;
//									StreamBlock3->Seek(0, SeekOrigin::End);
//									StreamBlock3->WriteByte(a);
//
//									} //R0
///////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//									if((b2 << 0x1F) >= 0 ){
//										
//										if(R9 >= 0){
//											
//											int off = R6;
//										StreamBlock3->Seek(- off, SeekOrigin::Current);
//										unsigned char g = StreamBlock2->ReadByte();
//										unsigned char h = StreamBlock3->ReadByte();
//										unsigned short f  = tab[ g];
//										unsigned short a = h ^ f ;
//										StreamBlock3->Seek(0, SeekOrigin::End);
//										StreamBlock3->WriteByte(a);
//
//										StreamBlock3->Seek(- off, SeekOrigin::Current);
//										h = StreamBlock3->ReadByte();
//										a = h ^ (f>>8);
//										StreamBlock3->Seek(0, SeekOrigin::End);
//										StreamBlock3->WriteByte(a);
//
//
//										}else{
//											
//											StreamBlock3->WriteByte(block_3[offset]);
//											StreamBlock3->WriteByte(block_3[offset + 1]);
//											offset += 2;
//
//										}
//
//											R9 = R9 << 1;
//											R8 -= 1;
//
//									}else{
//									
//									int off = R6;
//									StreamBlock3->Seek(- off, SeekOrigin::Current);
//									unsigned char a = StreamBlock3->ReadByte();;
//									StreamBlock3->Seek(0, SeekOrigin::End);
//									StreamBlock3->WriteByte(a);
//									StreamBlock3->Seek(- off, SeekOrigin::Current);
//									a = StreamBlock3->ReadByte();;
//									StreamBlock3->Seek(0, SeekOrigin::End);
//									StreamBlock3->WriteByte(a);
//
//									}
//
//					}//else{	//if(R9 >= 0){//BGE ������ ��� �����, �������� ��������� ///�������� �������� �� ������������
//
//				
//				} // for
//
//				array<unsigned char>^ decompress = gcnew array<unsigned char>(StreamBlock3->Length);
//				StreamBlock3->Seek(0, SeekOrigin::Begin);
//				StreamBlock3->Read(decompress, 0, decompress->Length);
//
//				return decompress;
//
//
//
//
//	}

	//array<unsigned char>^ Parser_RC1(array<unsigned char>^ decompress, String^ foldername, BackgroundWorker^ bwAsync){
	//			

	//			int  type;

	//			BinaryWriter^ bw2 = gcnew BinaryWriter(File::Create(String::Concat(foldername, L"\\name.bin"))); 
	//			bw2->BaseStream->Write(decompress,0,0x100);
	//			bw2->Close();
	//			
	//			
	//			MemoryStream^ myStreamParser = gcnew MemoryStream(decompress);
	//			BinaryReader^ br = gcnew BinaryReader(myStreamParser);
	//			
	//			br->BaseStream->Seek(0x14, SeekOrigin::Begin);
	//			int len_file = br->ReadInt32();
	//			
	//			br->BaseStream->Seek(0x100, SeekOrigin::Begin);
	//			MemoryStream^ Stream = gcnew MemoryStream();
	//			BinaryWriter^ bw = gcnew BinaryWriter(Stream);
	//			

	//			while((type = br->ReadInt32()) != 0){
	//			int len = br->ReadInt32();
	//			int offset = br->ReadUInt32();
	//			int position2 = br->BaseStream->Position;
	//			
	//			array<unsigned char>^ CompressedBlock = gcnew array<unsigned char>(len);
	//			
	//			switch(type){

	//			case 0xF:
	//			case 0xA:
	//			case 0x3:
	//					br->BaseStream->Seek(offset, SeekOrigin::Begin);
	//					br->BaseStream->Read(CompressedBlock, 0, len);
	//					bw->BaseStream->Write(CompressedBlock, 0, len);
	//				break;
	//			
	//			case 0x8:
	//					int position = br->BaseStream->Position;
	//					br->BaseStream->Seek(offset, SeekOrigin::Begin);
	//					unsigned int LenBlock = 0;
	//					int m = 0;
	//					
	//					for(int i = 0; i < 0x40; i++){
	//						LenBlock = br->ReadInt16();
	//						int position1 = br->BaseStream->Position;

	//						br->BaseStream->Seek(offset + 0x80 + m, SeekOrigin::Begin);
	//						br->BaseStream->Read(CompressedBlock, 0, LenBlock);
	//					if(LenBlock == 0x1000){
	//					
	//						bw->BaseStream->Write(CompressedBlock, 0, LenBlock);	
	//					}else{
	//					
	//						bw->BaseStream->Write((Decompress_RC1(CompressedBlock, bwAsync)), 0, 0x1000);
	//						bwAsync->ReportProgress(Convert::ToInt32( br->BaseStream->Position *  100 / br->BaseStream->Length));
	//					}
	//						m += LenBlock;
	//						br->BaseStream->Seek(position1, SeekOrigin::Begin);

	//					}
	//					br->BaseStream->Seek(position, SeekOrigin::Begin);

	//					break;
	//				}//case
	//					
	//			br->BaseStream->Seek(position2, SeekOrigin::Begin);

	//		}//while

	//				array<unsigned char>^ bufname = gcnew array<unsigned char>(0x400);
	//				br->BaseStream->Seek(len_file, SeekOrigin::Begin);
	//				br->Read(bufname,0,0x400);
	//				BinaryWriter^ bw1 = gcnew BinaryWriter(File::Create(String::Concat(foldername, L"\\end.bin"))); 
	//				bw1->BaseStream->Write(bufname,0,0x400);
	//				bw1->Close();


	//				array<unsigned char>^ decrypt_decompress = gcnew array<unsigned char>(bw->BaseStream->Length);
	//				bw->BaseStream->Seek(0,SeekOrigin::Begin);
	//				bw->BaseStream->Read(decrypt_decompress, 0, decrypt_decompress->Length);

	//				bw->Close();
	//				br->Close();

	//				return decrypt_decompress;

	//}
String^ GetStringRc1(array<unsigned char>^ buff){
				System::Text::Encoding^ encoding = System::Text::Encoding::UTF8;
				String^ path = "";
				
				for (Int32 i = 0; i < 0x2c; i++){
					if( 0 != static_cast<Byte>(buff->GetValue(i)) ){
               		path = String::Concat(path, encoding->GetString( buff,i,1 ));
					}else{continue;}
				}
				return path;
	}


void WriteDumpRc1(BinaryReader^ br, String^ rootpath, int offset, BackgroundWorker^ bwAsync){
				
				Entry^ entry = Entry::GetEntry(br, offset);
				if(0 != entry->DirectorysCount){
					for(int i = 0; i<entry->DirectorysCount; i++){
						DirectoryEntry^ direntry = DirectoryEntry::GetDirectory (br, br->BaseStream->Position);
						
						String^ path = GetStringRc1(direntry->Directoryname);
						path = rootpath + L"\\" + path;
						
						if(!Directory::Exists( path ))
						Directory::CreateDirectory( path );

						if(direntry->pNextOffset){
						int position = br->BaseStream->Position;
							
//						bwAsync->ReportProgress(Convert::ToInt32( br->BaseStream->Position *  100 / br->BaseStream->Length));
						
						WriteDumpRc1(br, path, direntry->pNextOffset, bwAsync);
						
//						bwAsync->ReportProgress(Convert::ToInt32( br->BaseStream->Position *  100 / br->BaseStream->Length));

						br->BaseStream->Seek(position, SeekOrigin::Begin);
						}
					}

				}/*else*/ 
				if(0 != entry->FilesCount){
					for(int i = 0; i < entry->FilesCount; i++){
						FileEntry^ filesentry = FileEntry::GetFile (br, br->BaseStream->Position);
						
						String^ path = GetStringRc1(filesentry->Filename);
						path = rootpath + L"\\" + path;
						int position = br->BaseStream->Position;
						
						array<unsigned char>^ bufdata = gcnew array<unsigned char>(filesentry->DataLen);

						BinaryWriter^ bw = gcnew BinaryWriter(File::Create(path)); 
						br->BaseStream->Seek(filesentry->DataOffset, SeekOrigin::Begin);
						br->Read(bufdata,0,filesentry->DataLen);
						bw->BaseStream->Write(bufdata,0,filesentry->DataLen);
						bw->Close();
						br->BaseStream->Seek(position, SeekOrigin::Begin);
					}

				}

				}	





void/*unsigned int*/ Save_file_org ( String^ SaveFile, TreeNode^ rootNode, BackgroundWorker^ bwAsync )
{

		BinaryWriter^ bw = gcnew BinaryWriter(File::Create(SaveFile)); 
		String^ RootName = static_cast <String^> (rootNode->FirstNode->Text);
		String^ ProjectFolderPath = static_cast <String^> (rootNode->FirstNode->Tag);
		
		int pEntry = bw->BaseStream->Position;
		RootEntry::WriteRootEntry(bw, RootName);//////

			
		MainEntry^ main_entry = MainEntry::CreateMainEntry(ProjectFolderPath, pEntry );//
		pEntry = bw->BaseStream->Position;
		MainEntry::WriteMainEntry(bw, main_entry);//////

		
		//MainEntry^ next_entry = MainEntry::CreateMainEntry(main_entry->DirEnt[0]->FullPath, pEntry );//
		file_offset = main_entry->DirEnt[main_entry->DirEnt->Length - 1]->pNextOffset + main_entry->DirEnt[main_entry->DirEnt->Length - 1]->ChildLen;
		int file_offset_ = main_entry->DirEnt[main_entry->DirEnt->Length - 1]->pNextOffset + main_entry->DirEnt[main_entry->DirEnt->Length - 1]->ChildLen;
		
		for(int i = 0; i<main_entry->DirEnt->Length; i++){
		WriteNextEntry( main_entry->DirEnt[i]->FullPath, bw, pEntry);
		}
		bw->BaseStream->Seek(0x38,SeekOrigin::Begin);
		bw->Write(bw->BaseStream->Length);
		bw->BaseStream->Seek(ALIGN(bw->BaseStream->Length,0x10000)-0x4,SeekOrigin::Begin);
		bw->Write(0x0);
		bw->Close();

		file_offset = 0;
		NextEntryOffset = 0;
//		autosign_file(SaveFile);

	//return true;
}

array<unsigned char>^ Create_file_org ( TreeNode^ rootNode, BackgroundWorker^ bwAsync )
{

		MemoryStream^ stream = gcnew MemoryStream();
		BinaryWriter^ bw = gcnew BinaryWriter(stream); 
		String^ RootName = static_cast <String^> (rootNode->FirstNode->FirstNode->Text);
		String^ ProjectFolderPath = static_cast <String^> (rootNode->FirstNode->FirstNode->Tag);
		
		int pEntry = bw->BaseStream->Position;
		RootEntry::WriteRootEntry(bw, RootName);//////

			
		MainEntry^ main_entry = MainEntry::CreateMainEntry(ProjectFolderPath, pEntry );//
		pEntry = bw->BaseStream->Position;
		MainEntry::WriteMainEntry(bw, main_entry);//////

		
		file_offset = main_entry->DirEnt[main_entry->DirEnt->Length - 1]->pNextOffset + main_entry->DirEnt[main_entry->DirEnt->Length - 1]->ChildLen;
		
		for(int i = 0; i<main_entry->DirEnt->Length; i++){
		WriteNextEntry( main_entry->DirEnt[i]->FullPath, bw, pEntry);
		}


		bw->BaseStream->Seek(0x38,SeekOrigin::Begin);
		bw->Write(Convert::ToInt32( bw->BaseStream->Length));
		bw->BaseStream->Seek(ALIGN(bw->BaseStream->Length,0x1000/*0*/),SeekOrigin::Begin);
		//bw->Write(0x0);
		
		while(bw->BaseStream->Position < ALIGN(bw->BaseStream->Length,0x40000))
//		bw->Write(0xFFFFFFFF);
		bw->Write(0x0);
		
		bw->BaseStream->Seek( ALIGN(bw->BaseStream->Length,0x40000), SeekOrigin::Begin);
		array<unsigned char>^ buf = File::ReadAllBytes(rootNode->FirstNode->Tag + "\\end.bin");
		bw->Write( buf, 0, buf->Length );

		file_offset = 0;
		NextEntryOffset = 0;

		array<unsigned char>^ rcs_part = stream->ToArray();
		bw->Close();
		stream->Close();

	return rcs_part;
}

array<unsigned char>^ Create_file_RC1 ( TreeNode^ rootNode, BackgroundWorker^ bwAsync )
{

		MemoryStream^ stream = gcnew MemoryStream();
		BinaryWriter^ bw = gcnew BinaryWriter(stream); 
		String^ RootName = static_cast <String^> (rootNode->FirstNode->Text);
		String^ ProjectFolderPath = static_cast <String^> (rootNode->FirstNode->Tag);
		
		int pEntry = bw->BaseStream->Position;
		RootEntry::WriteRootEntry(bw, RootName);//////

			
		MainEntry^ main_entry = MainEntry::CreateMainEntry(ProjectFolderPath, pEntry );//
		pEntry = bw->BaseStream->Position;
		MainEntry::WriteMainEntry(bw, main_entry);//////

		
		file_offset = main_entry->DirEnt[main_entry->DirEnt->Length - 1]->pNextOffset + main_entry->DirEnt[main_entry->DirEnt->Length - 1]->ChildLen;
		
		for(int i = 0; i<main_entry->DirEnt->Length; i++){
		WriteNextEntry( main_entry->DirEnt[i]->FullPath, bw, pEntry);
		}
		bw->BaseStream->Seek(0x38,SeekOrigin::Begin);
		bw->Write(Convert::ToInt32( bw->BaseStream->Length));
		bw->BaseStream->Seek(ALIGN(bw->BaseStream->Length,0x1000/*0*/),SeekOrigin::Begin);
		//bw->Write(0x0);
		
		while(bw->BaseStream->Position < ALIGN(bw->BaseStream->Length,0x40000))
//		bw->Write(0xFFFFFFFF);
		bw->Write(0x0);
		
		bw->BaseStream->Seek( ALIGN(bw->BaseStream->Length,0x40000), SeekOrigin::Begin);
		array<unsigned char>^ buf = File::ReadAllBytes(rootNode->Tag + "\\end.bin");
		bw->Write( buf, 0, buf->Length );

		file_offset = 0;
		NextEntryOffset = 0;

		array<unsigned char>^ rcs_part = stream->ToArray();
		bw->Close();
		stream->Close();

	return rcs_part;
}

array<unsigned char>^ DecryptCompressedBin( array<unsigned char>^ buffer, BackgroundWorker^ bwAsync){
	bool Wave3 = false;
	return Decompress(Decrypt( buffer, Wave3, bwAsync),bwAsync);
				
}

void dump_RC1(array<unsigned char>^ compressed, String^ foldername, bool Wave3, BackgroundWorker^ bwAsync){
		
						if(Wave3/*br->ReadInt32() != 0x3A424344*/ ){

						array<unsigned char>^ CryptBuff = gcnew array<unsigned char> (compressed->Length/* br->BaseStream->Position*/);
						//br->Read(CryptBuff,0,br->BaseStream->Length);
						CryptBuff = compressed;
						Wave3 = false;
						compressed = Decrypt( CryptBuff, Wave3, bwAsync );
						//br->Close();

						//Stream^ stream = gcnew MemoryStream(DecryptBuff);

						//br = gcnew BinaryReader(stream);
						}
	
	
	MemoryStream^ myStreamDump;		
		
		BinaryWriter^ bw = gcnew BinaryWriter(File::Create(String::Concat(foldername, L"\\name.bin"))); 
		bw->BaseStream->Write(compressed,0,0x100);
		//bw->Close();
		bw = gcnew BinaryWriter(File::Create(String::Concat(foldername, L"\\end.bin"))); 
		bw->BaseStream->Write(compressed, compressed->Length - 0x400 , 0x400);
		bw->Close();

				myStreamDump = gcnew MemoryStream(Decompress ( compressed , bwAsync ));
				
				BinaryReader^ br = gcnew BinaryReader(myStreamDump);
				br->BaseStream->Seek(0x0, SeekOrigin::Begin);

				RootEntry^ root = RootEntry::GetRoot(br, 0);

				String^ rootpath = GetStringRc1(root->Rootname);

				rootpath = foldername + L"\\" + rootpath;
				if(!Directory::Exists( rootpath ))
				Directory::CreateDirectory( rootpath );
						
				WriteDumpRc1(br, rootpath, br->BaseStream->Position, bwAsync);

				return ;
			}

void dump_ORG(array<unsigned char>^ compressedRc1, String^ foldername, BackgroundWorker^ bwAsync){
				
				MemoryStream^ myStreamDump = gcnew MemoryStream(compressedRc1);
				BinaryReader^ br = gcnew BinaryReader(myStreamDump);
				br->BaseStream->Seek(0x0, SeekOrigin::Begin);

				RootEntry^ root = RootEntry::GetRoot(br, 0);

				String^ rootpath = GetStringRc1(root->Rootname);

				rootpath = foldername + L"\\" + rootpath;
				if(!Directory::Exists( rootpath ))
				Directory::CreateDirectory( rootpath );
						
				WriteDumpRc1(br, rootpath, br->BaseStream->Position, bwAsync);

				return ;
			}

};