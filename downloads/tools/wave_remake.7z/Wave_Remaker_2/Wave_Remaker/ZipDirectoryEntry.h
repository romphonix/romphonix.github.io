﻿

//#include "ZipEntry.h"



using namespace System;
using namespace System::Collections::Generic;
using namespace System::Text;

namespace TinySharpZip
{
 //ref  class ZipDirectoryEntry : ZipEntry
 //   {

	// String^ directoryName;
 //       

	// public: ZipDirectoryEntry(String^ directoryName)
 //       {
 //           this->directoryName = directoryName;
 //       }


	//public: property String^ DirectoryName
 //       {
 //          String^ get (){ return directoryName; }
 //         void  set (String^ value){ directoryName = value; }
 //               
 //       }

 //   };
}
