﻿using namespace System;
using namespace System::IO;
//using namespace System::Runtime::InteropServices;





namespace TinySharpZip
{
//    ref class Crc32
//    {
////        #region Private Variables
//
//        static  unsigned int CRC32_POLYNOMIAL = 0xedb88320;
//        static  array<unsigned int>^ CRC32_TABLE;
//
////        #endregion
//
////        #region Constructors
//
//        static Crc32()
//        {
//            CRC32_TABLE = gcnew  array<unsigned int>(0x100);
//
//            for (unsigned int byteIndex = 0; byteIndex < 0x100; byteIndex++)
//            {
//                unsigned int crcTableItem = byteIndex;
//                for (int bitIndex = 0; bitIndex < 8; bitIndex++)
//                {
//                    if ((crcTableItem & 1) != 0)
//                    {
//                        crcTableItem = CRC32_POLYNOMIAL ^ (crcTableItem >> 1);
//                    }
//                    else
//                    {
//                        crcTableItem = crcTableItem >> 1;
//                    }
//                }
//                CRC32_TABLE[byteIndex] = crcTableItem;
//            }
//        }
//
////        #endregion
//
////        #region Public Methods
//         static unsigned int Compute(Stream^ bytes)
//        {
//			unsigned int crc32Value = UInt32::MaxValue;
//            int sourceByte = 0;
//            while ((sourceByte = bytes->ReadByte()) != -1)
//            {
//                unsigned int indexInTable = (crc32Value ^ (char)sourceByte) & 0xFF;
//                crc32Value = CRC32_TABLE[indexInTable] ^ (crc32Value >> 8);
//
//            }
//            crc32Value = ~crc32Value;
//            return crc32Value;
//        }
//
////        #endregion
//    };

}
