#include "StdAfx.h"
#include "LanguageID.h"

