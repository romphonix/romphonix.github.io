#pragma once


//#include "Crc32.h"
#include "ZipArchive.h"
//#include "ZipEntry.h"




namespace ImageUtils {


	using namespace System;
	using namespace System::IO;
	using namespace System::IO::Compression;





	void dump_SMT(array<unsigned char>^ compressed, String^ foldername,  BackgroundWorker^ bwAsync ){


				Stream^ myStreamDump = gcnew MemoryStream(compressed);
				
				TinySharpZip::ZipArchive::Extract(myStreamDump, foldername);
				myStreamDump->Close();





	}









}