these games were ripped from a motorola SLVR L7 and a motorola ROKR E1
Crazy - worms clone
Crazy 1.0.14 - same game, but no sound
Golf - literally golf
Pinball - it's pinball
Rebels - space shoot em up game